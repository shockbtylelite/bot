"""
╔══════════════════════════════════════════════════════════╗
║   Dirt VPS Bot  v5.0  —  LXC Backend  (fast & real)    ║
║   Uses Linux Containers instead of QEMU                 ║
╚══════════════════════════════════════════════════════════╝

DNS FIX:
    echo "nameserver 8.8.8.8" > /etc/resolv.conf

Install:
    apt install lxc lxc-templates python3-pip
    pip install discord.py
"""

import discord
from discord.ext import commands
from discord import ui
import json, os, asyncio, re, time, datetime, subprocess, random, string, hashlib, shutil

# ── CONFIG ────────────────────────────────────────────────────────────────────

BOT_TOKEN       = "MTQ4MDE2NTkzMDEwMDE5OTQyNA.GgNhIH.OjOmXUadE5BdwerPHbKy6yyI0J4h5vYE4HQVjg"
ADMIN_ROLE_ID   = 1478445114425606388
SUPPORT_ROLE_ID = 1480193319341396128
DATA_FILE       = "vps_data.json"
CC_FILE         = "custom_commands.json"
SETTINGS_FILE   = "settings.json"
ALERTS_FILE     = "alerts.json"
SCHED_FILE      = "schedules.json"

DEFAULT_RAM_MB  = 512
DEFAULT_CPUS    = 1
DEFAULT_DISK_GB = 10
MAX_RAM_MB      = 16384
MAX_CPUS        = 16
MAX_DISK_GB     = 500
DEFAULT_EXPIRE  = 30 * 24 * 3600

C_BLUE  = 0x5865F2; C_GREEN = 0x57F287; C_RED  = 0xED4245
C_GOLD  = 0xF0A500; C_TEAL  = 0x1ABC9C; C_PINK = 0xFF73FA

OS_OPTIONS = {
    "1": ("Ubuntu 22.04", "ubuntu", "jammy"),
    "2": ("Ubuntu 20.04", "ubuntu", "focal"),
    "3": ("Debian 12",    "debian", "bookworm"),
    "4": ("Debian 11",    "debian", "bullseye"),
    "5": ("Alpine 3.19",  "alpine", "3.19"),
}

PRESETS = {
    "lamp":     "apt-get install -y apache2 mysql-server php php-mysql libapache2-mod-php && systemctl enable apache2 mysql",
    "nginx":    "apt-get install -y nginx && systemctl enable nginx",
    "docker":   "curl -fsSL https://get.docker.com | sh && systemctl enable docker",
    "node":     "curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs && npm i -g pm2",
    "python":   "apt-get install -y python3 python3-pip python3-venv && pip3 install flask fastapi uvicorn",
    "mysql":    "apt-get install -y mysql-server && systemctl enable mysql",
    "redis":    "apt-get install -y redis-server && systemctl enable redis-server",
    "postgres": "apt-get install -y postgresql postgresql-contrib && systemctl enable postgresql",
    "tailscale":"curl -fsSL https://tailscale.com/install.sh | sh",
    "cloudflared":"curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared",
    "certbot":  "apt-get install -y certbot python3-certbot-nginx",
    "fail2ban": "apt-get install -y fail2ban && systemctl enable fail2ban",
    "minecraft":"apt-get install -y default-jre && wget -q https://piston-data.mojang.com/v1/objects/8dd1a28015f51b1803213892b50b7b4fc76e594d/server.jar -O /opt/mc-server.jar",
    "wireguard":"apt-get install -y wireguard",
    "netdata":  "bash <(curl -Ss https://my-netdata.io/kickstart.sh) --non-interactive",
    "grafana":  "apt-get install -y apt-transport-https software-properties-common wget && wget -q -O - https://packages.grafana.com/gpg.key | apt-key add - && echo 'deb https://packages.grafana.com/oss/deb stable main' | tee /etc/apt/sources.list.d/grafana.list && apt-get update -qq && apt-get install -y grafana && systemctl enable grafana-server",
}

# ── BOT SETUP ─────────────────────────────────────────────────────────────────

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

active_talks:  dict = {}
all_messages:  dict = {}

# ── DATA ──────────────────────────────────────────────────────────────────────

def ld():
    return json.load(open(DATA_FILE)) if os.path.exists(DATA_FILE) else {}

def sd(d): json.dump(d, open(DATA_FILE,"w"), indent=2)

def lcc():
    return json.load(open(CC_FILE)) if os.path.exists(CC_FILE) else {}

def scc(c): json.dump(c, open(CC_FILE,"w"), indent=2)

def ls():
    return json.load(open(SETTINGS_FILE)) if os.path.exists(SETTINGS_FILE) else {
        "max_vps_per_user":5,"banned_users":[],"maintenance":False}

def ss(s): json.dump(s, open(SETTINGS_FILE,"w"), indent=2)

def la():
    return json.load(open(ALERTS_FILE)) if os.path.exists(ALERTS_FILE) else {}

def sa(a): json.dump(a, open(ALERTS_FILE,"w"), indent=2)

def gv(data,uid,idx):
    for v in data.get(uid,{}).get("vps_list",[]): 
        if v["index"]==idx: return v
    return None

def ni(data,uid):
    lst=data.get(uid,{}).get("vps_list",[])
    return max((v["index"] for v in lst),default=0)+1

# ── TIME ──────────────────────────────────────────────────────────────────────

def pd(t):
    m=re.fullmatch(r"(\d+)(y|mo|w|d|h|m|s)",t.strip().lower())
    if not m: return None
    v,u=int(m.group(1)),m.group(2)
    return v*{"y":31536000,"mo":2592000,"w":604800,"d":86400,"h":3600,"m":60,"s":1}[u]

def fts(ts): return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M UTC")

def fd(s):
    parts=[]
    for u,n in[("y",31536000),("d",86400),("h",3600),("m",60),("s",1)]:
        if s>=n: parts.append(f"{s//n}{u}"); s%=n
    return " ".join(parts[:3]) or "0s"

# ── SUBPROCESS ────────────────────────────────────────────────────────────────

async def run(cmd, timeout=120):
    try:
        p=await asyncio.create_subprocess_shell(cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        o,e=await asyncio.wait_for(p.communicate(),timeout=timeout)
        return p.returncode,o.decode(errors="replace"),e.decode(errors="replace")
    except asyncio.TimeoutError: return -1,"","timeout"

def sq(s): return "'"+s.replace("'","'\\''")+"'"

# ── LXC HELPERS ───────────────────────────────────────────────────────────────

def lxc_name_for(uid, name): return f"d{uid[-6:]}-{name}"[:32].lower()

async def lxc_exec(lxc_name, cmd, timeout=120):
    return await run(f"lxc-attach -n {sq(lxc_name)} -- bash -c {sq(cmd)}", timeout=timeout)

async def lxc_is_running(name):
    rc,out,_=await run(f"lxc-info -n {sq(name)} -s 2>/dev/null")
    return "RUNNING" in out

async def lxc_status(name):
    rc,out,_=await run(f"lxc-info -n {sq(name)} -s 2>/dev/null")
    if "RUNNING" in out: return "running"
    if "STOPPED" in out: return "stopped"
    return "error"

async def lxc_ip(name):
    _,out,_=await run(f"lxc-info -n {sq(name)} -iH 2>/dev/null")
    ips=[x.strip() for x in out.strip().splitlines() if x.strip() and not x.strip().startswith("fe80")]
    return ips[0] if ips else "?"

async def lxc_start(name):
    rc,_,e=await run(f"lxc-start -n {sq(name)} -d 2>&1")
    return rc==0, e

async def lxc_stop(name):
    await run(f"lxc-stop -n {sq(name)} -k 2>/dev/null", timeout=20)

async def lxc_destroy(name):
    await lxc_stop(name)
    await run(f"lxc-destroy -n {sq(name)} -f 2>/dev/null", timeout=30)

# ── VPS CREATION ──────────────────────────────────────────────────────────────

INSTALL_CMDS = [
    ("sudo apt-get update -y 2>&1",                    "📦 Updating package lists..."),
    ("DEBIAN_FRONTEND=noninteractive sudo apt-get upgrade -y 2>&1", "⬆️  Upgrading packages..."),
    ("sudo apt-get update -y 2>&1",                    "📦 Refreshing lists..."),
    ("DEBIAN_FRONTEND=noninteractive sudo apt-get install -y curl wget git vim nano htop screenfetch net-tools ca-certificates unzip 2>&1", "📦 Installing base tools..."),
    ("sudo apt-get update -y 2>&1",                    "📦 Refreshing lists..."),
    ("curl -fsSL https://tailscale.com/install.sh | sh 2>&1", "🔒 Installing Tailscale..."),
    ("sudo apt-get update -y 2>&1",                    "📦 Refreshing lists..."),
    ("curl -sSf https://sshx.io/get | sh -s -- -q 2>&1 || curl -fsSLk https://github.com/ekzhang/sshx/releases/latest/download/sshx-x86_64-unknown-linux-musl.tar.gz | tar -xz -C /usr/local/bin/ 2>/dev/null || true", "🌐 Installing sshx..."),
    ("sudo apt-get update -y 2>&1",                    "📦 Refreshing lists..."),
    ("DEBIAN_FRONTEND=noninteractive apt-get install -y tmate 2>&1 || curl -fsSLk https://github.com/tmate-io/tmate/releases/download/2.4.0/tmate-2.4.0-static-linux-amd64.tar.xz | tar -xJ -C /usr/local/bin/ --strip=1 2>/dev/null || true", "🖥️  Installing tmate..."),
]

async def create_vps_bg(uid, vps_idx, lxc_n, dist, rel, ram_mb, cpus, dm, name):
    data=ld()

    async def log(msg):
        try: await dm.send(f"⏳ `{name}` — {msg}")
        except: pass
        print(f"[VPS {name}] {msg}")

    def set_status(s):
        d=ld()
        for v in d.get(uid,{}).get("vps_list",[]):
            if v["index"]==vps_idx: v["status"]=s; break
        sd(d)

    try:
        await log(f"Creating LXC container ({dist} {rel})…")
        rc,_,e=await run(f"lxc-create -t download -n {sq(lxc_n)} -- -d {dist} -r {rel} -a amd64 2>&1", timeout=300)
        if rc!=0:
            await log(f"❌ lxc-create failed: `{e[:200]}`"); set_status("error"); return

        # Memory limit
        cfg=f"/var/lib/lxc/{lxc_n}/config"
        if os.path.exists(cfg):
            with open(cfg,"a") as f:
                f.write(f"\nlxc.cgroup2.memory.max = {ram_mb}M\n")
                f.write(f"lxc.cgroup2.cpuset.cpus = 0-{max(0,cpus-1)}\n")

        await log("Starting container…")
        rc,_,e=await run(f"lxc-start -n {sq(lxc_n)} -d 2>&1", timeout=30)
        if rc!=0: await log(f"⚠️ Start: {e[:100]}")
        await asyncio.sleep(5)

        # Wait for network
        for _ in range(15):
            rc2,_,_=await lxc_exec(lxc_n,"echo ok",timeout=8)
            if rc2==0: break
            await asyncio.sleep(3)

        await log("Container up! Running install commands…")

        for cmd,label in INSTALL_CMDS:
            await log(label)
            rc3,out3,err3=await lxc_exec(lxc_n,cmd,timeout=300)
            if err3.strip() and rc3!=0: await log(f"⚠️ `{err3.strip()[-100:]}`")

        set_status("running")
        ip=await lxc_ip(lxc_n)
        d=ld()
        for v in d.get(uid,{}).get("vps_list",[]):
            if v["index"]==vps_idx: v["ip"]=ip; break
        sd(d)

        await dm.send(
            f"🎉 **VPS `{name}` is ready!**\n"
            f"🌐 IP: `{ip}`\n"
            f"🔒 Tailscale: run `!tailscale {vps_idx}` to get auth link\n"
            f"🌐 sshx: run `!sshx {vps_idx}` for browser terminal\n"
            f"🖥️ tmate: run `!tmate {vps_idx}` for SSH session\n\n"
            f"Type `!panel {vps_idx}` for the control panel. Have a nice day! 😊"
        )
    except Exception as ex:
        await log(f"❌ Fatal: `{ex}`"); set_status("error")

async def create_core(owner, requester, setup, pm=None, admin=False):
    os_name,dist,rel,vm_name,ram_mb,cpus,disk_gb=setup
    data=ld(); ukey=str(owner.id)
    if ukey not in data: data[ukey]={"vps_list":[]}
    cfg=ls()
    if str(owner.id) in cfg.get("banned_users",[]): 
        if pm: await pm.edit(content="❌ User is banned."); return
    lst=data[ukey]["vps_list"]; mx=cfg.get("max_vps_per_user",5)
    if not admin and len(lst)>=mx:
        if pm: await pm.edit(content=f"❌ User already has {mx} VPS."); return
    idx=ni(data,ukey)
    lxc_n=lxc_name_for(ukey,vm_name)
    # ensure unique
    taken=[v.get("lxc_name","") for v in lst]
    if lxc_n in taken: lxc_n=f"{lxc_n[:28]}{idx}"
    exp=0 if admin else time.time()+DEFAULT_EXPIRE
    data[ukey]["vps_list"].append({
        "index":idx,"name":vm_name,"lxc_name":lxc_n,"os":os_name,
        "ram_mb":ram_mb,"cpus":cpus,"disk_gb":disk_gb,
        "status":"installing","ip":"?","tailscale_ip":"",
        "sshx_url":"","tmate_ssh":"","created_at":time.time(),
        "expires_at":exp,"warned_24h":False,"notes":"","tags":[],"autostart":True,
    })
    sd(data)
    dm=owner.dm_channel or await owner.create_dm()
    if pm: await pm.edit(content=f"⏳ Creating `{vm_name}` (LXC container, ~2 min)…")
    asyncio.create_task(create_vps_bg(ukey,idx,lxc_n,dist,rel,ram_mb,cpus,dm,vm_name))
    if pm: await pm.edit(content=f"✅ Build started for `{vm_name}`! Watch DMs for progress.")

# ── SSHX ──────────────────────────────────────────────────────────────────────

async def vm_sshx(vps,msg=None):
    lxc_n=vps["lxc_name"]; dbg=[]
    if vps.get("sshx_url"): return vps["sshx_url"],""
    await lxc_exec(lxc_n,"pkill -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true",timeout=5)
    await lxc_exec(lxc_n,"nohup bash -c 'sshx > /tmp/sshx.log 2>&1' </dev/null &",timeout=5)
    await asyncio.sleep(4)
    for _ in range(20):
        await asyncio.sleep(2)
        _,log,_=await lxc_exec(lxc_n,"cat /tmp/sshx.log 2>/dev/null || echo ''",timeout=10)
        m=re.search(r"https://sshx\.io/s/[\w#/=+-]+",log)
        if m: return m.group(0).rstrip("/"),"\n".join(dbg)
        dbg.append(log.strip()[-80:] if log.strip() else "(no output yet)")
    return None,"\n".join(dbg)

async def vm_tmate(vps):
    lxc_n=vps["lxc_name"]
    await lxc_exec(lxc_n,"pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true",timeout=5)
    await lxc_exec(lxc_n,"tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true",timeout=15)
    await asyncio.sleep(8)
    sl=wl=""
    for _ in range(5):
        _,out,_=await lxc_exec(lxc_n,"tmate -S /tmp/tmate.sock show-messages 2>&1 || true",timeout=10)
        sm=re.search(r"ssh\s+\S+@\S+(?:\s+-p\s+\d+)?",out); wm=re.search(r"https://tmate\.io/t/\S+",out)
        if sm: sl=sm.group(0)
        if wm: wl=wm.group(0)
        if sl or wl: break
        await asyncio.sleep(3)
    return sl,wl

# ── VPS EMBED ─────────────────────────────────────────────────────────────────

def vembed(vps,running):
    exp=vps.get("expires_at",0); exps=fts(exp) if exp else "Never"
    left=fd(max(0,int(exp-time.time()))) if exp else "∞"
    e=discord.Embed(title=f"{'🟢' if running else '🔴'}  VPS `{vps['name']}`",
                    color=C_GREEN if running else C_RED, timestamp=datetime.datetime.utcnow())
    e.add_field(name="📋 Status",   value="Running ✅" if running else "Stopped ❌",inline=True)
    e.add_field(name="🖥️ OS",      value=vps.get("os","?"),                          inline=True)
    e.add_field(name="🌐 IP",       value=f"`{vps.get('ip','?')}`",                  inline=True)
    e.add_field(name="🧠 RAM",      value=f"{vps.get('ram_mb',DEFAULT_RAM_MB)}MB",   inline=True)
    e.add_field(name="⚙️ vCPU",    value=str(vps.get("cpus",DEFAULT_CPUS)),          inline=True)
    e.add_field(name="💾 Disk",     value=f"{vps.get('disk_gb',DEFAULT_DISK_GB)}GB", inline=True)
    if vps.get("tailscale_ip"): e.add_field(name="🛡️ Tailscale",value=f"`{vps['tailscale_ip']}`",inline=True)
    e.add_field(name="⏰ Expires",  value=exps, inline=True)
    e.add_field(name="⌛ Left",     value=left,  inline=True)
    if vps.get("notes"): e.add_field(name="📝",value=vps["notes"],inline=False)
    if vps.get("tags"):  e.add_field(name="🏷️",value=" ".join(f"`{t}`" for t in vps["tags"]),inline=False)
    e.set_footer(text=f"#{vps['index']} • {vps['lxc_name']}")
    return e

# ── PANEL VIEW ────────────────────────────────────────────────────────────────

class VPSPanel(ui.View):
    def __init__(self,vps,uid,adm):
        super().__init__(timeout=300); self.vps=vps; self.uid=uid; self.adm=adm

    async def interaction_check(self,i):
        if i.user.id!=self.uid:
            await i.response.send_message("❌ Not your panel.",ephemeral=True); return False
        return True

    async def _refresh(self,i):
        r=await lxc_is_running(self.vps["lxc_name"])
        await i.message.edit(embed=vembed(self.vps,r),view=self)

    @ui.button(label="▶ Start",   style=discord.ButtonStyle.green,  row=0)
    async def btn_start(self,i,b):
        await i.response.defer()
        ok,e=await lxc_start(self.vps["lxc_name"])
        d=ld(); v=gv(d,str(self.uid),self.vps["index"])
        if v: v["status"]="running" if ok else v["status"]; sd(d)
        await i.followup.send("▶️ Started!" if ok else f"❌ {e[:200]}",ephemeral=True)
        await self._refresh(i)

    @ui.button(label="⏹ Stop",    style=discord.ButtonStyle.red,    row=0)
    async def btn_stop(self,i,b):
        await i.response.defer()
        await lxc_stop(self.vps["lxc_name"])
        d=ld(); v=gv(d,str(self.uid),self.vps["index"])
        if v: v["status"]="stopped"; sd(d)
        await i.followup.send("⏹ Stopped.",ephemeral=True); await self._refresh(i)

    @ui.button(label="🔄 Reboot",  style=discord.ButtonStyle.blurple,row=0)
    async def btn_reboot(self,i,b):
        await i.response.defer()
        await lxc_exec(self.vps["lxc_name"],"reboot &",timeout=5)
        await i.followup.send("🔄 Reboot sent!",ephemeral=True); await self._refresh(i)

    @ui.button(label="🔃 Refresh", style=discord.ButtonStyle.grey,   row=0)
    async def btn_refresh(self,i,b):
        await i.response.defer(); await self._refresh(i)
        await i.followup.send("🔃 Refreshed.",ephemeral=True)

    @ui.button(label="🌐 sshx",    style=discord.ButtonStyle.blurple,row=1)
    async def btn_sshx(self,i,b):
        await i.response.defer()
        m=await i.followup.send("⏳ Starting sshx…",ephemeral=True)
        link,_=await vm_sshx(self.vps)
        if link:
            try: await i.user.send(f"✅ **sshx!**\n🔗 {link}")
            except: pass
            await m.edit(content=f"✅ sshx ready!\n🔗 {link}")
        else: await m.edit(content="❌ sshx failed. Container running?")

    @ui.button(label="🖥 tmate",   style=discord.ButtonStyle.blurple,row=1)
    async def btn_tmate(self,i,b):
        await i.response.defer()
        m=await i.followup.send("⏳ Starting tmate…",ephemeral=True)
        sl,wl=await vm_tmate(self.vps)
        if sl or wl:
            lines=["🖥️ **tmate:**"]
            if sl: lines.append(f"```{sl}```")
            if wl: lines.append(f"🌐 {wl}")
            try: await i.user.send("\n".join(lines))
            except: pass
            await m.edit(content="✅ tmate ready! 📬 DMs.")
        else: await m.edit(content="❌ tmate failed. Try sshx.")

    @ui.button(label="📊 Stats",   style=discord.ButtonStyle.grey,   row=1)
    async def btn_stats(self,i,b):
        await i.response.defer()
        n=self.vps["lxc_name"]
        _,upt,_=await lxc_exec(n,"uptime -p 2>/dev/null|head -1"); 
        _,ram,_=await lxc_exec(n,"free -m|awk '/^Mem/{printf \"%s/%s MB\",$3,$2}'")
        _,dsk,_=await lxc_exec(n,"df -h /|awk 'NR==2{printf \"%s/%s (%s)\",$3,$2,$5}'")
        _,cpu,_=await lxc_exec(n,"top -bn1|grep Cpu|awk '{print 100-$8\"%\"}'")
        _,ip, _=await lxc_exec(n,"hostname -I|awk '{print $1}'")
        e=discord.Embed(title=f"📊 Stats — `{self.vps['name']}`",color=C_BLUE,timestamp=datetime.datetime.utcnow())
        e.add_field(name="⏱ Uptime",value=upt.strip()or"?",inline=True)
        e.add_field(name="🧠 RAM",   value=ram.strip()or"?",inline=True)
        e.add_field(name="💾 Disk",  value=dsk.strip()or"?",inline=True)
        e.add_field(name="⚙️ CPU",  value=cpu.strip()or"?",inline=True)
        e.add_field(name="🌐 IP",    value=ip.strip()or"?",inline=True)
        await i.followup.send(embed=e,ephemeral=True)

    @ui.button(label="🔒 Tailscale",style=discord.ButtonStyle.grey,  row=2)
    async def btn_ts(self,i,b):
        await i.response.defer()
        m=await i.followup.send("⏳ Getting Tailscale status…",ephemeral=True)
        _,out,_=await lxc_exec(self.vps["lxc_name"],"tailscale up 2>&1; tailscale status 2>&1 | head -5",timeout=20)
        tsm=re.search(r"https://login\.tailscale\.com/\S+",out)
        ip_m=re.search(r"100\.\d+\.\d+\.\d+",out)
        if tsm:
            await m.edit(content=f"🔗 **Authorize Tailscale:**\n{tsm.group(0)}\n\nPaste the link in your browser to connect.")
        elif ip_m:
            d=ld(); v=gv(d,str(self.uid),self.vps["index"])
            if v: v["tailscale_ip"]=ip_m.group(0); sd(d)
            await m.edit(content=f"✅ **Tailscale IP: `{ip_m.group(0)}`**")
        else: await m.edit(content=f"ℹ️ Tailscale output:\n```\n{out.strip()[:400]}\n```")

    @ui.button(label="📸 Snapshot",style=discord.ButtonStyle.grey,   row=2)
    async def btn_snap(self,i,b):
        await i.response.defer()
        ts=int(time.time())
        rc,_,e=await run(f"lxc-snapshot -n {sq(self.vps['lxc_name'])} -c snap-{ts} 2>&1")
        if rc==0: await i.followup.send(f"📸 Snapshot `snap-{ts}` created!",ephemeral=True)
        else:     await i.followup.send(f"❌ {e[:200]}",ephemeral=True)

    @ui.button(label="🔥 Delete",  style=discord.ButtonStyle.red,    row=2)
    async def btn_del(self,i,b):
        if not self.adm: await i.response.send_message("❌ Admins only.",ephemeral=True); return
        await i.response.send_message(f"⚠️ Type `CONFIRM` to delete `{self.vps['name']}` (30s).",ephemeral=True)
        def chk(m): return m.author.id==i.user.id and m.content=="CONFIRM"
        try:
            await bot.wait_for("message",check=chk,timeout=30)
            await lxc_destroy(self.vps["lxc_name"])
            d=ld(); ukey=str(self.uid)
            d[ukey]["vps_list"]=[v for v in d[ukey]["vps_list"] if v["index"]!=self.vps["index"]]; sd(d)
            self.stop()
            await i.message.edit(content=f"🗑️ `{self.vps['name']}` deleted.",embed=None,view=None)
        except asyncio.TimeoutError: await i.followup.send("⏰ Cancelled.",ephemeral=True)

# ── LOOPS ─────────────────────────────────────────────────────────────────────

async def expiry_loop():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            now=time.time(); data=ld(); changed=False
            for uid,ud in list(data.items()):
                keep=[]
                for vps in ud.get("vps_list",[]):
                    exp=vps.get("expires_at",0)
                    if not exp: keep.append(vps); continue
                    if now>=exp:
                        await lxc_destroy(vps["lxc_name"]); changed=True
                        try:
                            u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                            await dm.send(f"⏰ VPS `{vps['name']}` expired and was deleted.")
                        except: pass
                    else:
                        if exp-now<86400 and not vps.get("warned_24h"):
                            vps["warned_24h"]=True; changed=True
                            try:
                                u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                                await dm.send(f"⚠️ VPS `{vps['name']}` expires in {fd(int(exp-now))}!")
                            except: pass
                        keep.append(vps)
                if len(keep)!=len(ud.get("vps_list",[])):
                    ud["vps_list"]=keep; changed=True
            if changed: sd(data)
        except Exception as ex: print(f"[expiry] {ex}")
        await asyncio.sleep(60)

async def autostart_loop():
    await bot.wait_until_ready(); await asyncio.sleep(15)
    data=ld()
    for ud in data.values():
        for vps in ud.get("vps_list",[]):
            if vps.get("autostart",True) and vps.get("status")=="running":
                running=await lxc_is_running(vps["lxc_name"])
                if not running:
                    await lxc_start(vps["lxc_name"])
                    print(f"[autostart] {vps['lxc_name']}")

# ── PERM HELPERS ──────────────────────────────────────────────────────────────

def isa(member): return any(r.id==ADMIN_ROLE_ID for r in member.roles)

def ao():
    async def pred(ctx):
        if not ctx.guild: await ctx.send("❌ Server only."); return False
        if isa(ctx.author): return True
        await ctx.send("❌ Admins only."); return False
    return commands.check(pred)

async def getvps(ctx,index=1):
    data=ld(); vps=gv(data,str(ctx.author.id),index)
    if not vps: await ctx.send(f"❌ VPS #{index} not found. Use `!vpslist`.")
    return vps,data

async def reply(ctx,*a,**kw):
    if ctx.guild:
        m=await ctx.channel.send(*a,**kw); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id)); return m
    return await ctx.send(*a,**kw)

async def wc(ctx):
    def c(m): return m.author==ctx.author and m.channel==ctx.channel
    try: r=await bot.wait_for("message",check=c,timeout=300); all_messages.setdefault(ctx.channel.id,[]).append(("user",r.id)); return r
    except asyncio.TimeoutError: return None

async def wd(user):
    def c(m): return m.author.id==user.id and isinstance(m.channel,discord.DMChannel)
    try: return await bot.wait_for("message",check=c,timeout=600)
    except asyncio.TimeoutError: return None

# ── WIZARDS ───────────────────────────────────────────────────────────────────

async def guild_wiz(ctx):
    osl="\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    s1=await ctx.channel.send(f"🖥️ **OS:**\n{osl}\n\nType number:")
    r1=await wc(ctx)
    if not r1 or r1.content.strip() not in OS_OPTIONS: await s1.edit(content="❌ Invalid."); return None
    osn,dist,rel=OS_OPTIONS[r1.content.strip()]; await s1.edit(content=f"✅ OS: {osn}")
    s2=await ctx.channel.send("📛 **Name:**")
    r2=await wc(ctx)
    if not r2: return None
    nm=re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:24] or "myserver"
    await s2.edit(content=f"✅ Name: `{nm}`")
    s3=await ctx.channel.send("🧠 **RAM MB** (e.g. 512, 1024, 2048):")
    r3=await wc(ctx)
    try: ram=max(128,min(int(r3.content.strip()),MAX_RAM_MB))
    except: ram=DEFAULT_RAM_MB
    await s3.edit(content=f"✅ RAM: {ram}MB")
    s4=await ctx.channel.send("⚙️ **vCPUs** (1-16):")
    r4=await wc(ctx)
    try: cpus=max(1,min(int(r4.content.strip()),MAX_CPUS))
    except: cpus=DEFAULT_CPUS
    await s4.edit(content=f"✅ vCPUs: {cpus}")
    s5=await ctx.channel.send("💾 **Disk GB** (5-500):")
    r5=await wc(ctx)
    try: disk=max(5,min(int(r5.content.strip()),MAX_DISK_GB))
    except: disk=DEFAULT_DISK_GB
    await s5.edit(content=f"✅ Disk: {disk}GB")
    return osn,dist,rel,nm,ram,cpus,disk

async def dm_wiz(user,admin_name):
    dm=user.dm_channel or await user.create_dm()
    osl="\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    await dm.send(f"👋 **{user.display_name}** — Admin **{admin_name}** is creating your VPS!\n\n🖥️ **OS:**\n{osl}\n\nType number:")
    r1=await wd(user)
    if not r1 or r1.content.strip() not in OS_OPTIONS: await dm.send("❌ Invalid."); return None
    osn,dist,rel=OS_OPTIONS[r1.content.strip()]; await dm.send(f"✅ OS: {osn}")
    await dm.send("📛 **VM name:**"); r2=await wd(user)
    if not r2: return None
    nm=re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:24] or "myserver"
    await dm.send(f"✅ Name: `{nm}`. ⏳ Creating now…")
    return osn,dist,rel,nm,DEFAULT_RAM_MB,DEFAULT_CPUS,DEFAULT_DISK_GB

# ══════════════════════════════════════════════════════════════════════════════
#  COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

# ─── VPS CREATION ─────────────────────────────────────────────────────────────

@bot.command(name="createvps")
@ao()
async def c_createvps(ctx):
    """Create a VPS with custom specs."""
    s=await guild_wiz(ctx)
    if not s: return
    pm=await ctx.channel.send("⏳ Creating container…")
    await create_core(ctx.author,ctx.author,s,pm,admin=True)

@bot.command(name="createsomeonevps")
@ao()
async def c_createsomeonevps(ctx,member:discord.Member):
    """Create VPS for someone else."""
    pm=await ctx.channel.send(f"⏳ Sending wizard to **{member.display_name}**…")
    try: s=await dm_wiz(member,ctx.author.display_name)
    except discord.Forbidden: await pm.edit(content=f"❌ Can't DM {member.mention}."); return
    if not s: await pm.edit(content="❌ Incomplete."); return
    await pm.edit(content=f"⏳ Creating container for **{member.display_name}**…")
    await create_core(member,ctx.author,s,pm,admin=False)

@bot.command(name="clonvps")
@ao()
async def c_clonvps(ctx,index:int=1):
    """Clone a VPS."""
    vps,data=await getvps(ctx,index)
    if not vps: return
    pm=await reply(ctx,f"⏳ Cloning `{vps['name']}`…")
    ukey=str(ctx.author.id); idx=ni(data,ukey)
    new_lxc=f"{vps['lxc_name'][:24]}-cl{idx}"
    rc,_,e=await run(f"lxc-copy -n {sq(vps['lxc_name'])} -N {sq(new_lxc)} 2>&1",timeout=300)
    if rc==0:
        ip=await lxc_ip(new_lxc)
        data[ukey]["vps_list"].append({**dict(vps),"index":idx,"lxc_name":new_lxc,"name":f"{vps['name']}-clone","ip":ip,"created_at":time.time()})
        sd(data)
        await pm.edit(content=f"✅ Clone `{new_lxc}` ready! IP: `{ip}`")
    else: await pm.edit(content=f"❌ Clone failed: {e[:200]}")

# ─── PANEL & INFO ─────────────────────────────────────────────────────────────

@bot.command(name="panel")
async def c_panel(ctx,index:int=1):
    """Interactive button panel."""
    vps,_=await getvps(ctx,index)
    if not vps: return
    running=await lxc_is_running(vps["lxc_name"])
    adm=bool(ctx.guild and isa(ctx.author))
    await reply(ctx,embed=vembed(vps,running),view=VPSPanel(vps,ctx.author.id,adm))

@bot.command(name="vpslist")
async def c_vpslist(ctx):
    """List your VMs."""
    data=ld(); lst=data.get(str(ctx.author.id),{}).get("vps_list",[])
    if not lst: await reply(ctx,"❌ No VMs."); return
    e=discord.Embed(title=f"🖥️ Your VMs ({len(lst)})",color=C_BLUE)
    for v in lst:
        r=await lxc_is_running(v["lxc_name"]); exp=v.get("expires_at",0)
        e.add_field(name=f"{'🟢' if r else '🔴'} #{v['index']} `{v['name']}`",
            value=(f"{v.get('os','?')} • IP:`{v.get('ip','?')}`\n"
                   f"🧠{v.get('ram_mb',DEFAULT_RAM_MB)}MB ⚙️{v.get('cpus',DEFAULT_CPUS)} 💾{v.get('disk_gb',DEFAULT_DISK_GB)}GB\n"
                   f"⏰ {fts(exp) if exp else 'Never'}"),inline=False)
    e.set_footer(text="Use !panel [#] for interactive control panel")
    await reply(ctx,embed=e)

@bot.command(name="status")
async def c_status(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    r=await lxc_is_running(vps["lxc_name"]); ip=await lxc_ip(vps["lxc_name"])
    e=discord.Embed(title=f"📊 `{vps['name']}`",color=C_GREEN if r else C_RED)
    e.add_field(name="Status",value="🟢 Running" if r else "🔴 Stopped",inline=True)
    e.add_field(name="IP",    value=f"`{ip}`",inline=True)
    e.add_field(name="OS",    value=vps.get("os","?"),inline=True)
    e.add_field(name="RAM",   value=f"{vps.get('ram_mb',DEFAULT_RAM_MB)}MB",inline=True)
    e.add_field(name="vCPU",  value=str(vps.get("cpus",DEFAULT_CPUS)),inline=True)
    e.add_field(name="Disk",  value=f"{vps.get('disk_gb',DEFAULT_DISK_GB)}GB",inline=True)
    if vps.get("tailscale_ip"): e.add_field(name="🛡️ Tailscale",value=f"`{vps['tailscale_ip']}`",inline=True)
    await reply(ctx,embed=e)

@bot.command(name="viewothervps")
@ao()
async def c_viewothervps(ctx):
    data=ld()
    for uid,ud in data.items():
        lst=ud.get("vps_list",[])
        if not lst: continue
        try: u=await bot.fetch_user(int(uid)); uname=u.display_name
        except: uname=f"User {uid}"
        e=discord.Embed(title=f"🖥️ {uname} — {len(lst)} VM(s)",color=C_BLUE)
        for v in lst:
            r=await lxc_is_running(v["lxc_name"])
            e.add_field(name=f"{'🟢' if r else '🔴'} #{v['index']} `{v['name']}`",
                value=f"{v.get('os','?')} | {v.get('ram_mb',DEFAULT_RAM_MB)}MB | `{v.get('ip','?')}`",inline=False)
        await ctx.send(embed=e)

# ─── POWER ─────────────────────────────────────────────────────────────────────

@bot.command(name="start")
async def c_start(ctx,index:int=1):
    vps,data=await getvps(ctx,index)
    if not vps: return
    if await lxc_is_running(vps["lxc_name"]): await reply(ctx,"⚠️ Already running."); return
    msg=await reply(ctx,"⏳ Starting…")
    ok,e=await lxc_start(vps["lxc_name"])
    vps["status"]="running" if ok else vps["status"]; sd(data)
    await msg.edit(content="▶️ Started!" if ok else f"❌ {e[:200]}")

@bot.command(name="stop")
async def c_stop(ctx,index:int=1):
    vps,data=await getvps(ctx,index)
    if not vps: return
    await lxc_stop(vps["lxc_name"]); vps["status"]="stopped"; sd(data)
    await reply(ctx,f"⏹️ `{vps['name']}` stopped.")

@bot.command(name="reboot")
async def c_reboot(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    await lxc_exec(vps["lxc_name"],"reboot &",timeout=5)
    await reply(ctx,f"🔄 Reboot sent to `{vps['name']}`!")

@bot.command(name="forceoff")
@ao()
async def c_forceoff(ctx,index:int=1):
    vps,data=await getvps(ctx,index)
    if not vps: return
    await run(f"lxc-stop -n {sq(vps['lxc_name'])} -k 2>/dev/null",timeout=15)
    vps["status"]="stopped"; sd(data); await reply(ctx,f"💀 `{vps['name']}` force-killed.")

@bot.command(name="deletevps")
@ao()
async def c_deletevps(ctx,index:int=1):
    vps,data=await getvps(ctx,index)
    if not vps: return
    await reply(ctx,f"🗑️ Destroying `{vps['name']}`…")
    await lxc_destroy(vps["lxc_name"])
    ukey=str(ctx.author.id); data[ukey]["vps_list"]=[v for v in data[ukey]["vps_list"] if v["index"]!=index]; sd(data)
    await reply(ctx,f"✅ `{vps['name']}` destroyed.")

@bot.command(name="userdeletevps")
@ao()
async def c_userdeletevps(ctx,user_id:int,index:int=1):
    data=ld(); vps=gv(data,str(user_id),index)
    if not vps: await ctx.send("❌ Not found."); return
    await ctx.send(f"🗑️ Destroying…")
    await lxc_destroy(vps["lxc_name"])
    data[str(user_id)]["vps_list"]=[v for v in data[str(user_id)]["vps_list"] if v["index"]!=index]; sd(data)
    try:
        u=await bot.fetch_user(user_id); dm=u.dm_channel or await u.create_dm()
        await dm.send(f"⚠️ Your VPS **`{vps['name']}`** was deleted by an admin.")
    except: pass
    await ctx.send(f"✅ Done.")

# ─── TERMINAL ACCESS ──────────────────────────────────────────────────────────

@bot.command(name="sshx")
async def c_sshx(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Getting sshx link for `{vps['name']}`…")
    link,dbg=await vm_sshx(vps,msg)
    if link:
        try: await ctx.author.send(f"✅ **sshx on `{vps['name']}`**\n🔗 {link}")
        except: pass
        await msg.edit(content="✅ sshx ready! 📬 Link in DMs." if ctx.guild else f"✅ sshx!\n🔗 {link}")
    else: await msg.edit(content=f"❌ sshx failed:\n```{dbg[-500:]}```")

@bot.command(name="tmate")
async def c_tmate(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,"⏳ Starting tmate…")
    sl,wl=await vm_tmate(vps)
    if sl or wl:
        lines=["🖥️ **tmate:**"]
        if sl: lines.append(f"```{sl}```")
        if wl: lines.append(f"🌐 {wl}")
        try: await ctx.author.send("\n".join(lines))
        except: pass
        await msg.edit(content="✅ tmate ready! 📬 DMs." if ctx.guild else "\n".join(lines))
    else: await msg.edit(content="❌ tmate failed. Try `!sshx`.")

@bot.command(name="tailscale")
async def c_tailscale(ctx,index:int=1):
    """Get Tailscale auth link or IP."""
    vps,data=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,"⏳ Getting Tailscale status…")
    _,out,_=await lxc_exec(vps["lxc_name"],"tailscale up 2>&1; tailscale status 2>&1 | head -5",timeout=20)
    tsm=re.search(r"https://login\.tailscale\.com/\S+",out)
    ip_m=re.search(r"100\.\d+\.\d+\.\d+",out)
    if tsm:
        await msg.edit(content=f"🔗 **Tailscale Auth Link:**\n{tsm.group(0)}\n\nPaste in your browser, then run `!tailscale {index}` again.")
    elif ip_m:
        vps["tailscale_ip"]=ip_m.group(0); sd(data)
        await msg.edit(content=f"✅ **Tailscale connected!** IP: `{ip_m.group(0)}`")
    else:
        await msg.edit(content=f"ℹ️ Tailscale output:\n```\n{out.strip()[:600]}\n```")

# ─── SYSTEM INFO ──────────────────────────────────────────────────────────────

async def vi(ctx,index,cmd,title,emoji=""):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],cmd,timeout=20)
    output=(out+err).strip()[:1800] or "(no output)"
    await reply(ctx,f"{emoji} **{title} — `{vps['name']}`:**\n```\n{output}\n```")

@bot.command(name="df")
async def c_df(ctx,i:int=1):    await vi(ctx,i,"df -h","Disk","💾")
@bot.command(name="ram")
async def c_ram(ctx,i:int=1):   await vi(ctx,i,"free -h","RAM","🧠")
@bot.command(name="cpu")
async def c_cpu(ctx,i:int=1):   await vi(ctx,i,"top -bn1|head -12","CPU","⚙️")
@bot.command(name="top")
async def c_top(ctx,i:int=1):   await vi(ctx,i,"ps aux --sort=-%cpu|head -12","Processes","📊")
@bot.command(name="uptime")
async def c_uptime(ctx,i:int=1): await vi(ctx,i,"uptime","Uptime","⏱️")
@bot.command(name="ip")
async def c_ip(ctx,i:int=1):    await vi(ctx,i,"ip addr show","Network","🌐")
@bot.command(name="ports")
async def c_ports(ctx,i:int=1): await vi(ctx,i,"ss -tlnp 2>/dev/null||netstat -tlnp 2>/dev/null","Ports","🔌")
@bot.command(name="load")
async def c_load(ctx,i:int=1):  await vi(ctx,i,"cat /proc/loadavg && uptime","Load","📈")
@bot.command(name="os")
async def c_os(ctx,i:int=1):    await vi(ctx,i,"cat /etc/os-release","OS","🐧")
@bot.command(name="kernel")
async def c_kernel(ctx,i:int=1): await vi(ctx,i,"uname -a","Kernel","🐧")
@bot.command(name="who")
async def c_who(ctx,i:int=1):   await vi(ctx,i,"who && w","Logged In","👥")
@bot.command(name="dmesg")
async def c_dmesg(ctx,i:int=1): await vi(ctx,i,"dmesg|tail -30","dmesg","📋")

# ─── FILES ────────────────────────────────────────────────────────────────────

@bot.command(name="ls")
async def c_ls(ctx,index:int=1,*,path:str="/"):
    vps,_=await getvps(ctx,index)
    if not vps: return
    await vi(ctx,index,f"ls -la {sq(path)} 2>&1|head -40","Files","📁")

@bot.command(name="cat")
async def c_cat(ctx,index:int=1,*,filepath:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"cat {sq(filepath)} 2>&1|head -80",timeout=10)
    await reply(ctx,f"📄 **`{filepath}`:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="tail")
async def c_tail(ctx,index:int=1,*,filepath:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"tail -40 {sq(filepath)} 2>&1",timeout=10)
    await reply(ctx,f"📄 **tail:**\n```\n{(out+err).strip()[:1800]}\n```")

# ─── NETWORK ──────────────────────────────────────────────────────────────────

@bot.command(name="ping")
async def c_ping(ctx,index:int=1,*,host:str="google.com"):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"ping -c 4 {host} 2>&1",timeout=20)
    await reply(ctx,f"🏓 **ping {host}:**\n```\n{(out+err).strip()[:1500]}\n```")

@bot.command(name="dig")
async def c_dig(ctx,index:int=1,*,query:str="google.com"):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"dig {query} 2>&1||nslookup {query} 2>&1",timeout=15)
    await reply(ctx,f"🔍 **dig {query}:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="curl")
async def c_curl(ctx,index:int=1,*,url:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"curl -sSL --max-time 10 {sq(url)} 2>&1|head -40",timeout=20)
    await reply(ctx,f"🌐 **curl:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="httpcheck")
async def c_httpcheck(ctx,index:int=1,*,url:str="http://localhost"):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,out,_=await lxc_exec(vps["lxc_name"],f"curl -sSo /dev/null -w '%{{http_code}}' --max-time 10 {sq(url)}",timeout=20)
    code=out.strip(); ok=code.startswith("2") or code.startswith("3")
    await reply(ctx,f"{'✅' if ok else '❌'} `{url}` → HTTP **{code}**")

# ─── SERVICES ─────────────────────────────────────────────────────────────────

@bot.command(name="svc")
async def c_svc(ctx,index:int=1,*,name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"systemctl status {name} 2>&1|head -20",timeout=15)
    await reply(ctx,f"⚙️ **{name}:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="svcstart")
async def c_svcstart(ctx,index:int=1,*,name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await lxc_exec(vps["lxc_name"],f"systemctl start {name} 2>&1",timeout=20)
    await reply(ctx,f"✅ `{name}` started." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="svcstop")
async def c_svcstop(ctx,index:int=1,*,name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await lxc_exec(vps["lxc_name"],f"systemctl stop {name} 2>&1",timeout=20)
    await reply(ctx,f"✅ `{name}` stopped." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="svcrestart")
async def c_svcrestart(ctx,index:int=1,*,name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await lxc_exec(vps["lxc_name"],f"systemctl restart {name} 2>&1",timeout=20)
    await reply(ctx,f"✅ `{name}` restarted." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="svclogs")
async def c_svclogs(ctx,index:int=1,*,name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"journalctl -u {name} -n 30 --no-pager 2>&1",timeout=20)
    await reply(ctx,f"📜 **{name} logs:**\n```\n{(out+err).strip()[:1800]}\n```")

# ─── PACKAGES ─────────────────────────────────────────────────────────────────

@bot.command(name="install")
async def c_install(ctx,index:int=1,*,package:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Installing `{package}`…")
    rc,out,err=await lxc_exec(vps["lxc_name"],
        f"apt-get update -qq 2>&1 && DEBIAN_FRONTEND=noninteractive apt-get install -y {package} 2>&1",timeout=180)
    output=(out+err).strip()[-600:]
    await msg.edit(content=f"✅ `{package}` installed!\n```\n{output[-300:]}\n```" if rc==0 else f"❌ Failed:\n```\n{output[-400:]}\n```")

@bot.command(name="remove")
@ao()
async def c_remove(ctx,index:int=1,*,package:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Removing `{package}`…")
    rc,_,e=await lxc_exec(vps["lxc_name"],f"apt-get remove -y {package} 2>&1",timeout=120)
    await msg.edit(content=f"✅ `{package}` removed." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="update")
async def c_update(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,"⏳ Updating…")
    rc,_,e=await lxc_exec(vps["lxc_name"],"apt-get update -qq 2>&1",timeout=120)
    await msg.edit(content="✅ Updated!" if rc==0 else f"❌ {e[:200]}")

@bot.command(name="preset")
@ao()
async def c_preset(ctx,index:int=1,*,name:str):
    """Install a preset stack. !preset [#] <n>"""
    if name not in PRESETS:
        await reply(ctx,f"❌ Unknown. Available: {', '.join(f'`{k}`' for k in PRESETS)}"); return
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Installing **{name}** on `{vps['name']}`…")
    rc,out,err=await lxc_exec(vps["lxc_name"],
        f"apt-get update -qq 2>&1 && DEBIAN_FRONTEND=noninteractive bash -c {sq(PRESETS[name])} 2>&1",timeout=600)
    output=(out+err).strip()[-800:]
    await msg.edit(content=f"✅ **{name}** installed!\n```\n{output[-300:]}\n```" if rc==0 else f"❌ Failed:\n```\n{output[-500:]}\n```")

# ─── USERS ────────────────────────────────────────────────────────────────────

@bot.command(name="adduser")
@ao()
async def c_adduser(ctx,index:int=1,username:str="",password:str=""):
    if not username: await reply(ctx,"❌ Usage: `!adduser [#] username password`"); return
    vps,_=await getvps(ctx,index)
    if not vps: return
    pw=password or "".join(random.choices(string.ascii_letters+string.digits,k=16))
    rc,_,e=await lxc_exec(vps["lxc_name"],
        f"useradd -m -s /bin/bash {username} 2>&1 && echo '{username}:{pw}' | chpasswd && usermod -aG sudo {username} 2>&1",timeout=15)
    if rc==0:
        await reply(ctx,f"✅ User `{username}` created.")
        try: await ctx.author.send(f"👤 New user on `{vps['name']}`:\n`{username}` / `{pw}`")
        except: pass
    else: await reply(ctx,f"❌ {e[:200]}")

@bot.command(name="passwd")
async def c_passwd(ctx,index:int=1,username:str="",password:str=""):
    vps,_=await getvps(ctx,index)
    if not vps: return
    user=username or "root"
    pw=password or "".join(random.choices(string.ascii_letters+string.digits,k=20))
    rc,_,e=await lxc_exec(vps["lxc_name"],f"echo '{user}:{pw}' | chpasswd 2>&1",timeout=10)
    if rc==0:
        await reply(ctx,f"✅ Password for `{user}` changed.")
        try: await ctx.author.send(f"🔑 `{user}` on `{vps['name']}`: `{pw}`")
        except: pass
    else: await reply(ctx,f"❌ {e[:200]}")

@bot.command(name="userlist")
async def c_userlist(ctx,index:int=1):
    await vi(ctx,index,"cat /etc/passwd|grep -v nologin|grep -v false|cut -d: -f1,3,6","Users","👥")

# ─── DOCKER ───────────────────────────────────────────────────────────────────

@bot.command(name="dps")
async def c_dps(ctx,i:int=1):     await vi(ctx,i,"docker ps -a 2>&1","Docker Containers","🐳")
@bot.command(name="dimages")
async def c_dimages(ctx,i:int=1): await vi(ctx,i,"docker images 2>&1","Docker Images","🐳")
@bot.command(name="dstats")
async def c_dstats(ctx,i:int=1):  await vi(ctx,i,"docker stats --no-stream 2>&1","Docker Stats","🐳")
@bot.command(name="dvolumes")
async def c_dvols(ctx,i:int=1):   await vi(ctx,i,"docker volume ls 2>&1","Docker Volumes","🐳")

@bot.command(name="dlogs")
async def c_dlogs(ctx,index:int=1,*,container:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    _,out,err=await lxc_exec(vps["lxc_name"],f"docker logs --tail=40 {container} 2>&1",timeout=20)
    await reply(ctx,f"📜 **{container} logs:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="dstart")
async def c_dstart(ctx,index:int=1,*,container:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await lxc_exec(vps["lxc_name"],f"docker start {container} 2>&1",timeout=20)
    await reply(ctx,f"✅ `{container}` started." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="dstop")
async def c_dstop(ctx,index:int=1,*,container:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await lxc_exec(vps["lxc_name"],f"docker stop {container} 2>&1",timeout=20)
    await reply(ctx,f"✅ `{container}` stopped." if rc==0 else f"❌ {e[:200]}")

# ─── SNAPSHOTS ────────────────────────────────────────────────────────────────

@bot.command(name="snapshot")
@ao()
async def c_snapshot(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    ts=int(time.time())
    rc,_,e=await run(f"lxc-snapshot -n {sq(vps['lxc_name'])} -c snap-{ts} 2>&1")
    await reply(ctx,f"📸 Snapshot `snap-{ts}` created!" if rc==0 else f"❌ {e[:200]}")

@bot.command(name="snapshots")
async def c_snapshots(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,out,_=await run(f"lxc-snapshot -L -n {sq(vps['lxc_name'])} 2>&1")
    await reply(ctx,f"📸 **Snapshots:**\n```\n{out.strip()[:1800]}\n```")

@bot.command(name="snaprestore")
@ao()
async def c_snaprestore(ctx,index:int=1,*,snap_name:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Restoring `{snap_name}`…")
    await lxc_stop(vps["lxc_name"]); await asyncio.sleep(2)
    rc,_,e=await run(f"lxc-snapshot -r {sq(snap_name)} -n {sq(vps['lxc_name'])} 2>&1")
    if rc==0:
        await lxc_start(vps["lxc_name"])
        await msg.edit(content=f"✅ Snapshot `{snap_name}` restored and rebooted!")
    else: await msg.edit(content=f"❌ {e[:200]}")

# ─── RUN ──────────────────────────────────────────────────────────────────────

@bot.command(name="run")
@ao()
async def c_run(ctx,index:int=1,*,command:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Running on `{vps['name']}`…")
    rc,out,err=await lxc_exec(vps["lxc_name"],command,timeout=120)
    output=(out+err).strip()[:1800]
    e=discord.Embed(title=f"{'✅' if rc==0 else '❌'} Command on `{vps['name']}`",color=C_GREEN if rc==0 else C_RED)
    e.add_field(name="Exit",value=str(rc),inline=True)
    e.add_field(name="Cmd", value=f"```{command[:120]}```",inline=False)
    if output: e.add_field(name="Output",value=f"```\n{output}\n```",inline=False)
    await msg.edit(content="",embed=e)

# ─── ORGANISATION ─────────────────────────────────────────────────────────────

@bot.command(name="notes")
async def c_notes(ctx,index:int=1,*,text:str):
    vps,data=await getvps(ctx,index)
    if not vps: return
    vps["notes"]=text[:200]; sd(data); await reply(ctx,f"📝 Notes set.")

@bot.command(name="tag")
async def c_tag(ctx,index:int=1,*,tags:str):
    vps,data=await getvps(ctx,index)
    if not vps: return
    vps["tags"]=tags.split()[:10]; sd(data); await reply(ctx,f"🏷️ Tags: {' '.join(f'`{t}`' for t in vps['tags'])}")

@bot.command(name="autostart")
async def c_autostart(ctx,index:int=1,*,toggle:str="on"):
    vps,data=await getvps(ctx,index)
    if not vps: return
    on=toggle.lower() in ("on","true","yes","1"); vps["autostart"]=on; sd(data)
    await reply(ctx,f"{'🟢' if on else '⭕'} Autostart {'ON' if on else 'OFF'} for `{vps['name']}`.")

@bot.command(name="transfer")
@ao()
async def c_transfer(ctx,index:int=1,member:discord.Member=None):
    if not member: await reply(ctx,"❌ Usage: `!transfer [#] @user`"); return
    vps,data=await getvps(ctx,index)
    if not vps: return
    ukey=str(ctx.author.id); tkey=str(member.id)
    if tkey not in data: data[tkey]={"vps_list":[]}
    vps["index"]=ni(data,tkey); data[tkey]["vps_list"].append(vps)
    data[ukey]["vps_list"]=[v for v in data[ukey]["vps_list"] if v["index"]!=index]; sd(data)
    try:
        dm=member.dm_channel or await member.create_dm()
        await dm.send(f"📦 VM **`{vps['name']}`** transferred to you by **{ctx.author.display_name}**!")
    except: pass
    await reply(ctx,f"✅ `{vps['name']}` transferred to **{member.display_name}**.")

# ─── EXPIRY ───────────────────────────────────────────────────────────────────

@bot.command(name="expire")
@ao()
async def c_expire(ctx,user_id:int,duration:str):
    secs=pd(duration)
    if not secs: await ctx.send("❌ Use: `7d` `2h` `1mo`"); return
    data=ld(); vl=data.get(str(user_id),{}).get("vps_list",[])
    if not vl: await ctx.send(f"❌ No VPS for `{user_id}`."); return
    new_exp=time.time()+secs
    for v in vl: v["expires_at"]=new_exp; v["warned_24h"]=False
    sd(data)
    try:
        u=await bot.fetch_user(user_id); dm=u.dm_channel or await u.create_dm()
        await dm.send(f"⏰ Your VPS(es) expire **{fts(new_exp)}** ({fd(secs)} from now).")
    except: pass
    await ctx.send(f"✅ Expires **{fts(new_exp)}**.")

@bot.command(name="noexpire")
@ao()
async def c_noexpire(ctx,user_id:int):
    data=ld(); vl=data.get(str(user_id),{}).get("vps_list",[])
    for v in vl: v["expires_at"]=0; v["warned_24h"]=False
    sd(data); await ctx.send(f"✅ Expiry removed from `{user_id}`.")

# ─── ADMIN ────────────────────────────────────────────────────────────────────

@bot.command(name="stats")
@ao()
async def c_stats(ctx):
    data=ld()
    total_u=len([u for u in data if data[u].get("vps_list")])
    total_v=sum(len(u.get("vps_list",[])) for u in data.values())
    running=sum(1 for ud in data.values() for v in ud.get("vps_list",[]) if v.get("status")=="running")
    e=discord.Embed(title="📈 Bot Stats",color=C_BLUE)
    e.add_field(name="👥 Users",  value=str(total_u),inline=True)
    e.add_field(name="🖥️ VMs",   value=str(total_v),inline=True)
    e.add_field(name="🟢 Running",value=str(running),inline=True)
    e.add_field(name="Backend",   value="LXC",       inline=True)
    await ctx.send(embed=e)

@bot.command(name="setmaxvps")
@ao()
async def c_setmaxvps(ctx,n:int):
    s=ls(); s["max_vps_per_user"]=max(1,n); ss(s)
    await ctx.send(f"✅ Max VPS per user: **{n}**.")

@bot.command(name="banuser")
@ao()
async def c_banuser(ctx,user_id:int):
    s=ls()
    if str(user_id) not in s.get("banned_users",[]): s.setdefault("banned_users",[]).append(str(user_id))
    ss(s); await ctx.send(f"🚫 `{user_id}` banned.")

@bot.command(name="unbanuser")
@ao()
async def c_unbanuser(ctx,user_id:int):
    s=ls(); s["banned_users"]=[u for u in s.get("banned_users",[]) if u!=str(user_id)]; ss(s)
    await ctx.send(f"✅ `{user_id}` unbanned.")

@bot.command(name="announce")
@ao()
async def c_announce(ctx,*,message:str):
    data=ld(); count=0
    for uid in data:
        if data[uid].get("vps_list"):
            try:
                u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                await dm.send(f"📢 **{ctx.author.display_name}:** {message}"); count+=1
                await asyncio.sleep(0.5)
            except: pass
    await ctx.send(f"📢 Sent to **{count}** users.")

# ─── CUSTOM COMMANDS ──────────────────────────────────────────────────────────

@bot.command(name="createcustomcommand")
@ao()
async def c_ccc(ctx):
    s1=await ctx.channel.send("🛠️ **Name** (no `!`):")
    r1=await wc(ctx)
    if not r1: return
    cn=re.sub(r"[^a-z0-9_]","",r1.content.strip().lower())
    if not cn: await s1.edit(content="❌ Invalid."); return
    s2=await ctx.channel.send("🛠️ **Bash command:**")
    r2=await wc(ctx)
    if not r2: return
    bc=r2.content.strip()
    s3=await ctx.channel.send("🛠️ **Description:**")
    r3=await wc(ctx); desc=r3.content.strip() if r3 else "Custom"
    cmds=lcc(); cmds[cn]={"bash":bc,"description":desc}; scc(cmds)
    await ctx.channel.send(f"✅ `!{cn}` created!")

@bot.command(name="deletecustomcommand")
@ao()
async def c_dcc(ctx,name:str):
    name=name.lstrip("!").lower(); cmds=lcc()
    if name not in cmds: await ctx.send(f"❌ Not found."); return
    del cmds[name]; scc(cmds); await ctx.send(f"🗑️ `!{name}` deleted.")

@bot.command(name="listcustomcommands")
@ao()
async def c_lcc_cmd(ctx):
    cmds=lcc()
    if not cmds: await ctx.send("❌ No custom commands."); return
    e=discord.Embed(title="🛠️ Custom Commands",color=C_GOLD)
    for n,info in cmds.items():
        e.add_field(name=f"!{n}",value=f"{info['description']}\n```{info['bash'][:60]}```",inline=False)
    await ctx.send(embed=e)

# ─── TALK / SUPPORT ───────────────────────────────────────────────────────────

@bot.command(name="talk")
@ao()
async def c_talk(ctx,user_id:int):
    if ctx.author.id in active_talks: await ctx.send("⚠️ Already talking."); return
    try: target=await bot.fetch_user(user_id)
    except: await ctx.send("❌ Not found."); return
    active_talks[ctx.author.id]=user_id; active_talks[user_id]=ctx.author.id
    try:
        dm=target.dm_channel or await target.create_dm()
        await dm.send("📞 **Admin connected.** Use `!say <msg>`, `!endtalk` to end.")
    except discord.Forbidden:
        active_talks.pop(ctx.author.id,None); active_talks.pop(user_id,None)
        await ctx.send(f"❌ Can't DM {target.display_name}."); return
    await ctx.send(f"✅ Connected to **{target.display_name}**.")

@bot.command(name="endtalk")
async def c_endtalk(ctx):
    uid=ctx.author.id
    if uid not in active_talks: await reply(ctx,"❌ No active talk."); return
    pid=active_talks.pop(uid); active_talks.pop(pid,None)
    try:
        p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
        await dm.send("📵 Chat ended.")
    except: pass
    await reply(ctx,"✅ Talk ended.")

@bot.command(name="botinfo")
async def c_botinfo(ctx):
    e=discord.Embed(title="🤖 Dirt VPS Bot v5.0 — LXC",color=C_PINK)
    e.add_field(name="📡 Ping",   value=f"{round(bot.latency*1000)}ms",inline=True)
    e.add_field(name="Backend",   value="LXC Containers",              inline=True)
    e.add_field(name="Presets",   value=str(len(PRESETS)),             inline=True)
    e.set_footer(text="Dirt VPS • Fast LXC containers")
    await reply(ctx,embed=e)

@bot.command(name="ping")
async def c_ping(ctx):
    await reply(ctx,f"🏓 `{round(bot.latency*1000)}ms`")

@bot.command(name="clear")
@ao()
async def c_clear(ctx):
    entries=all_messages.get(ctx.channel.id,[]); deleted=0
    for _,mid in list(entries):
        try: m=await ctx.channel.fetch_message(mid); await m.delete(); deleted+=1
        except: pass
        await asyncio.sleep(0.3)
    all_messages[ctx.channel.id]=[]
    try: await ctx.message.delete()
    except: pass
    m=await ctx.send(f"🧹 Cleared {deleted} messages.")
    await asyncio.sleep(3)
    try: await m.delete()
    except: pass

@bot.command(name="commands")
async def c_commands(ctx):
    e=discord.Embed(title="🖥️ Dirt VPS Bot v5.0 — LXC",color=C_BLUE,description="LXC-based real Linux containers")
    e.add_field(name="🔨 Create",    value="`!createvps` `!createsomeonevps @u` `!clonvps [#]`",inline=False)
    e.add_field(name="📋 Panel",     value="`!panel [#]` `!vpslist` `!status [#]` `!viewothervps`",inline=False)
    e.add_field(name="⚡ Power",     value="`!start` `!stop` `!reboot` `!forceoff` `!deletevps`",inline=False)
    e.add_field(name="🌐 Access",    value="`!sshx [#]` `!tmate [#]` `!tailscale [#]`",inline=False)
    e.add_field(name="🖥️ Info",     value="`!df` `!ram` `!cpu` `!top` `!uptime` `!ip` `!ports` `!os` `!kernel` `!who` `!load`",inline=False)
    e.add_field(name="📁 Files",     value="`!ls` `!cat` `!tail`",inline=False)
    e.add_field(name="🌍 Network",   value="`!ping` `!dig` `!curl` `!httpcheck`",inline=False)
    e.add_field(name="⚙️ Services", value="`!svc` `!svcstart` `!svcstop` `!svcrestart` `!svclogs`",inline=False)
    e.add_field(name="📦 Packages",  value="`!install` `!remove` `!update` `!preset`",inline=False)
    e.add_field(name="👤 Users",     value="`!adduser` `!passwd` `!userlist`",inline=False)
    e.add_field(name="🐳 Docker",    value="`!dps` `!dimages` `!dstart` `!dstop` `!dlogs` `!dstats`",inline=False)
    e.add_field(name="📸 Snapshots", value="`!snapshot` `!snapshots` `!snaprestore`",inline=False)
    e.add_field(name="🏷️ Org",      value="`!notes` `!tag` `!autostart` `!transfer`",inline=False)
    e.add_field(name="⏰ Expiry",    value="`!expire <id> <time>` `!noexpire <id>`",inline=False)
    e.add_field(name="👥 Admin",     value="`!stats` `!setmaxvps` `!banuser` `!unbanuser` `!announce`",inline=False)
    e.add_field(name="🛠️ Custom",   value="`!createcustomcommand` `!deletecustomcommand` `!listcustomcommands`",inline=False)
    e.add_field(name="💬 Misc",      value="`!run [#] <cmd>` `!talk` `!clear` `!ping` `!botinfo`",inline=False)
    e.set_footer(text="!panel [#] opens interactive button control panel")
    await reply(ctx,embed=e)

# ── DM HANDLER ────────────────────────────────────────────────────────────────

async def handle_dm(message):
    parts=message.content.strip().split(); cmd=parts[0][1:].lower(); args=parts[1:]
    uid=message.author.id; ukey=str(uid)
    index=int(args[0]) if args and args[0].isdigit() else 1
    data=ld(); vps=gv(data,ukey,index)

    if cmd=="say":
        if uid not in active_talks: await message.channel.send("❌ No active chat."); return
        pid=active_talks[uid]; text=" ".join(args) or "(empty)"
        try:
            p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
            role="👤 User" if ukey in data else "👨‍💼 Admin"
            await dm.send(f"{role} **{message.author.display_name}**: {text}")
            await message.channel.send("✅ Sent.")
        except Exception as ex: await message.channel.send(f"❌ {ex}")
        return

    if cmd=="endtalk":
        if uid not in active_talks: await message.channel.send("❌ No talk."); return
        pid=active_talks.pop(uid); active_talks.pop(pid,None)
        try:
            p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
            await dm.send("📵 Chat ended.")
        except: pass
        await message.channel.send("✅ Ended."); return

    if cmd=="support":
        await message.channel.send("✅ Support request sent! An admin will DM you.")
        for guild in bot.guilds:
            for rid in (SUPPORT_ROLE_ID,ADMIN_ROLE_ID):
                role=guild.get_role(rid)
                if not role: continue
                for member in role.members:
                    if member.bot: continue
                    try:
                        adm=member.dm_channel or await member.create_dm()
                        await adm.send(f"🆘 **{message.author.display_name}** (`{uid}`) needs support! `!talk {uid}`")
                    except: pass
        return

    if cmd in ("vpslist","listvps"):
        lst=data.get(ukey,{}).get("vps_list",[])
        if not lst: await message.channel.send("❌ No VMs."); return
        e=discord.Embed(title=f"🖥️ Your VMs ({len(lst)})",color=C_BLUE)
        for v in lst:
            r=await lxc_is_running(v["lxc_name"]); exp=v.get("expires_at",0)
            e.add_field(name=f"{'🟢' if r else '🔴'} #{v['index']} `{v['name']}`",
                value=f"{v.get('os','?')} • IP:`{v.get('ip','?')}`\n⏰ {fts(exp) if exp else 'Never'}",inline=False)
        await message.channel.send(embed=e); return

    if cmd=="panel":
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        r=await lxc_is_running(vps["lxc_name"])
        await message.channel.send(embed=vembed(vps,r),view=VPSPanel(vps,uid,False)); return

    if cmd=="status":
        if not vps: await message.channel.send("❌ Not found."); return
        r=await lxc_is_running(vps["lxc_name"]); ip=await lxc_ip(vps["lxc_name"])
        e=discord.Embed(title=f"📊 `{vps['name']}`",color=C_GREEN if r else C_RED)
        e.add_field(name="Status",value="🟢 Running" if r else "🔴 Stopped",inline=True)
        e.add_field(name="IP",    value=f"`{ip}`",inline=True)
        await message.channel.send(embed=e); return

    if cmd=="start":
        if not vps: await message.channel.send("❌ Not found."); return
        ok,e=await lxc_start(vps["lxc_name"])
        if ok: vps["status"]="running"; sd(data)
        await message.channel.send("▶️ Started!" if ok else f"❌ {e[:200]}"); return

    if cmd=="stop":
        if not vps: await message.channel.send("❌ Not found."); return
        await lxc_stop(vps["lxc_name"]); vps["status"]="stopped"; sd(data)
        await message.channel.send("⏹️ Stopped."); return

    if cmd=="reboot":
        if not vps: await message.channel.send("❌ Not found."); return
        await lxc_exec(vps["lxc_name"],"reboot &",timeout=5)
        await message.channel.send("🔄 Reboot sent!"); return

    if cmd=="sshx":
        if not vps: await message.channel.send("❌ Not found."); return
        msg=await message.channel.send("⏳ Starting sshx…")
        link,_=await vm_sshx(vps)
        if link: await msg.edit(content=f"✅ **sshx!**\n🔗 {link}")
        else:    await msg.edit(content="❌ sshx failed.")
        return

    if cmd=="tmate":
        if not vps: await message.channel.send("❌ Not found."); return
        msg=await message.channel.send("⏳ Starting tmate…")
        sl,wl=await vm_tmate(vps)
        if sl or wl:
            out=["🖥️ **tmate:**"]
            if sl: out.append(f"```{sl}```")
            if wl: out.append(f"🌐 {wl}")
            await msg.edit(content="\n".join(out))
        else: await msg.edit(content="❌ tmate failed. Try `!sshx`.")
        return

    if cmd=="tailscale":
        if not vps: await message.channel.send("❌ Not found."); return
        msg=await message.channel.send("⏳ Checking Tailscale…")
        _,out,_=await lxc_exec(vps["lxc_name"],"tailscale up 2>&1; tailscale status 2>&1|head -5",timeout=20)
        tsm=re.search(r"https://login\.tailscale\.com/\S+",out)
        ip_m=re.search(r"100\.\d+\.\d+\.\d+",out)
        if tsm: await msg.edit(content=f"🔗 **Auth link:** {tsm.group(0)}")
        elif ip_m:
            vps["tailscale_ip"]=ip_m.group(0); sd(data)
            await msg.edit(content=f"✅ Tailscale IP: `{ip_m.group(0)}`")
        else: await msg.edit(content=f"ℹ️ {out.strip()[:400]}")
        return

    # Simple info commands
    dm_map={"df":"df -h","ram":"free -h","top":"ps aux --sort=-%cpu|head -12","uptime":"uptime","ip":"hostname -I && ip addr show","ports":"ss -tlnp 2>/dev/null","cpu":"top -bn1|head -12","os":"cat /etc/os-release"}
    if cmd in dm_map:
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        _,out,err=await lxc_exec(vps["lxc_name"],dm_map[cmd],timeout=15)
        await message.channel.send(f"```\n{(out+err).strip()[:1500]}\n```"); return

    if cmd=="install":
        pkg=" ".join(args[1:]) if len(args)>1 else ""
        if not pkg or not vps: await message.channel.send("❌ !install [#] <pkg>"); return
        msg=await message.channel.send(f"⏳ Installing `{pkg}`…")
        rc,out,err=await lxc_exec(vps["lxc_name"],f"apt-get update -qq 2>&1 && apt-get install -y {pkg} 2>&1",timeout=180)
        out2=(out+err).strip()[-400:]
        await msg.edit(content=f"✅ `{pkg}` installed!\n```{out2[-300:]}```" if rc==0 else f"❌ {out2}"); return

    if cmd=="commands":
        e=discord.Embed(title="🖥️ Your DM Commands",color=C_BLUE)
        e.add_field(name="📋 Info",  value="`!vpslist` `!panel [#]` `!status [#]` `!df` `!ram` `!cpu` `!uptime` `!ip`",inline=False)
        e.add_field(name="⚡ Power", value="`!start [#]` `!stop [#]` `!reboot [#]`",inline=False)
        e.add_field(name="🌐 Access",value="`!sshx [#]` `!tmate [#]` `!tailscale [#]`",inline=False)
        e.add_field(name="📦 Pkgs",  value="`!install [#] <pkg>`",inline=False)
        e.add_field(name="💬 Help",  value="`!support` `!say <msg>` `!endtalk`",inline=False)
        # custom commands
        cc=lcc()
        if cc: e.add_field(name="🛠️ Custom",value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in cc.items()),inline=False)
        await message.channel.send(embed=e); return

    # Custom commands
    cc=lcc()
    if cmd in cc:
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        msg=await message.channel.send(f"⏳ Running `!{cmd}`…")
        rc,out,err=await lxc_exec(vps["lxc_name"],cc[cmd]["bash"],timeout=120)
        out2=(out+err).strip()[:1400]
        await msg.edit(content=f"✅ Done!\n```{out2}```" if rc==0 else f"❌ Failed:\n```{out2}```"); return

    await message.channel.send(f"❓ `!{cmd}` unknown. Type `!commands`.")

# ── EVENT ROUTER ──────────────────────────────────────────────────────────────

@bot.event
async def on_message(message):
    if message.author.bot: return
    if isinstance(message.channel,discord.DMChannel):
        if message.content.startswith("!"): await handle_dm(message)
        return
    all_messages.setdefault(message.channel.id,[]).append(("user",message.id))
    if not message.content.startswith("!"): return
    # custom commands in guild
    parts=message.content.strip().split(); cmd=parts[0][1:].lower(); args=parts[1:]
    index=int(args[0]) if args and args[0].isdigit() else 1
    cc=lcc()
    if cmd in cc:
        data=ld(); vps=gv(data,str(message.author.id),index)
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        msg=await message.channel.send(f"⏳ Running `!{cmd}` on `{vps['name']}`…")
        rc,out,err=await lxc_exec(vps["lxc_name"],cc[cmd]["bash"],timeout=120)
        out2=(out+err).strip()[:1400]
        await msg.edit(content=f"✅ Done!\n```{out2}```" if rc==0 else f"❌ Failed:\n```{out2}```")
        return
    await bot.process_commands(message)

@bot.event
async def on_command_error(ctx,error):
    if isinstance(error,(commands.MemberNotFound,)): await ctx.send("❌ User not found.")
    elif isinstance(error,commands.MissingRequiredArgument): await ctx.send("❌ Missing argument. Try `!commands`.")
    elif isinstance(error,(commands.CheckFailure,commands.CommandNotFound)): pass
    else: await ctx.send(f"❌ {error}")

@bot.event
async def on_ready():
    print("╔══════════════════════════════════════════╗")
    print(f"║  Dirt VPS Bot v5.0  LXC  ✅  Online!    ║")
    print(f"║  {bot.user}")
    print("╚══════════════════════════════════════════╝")
    bot.loop.create_task(expiry_loop())
    bot.loop.create_task(autostart_loop())

bot.run(BOT_TOKEN)

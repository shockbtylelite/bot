"""
DenizHosting Panel  —  Flask + LXC + SocketIO
Port 8000  |  First user = Owner/Admin
"""
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_socketio import SocketIO, emit, join_room
import sqlite3, hashlib, os, subprocess, threading, time, json, re, pty, select, signal, struct, fcntl, termios

app = Flask(__name__)
app.secret_key = os.urandom(32).hex()
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

DB = "deniz.db"
PANEL_NAME = "DenizHosting"

# ─── DB ───────────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS vps_listings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            owner_id INTEGER,
            cores INTEGER DEFAULT 1,
            ram_mb INTEGER DEFAULT 512,
            disk_gb INTEGER DEFAULT 10,
            os TEXT DEFAULT 'ubuntu:22.04',
            price REAL DEFAULT 0,
            is_free INTEGER DEFAULT 1,
            max_slots INTEGER DEFAULT 1,
            sold_slots INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS vps_instances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            listing_id INTEGER,
            lxc_name TEXT UNIQUE NOT NULL,
            display_name TEXT DEFAULT '',
            status TEXT DEFAULT 'installing',
            tailscale_ip TEXT DEFAULT '',
            sshx_url TEXT DEFAULT '',
            tmate_ssh TEXT DEFAULT '',
            cores INTEGER DEFAULT 1,
            ram_mb INTEGER DEFAULT 512,
            disk_gb INTEGER DEFAULT 10,
            os TEXT DEFAULT 'ubuntu:22.04',
            created_at INTEGER DEFAULT (strftime('%s','now')),
            expires_at INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            listing_id INTEGER,
            vps_id INTEGER,
            amount REAL DEFAULT 0,
            email TEXT,
            first_name TEXT,
            last_name TEXT,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS install_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER,
            line TEXT,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        """)

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def current_user():
    if "user_id" not in session: return None
    with get_db() as db:
        return db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

def is_admin():
    u = current_user()
    return u and u["role"] in ("admin","owner")

# ─── LXC HELPERS ──────────────────────────────────────────────────────────────
def lxc_run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"

def lxc_exec(name, cmd, timeout=120):
    return lxc_run(f"lxc-attach -n {name} -- bash -c {shq(cmd)}", timeout=timeout)

def shq(s):
    return "'" + s.replace("'", "'\\''") + "'"

def lxc_is_running(name):
    rc, out, _ = lxc_run(f"lxc-info -n {name} -s 2>/dev/null")
    return "RUNNING" in out

def lxc_status(name):
    rc, out, _ = lxc_run(f"lxc-info -n {name} -s 2>/dev/null")
    if "RUNNING" in out: return "running"
    if "STOPPED" in out: return "stopped"
    return "unknown"

def lxc_ip(name):
    _, out, _ = lxc_run(f"lxc-info -n {name} -iH 2>/dev/null")
    ips = [x.strip() for x in out.strip().splitlines() if x.strip() and not x.strip().startswith("fe80")]
    return ips[0] if ips else ""

OS_OPTIONS = {
    "ubuntu:22.04": "Ubuntu 22.04",
    "ubuntu:20.04": "Ubuntu 20.04",
    "debian:12":    "Debian 12",
    "debian:11":    "Debian 11",
    "alpine:3.19":  "Alpine 3.19",
}

def add_install_log(vps_id, line):
    with get_db() as db:
        db.execute("INSERT INTO install_logs (vps_id, line) VALUES (?,?)", (vps_id, line))
    socketio.emit("install_log", {"line": line}, room=f"vps_{vps_id}")

def set_vps_status(vps_id, status):
    with get_db() as db:
        db.execute("UPDATE vps_instances SET status=? WHERE id=?", (status, vps_id))
    socketio.emit("status_change", {"status": status}, room=f"vps_{vps_id}")

def create_lxc_vps(vps_id, lxc_name, os_str, cores, ram_mb, disk_gb):
    """Background thread: create LXC container and run install commands."""
    dist, ver = (os_str.split(":") + [""])[:2]
    if not ver: ver = "latest"

    def log(msg):
        add_install_log(vps_id, msg)
        print(f"[VPS {vps_id}] {msg}")

    try:
        log(f"📦 Creating LXC container: {lxc_name}")
        rc, out, err = lxc_run(
            f"lxc-create -t download -n {lxc_name} -- -d {dist} -r {ver} -a amd64 2>&1",
            timeout=300)
        if rc != 0:
            log(f"❌ lxc-create failed: {err[:300]}")
            set_vps_status(vps_id, "error"); return

        # Set memory / CPU limits
        cfg_path = f"/var/lib/lxc/{lxc_name}/config"
        with open(cfg_path, "a") as f:
            f.write(f"\nlxc.cgroup2.memory.max = {ram_mb}M\n")
            f.write(f"lxc.cgroup2.cpuset.cpus = 0-{cores-1}\n")

        log("▶️  Starting container...")
        lxc_run(f"lxc-start -n {lxc_name} -d", timeout=30)
        time.sleep(5)

        # Wait for network
        for i in range(20):
            rc2, _, _ = lxc_exec(lxc_name, "echo ready", timeout=10)
            if rc2 == 0: break
            time.sleep(3)

        log("✅ Container is up! Running install commands...")

        commands = [
            ("sudo apt-get update -y",            "📦 Updating package lists..."),
            ("DEBIAN_FRONTEND=noninteractive sudo apt-get upgrade -y", "⬆️  Upgrading packages..."),
            ("sudo apt-get update -y",            "📦 Updating again..."),
            ("DEBIAN_FRONTEND=noninteractive sudo apt-get install -y curl wget git vim nano htop net-tools screenfetch ca-certificates unzip", "📦 Installing base tools..."),
            ("sudo apt-get update -y",            "📦 Package list refresh..."),
            ("curl -fsSL https://tailscale.com/install.sh | sh", "🔒 Installing Tailscale VPN..."),
            ("sudo apt-get update -y",            "📦 Package list refresh..."),
            ("curl -sSf https://sshx.io/get | sh -s -- -q || curl -fsSLk https://github.com/ekzhang/sshx/releases/latest/download/sshx-x86_64-unknown-linux-musl.tar.gz | tar -xz -C /usr/local/bin/ && chmod +x /usr/local/bin/sshx 2>/dev/null || true", "🌐 Installing sshx..."),
            ("sudo apt-get update -y",            "📦 Package list refresh..."),
            ("apt-get install -y tmate 2>/dev/null || curl -fsSLk https://github.com/tmate-io/tmate/releases/download/2.4.0/tmate-2.4.0-static-linux-amd64.tar.xz | tar -xJ -C /usr/local/bin/ --strip=1 2>/dev/null || true", "🖥️  Installing tmate..."),
        ]

        for cmd, label in commands:
            log(label)
            rc3, out3, err3 = lxc_exec(lxc_name, cmd, timeout=300)
            if out3.strip(): log(out3.strip()[-500:])
            if err3.strip() and rc3 != 0: log(f"⚠️  {err3.strip()[-200:]}")

        log("✅ All tools installed successfully!")
        log("🔒 Setting up Tailscale — waiting for user to authenticate...")

        # Start tailscale
        lxc_exec(lxc_name, "tailscale up --accept-routes 2>/dev/null &", timeout=10)
        _, ts_out, _ = lxc_exec(lxc_name, "tailscale up --auth-key='' 2>&1 || tailscale status 2>&1 || echo PENDING", timeout=15)
        log("ℹ️  Tailscale: " + ts_out.strip()[:200])

        set_vps_status(vps_id, "running")
        log("🎉 VPS is ready! Have a nice day 🎉")

    except Exception as e:
        log(f"❌ Install error: {e}")
        set_vps_status(vps_id, "error")

# ─── AUTH ROUTES ──────────────────────────────────────────────────────────────
@app.route("/")
def index():
    if "user_id" not in session: return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email","").strip()
        pw    = request.form.get("password","").strip()
        with get_db() as db:
            u = db.execute("SELECT * FROM users WHERE email=? AND password=?", (email, hash_pw(pw))).fetchone()
        if u:
            session["user_id"] = u["id"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html", panel=PANEL_NAME)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        email    = request.form.get("email","").strip()
        pw       = request.form.get("password","").strip()
        if not username or not email or not pw:
            flash("All fields required.", "error")
            return render_template("register.html", panel=PANEL_NAME)
        with get_db() as db:
            count = db.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
            role  = "owner" if count == 0 else "user"
            try:
                db.execute("INSERT INTO users (username,email,password,role) VALUES (?,?,?,?)",
                           (username, email, hash_pw(pw), role))
                u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
                session["user_id"] = u["id"]
                flash(f"Welcome, {username}! {'You are the Owner.' if role=='owner' else ''}", "success")
                return redirect(url_for("dashboard"))
            except sqlite3.IntegrityError:
                flash("Username or email already taken.", "error")
    return render_template("register.html", panel=PANEL_NAME)

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

# ─── DASHBOARD ────────────────────────────────────────────────────────────────
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        vpses   = db.execute("SELECT * FROM vps_instances WHERE user_id=? ORDER BY id DESC", (u["id"],)).fetchall()
        shop    = db.execute("SELECT vl.*,u.username as owner_name FROM vps_listings vl LEFT JOIN users u ON vl.owner_id=u.id WHERE vl.is_active=1 ORDER BY vl.id DESC").fetchall()
        u_count = db.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
        v_count = db.execute("SELECT COUNT(*) as c FROM vps_instances").fetchone()["c"]
    return render_template("dashboard.html", user=u, vpses=vpses, shop=shop,
                           panel=PANEL_NAME, user_count=u_count, vps_count=v_count,
                           os_options=OS_OPTIONS, is_admin=is_admin())

# ─── VPS MANAGEMENT ───────────────────────────────────────────────────────────
@app.route("/vps/create", methods=["POST"])
def vps_create():
    if "user_id" not in session: return redirect(url_for("login"))
    u  = current_user()
    name     = re.sub(r"[^a-z0-9\-]", "-", request.form.get("name","myserver").lower())[:32]
    cores    = min(int(request.form.get("cores", 1)), 8)
    ram_mb   = min(int(request.form.get("ram", 512)), 8192)
    disk_gb  = min(int(request.form.get("disk", 10)), 200)
    os_str   = request.form.get("os", "ubuntu:22.04")
    target_uid = int(request.form.get("target_user", u["id"])) if is_admin() else u["id"]
    if os_str not in OS_OPTIONS: os_str = "ubuntu:22.04"

    lxc_name = f"deniz-{target_uid}-{name}-{int(time.time())%10000}"
    with get_db() as db:
        db.execute("INSERT INTO vps_instances (user_id,lxc_name,display_name,status,cores,ram_mb,disk_gb,os) VALUES (?,?,?,?,?,?,?,?)",
                   (target_uid, lxc_name, name, "installing", cores, ram_mb, disk_gb, os_str))
        vps_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]

    threading.Thread(target=create_lxc_vps, args=(vps_id, lxc_name, os_str, cores, ram_mb, disk_gb), daemon=True).start()
    flash(f"VPS '{name}' is being created!", "success")
    return redirect(url_for("vps_panel", vps_id=vps_id))

@app.route("/vps/<int:vps_id>")
def vps_panel(vps_id):
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
        logs = db.execute("SELECT line FROM install_logs WHERE vps_id=? ORDER BY id ASC LIMIT 300", (vps_id,)).fetchall()
    if not vps: flash("VPS not found.","error"); return redirect(url_for("dashboard"))
    if vps["user_id"] != u["id"] and not is_admin():
        flash("Access denied.","error"); return redirect(url_for("dashboard"))
    running = lxc_is_running(vps["lxc_name"])
    ip = lxc_ip(vps["lxc_name"])
    return render_template("vps_panel.html", vps=vps, user=u, panel=PANEL_NAME,
                           running=running, ip=ip, logs=[r["line"] for r in logs],
                           is_admin=is_admin(), os_options=OS_OPTIONS)

@app.route("/vps/<int:vps_id>/start", methods=["POST"])
def vps_start(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False,"msg":"Not found"})
    lxc_run(f"lxc-start -n {vps['lxc_name']} -d")
    with get_db() as db: db.execute("UPDATE vps_instances SET status='running' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Started"})

@app.route("/vps/<int:vps_id>/stop", methods=["POST"])
def vps_stop(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_run(f"lxc-stop -n {vps['lxc_name']} -k")
    with get_db() as db: db.execute("UPDATE vps_instances SET status='stopped' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Stopped"})

@app.route("/vps/<int:vps_id>/restart", methods=["POST"])
def vps_restart(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_run(f"lxc-stop -n {vps['lxc_name']} -k")
    time.sleep(2)
    lxc_run(f"lxc-start -n {vps['lxc_name']} -d")
    with get_db() as db: db.execute("UPDATE vps_instances SET status='running' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Restarted"})

@app.route("/vps/<int:vps_id>/screenfetch", methods=["POST"])
def vps_screenfetch(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    rc, out, err = lxc_exec(vps["lxc_name"],
        "screenfetch -N 2>/dev/null || neofetch --stdout 2>/dev/null || echo 'screenfetch not installed'", timeout=20)
    return jsonify({"ok":True,"output":(out+err).strip()[:2000]})

@app.route("/vps/<int:vps_id>/sshx", methods=["POST"])
def vps_sshx(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    if vps["sshx_url"]:
        return jsonify({"ok":True,"url":vps["sshx_url"]})
    lxc_exec(vps["lxc_name"], "pkill -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true", timeout=5)
    lxc_exec(vps["lxc_name"], "nohup bash -c 'sshx > /tmp/sshx.log 2>&1' </dev/null &", timeout=5)
    time.sleep(5)
    for _ in range(20):
        time.sleep(2)
        _, log, _ = lxc_exec(vps["lxc_name"], "cat /tmp/sshx.log 2>/dev/null", timeout=10)
        m = re.search(r"https://sshx\.io/s/[\w#/=+-]+", log)
        if m:
            url = m.group(0).rstrip("/")
            with get_db() as db: db.execute("UPDATE vps_instances SET sshx_url=? WHERE id=?", (url, vps_id))
            return jsonify({"ok":True,"url":url})
    return jsonify({"ok":False,"msg":"sshx URL not found"})

@app.route("/vps/<int:vps_id>/tmate", methods=["POST"])
def vps_tmate(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_exec(vps["lxc_name"], "pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true", timeout=5)
    lxc_exec(vps["lxc_name"], "tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true", timeout=15)
    time.sleep(8)
    ssh_line = web_link = ""
    for _ in range(5):
        _, out, _ = lxc_exec(vps["lxc_name"], "tmate -S /tmp/tmate.sock show-messages 2>&1 || true", timeout=10)
        sm = re.search(r"ssh\s+\S+@\S+(?:\s+-p\s+\d+)?", out)
        wm = re.search(r"https://tmate\.io/t/\S+", out)
        if sm: ssh_line = sm.group(0)
        if wm: web_link = wm.group(0)
        if ssh_line or web_link: break
        time.sleep(3)
    if ssh_line:
        with get_db() as db: db.execute("UPDATE vps_instances SET tmate_ssh=? WHERE id=?", (ssh_line, vps_id))
    return jsonify({"ok":bool(ssh_line or web_link),"ssh":ssh_line,"web":web_link})

@app.route("/vps/<int:vps_id>/tailscale", methods=["POST"])
def vps_tailscale(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    _, out, _ = lxc_exec(vps["lxc_name"], "tailscale ip -4 2>/dev/null || echo ''", timeout=10)
    ts_ip = out.strip()
    if ts_ip:
        with get_db() as db: db.execute("UPDATE vps_instances SET tailscale_ip=? WHERE id=?", (ts_ip, vps_id))
    return jsonify({"ok":True,"ip":ts_ip})

@app.route("/vps/<int:vps_id>/tailscale_up", methods=["POST"])
def vps_tailscale_up(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    _, out, _ = lxc_exec(vps["lxc_name"], "tailscale up 2>&1; tailscale status 2>&1 | head -5", timeout=30)
    m = re.search(r"https://login\.tailscale\.com/\S+", out)
    return jsonify({"ok":True,"output":out.strip()[:500],"login_url": m.group(0) if m else ""})

@app.route("/vps/<int:vps_id>/delete", methods=["POST"])
def vps_delete(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    u = current_user()
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    if vps["user_id"] != u["id"] and not is_admin(): return jsonify({"ok":False,"msg":"Access denied"})
    lxc_run(f"lxc-stop -n {vps['lxc_name']} -k 2>/dev/null; lxc-destroy -n {vps['lxc_name']} 2>/dev/null; true", timeout=30)
    with get_db() as db:
        db.execute("DELETE FROM vps_instances WHERE id=?", (vps_id,))
        db.execute("DELETE FROM install_logs WHERE vps_id=?", (vps_id,))
    return jsonify({"ok":True})

@app.route("/vps/<int:vps_id>/status")
def vps_status(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    running = lxc_is_running(vps["lxc_name"])
    ip = lxc_ip(vps["lxc_name"])
    return jsonify({"ok":True,"status":vps["status"],"running":running,"ip":ip,
                    "tailscale_ip":vps["tailscale_ip"],"sshx_url":vps["sshx_url"]})

# ─── SHOP ─────────────────────────────────────────────────────────────────────
@app.route("/shop")
def shop():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        listings = db.execute(
            "SELECT vl.*,u.username as owner_name FROM vps_listings vl LEFT JOIN users u ON vl.owner_id=u.id WHERE vl.is_active=1 ORDER BY vl.id DESC"
        ).fetchall()
    return render_template("shop.html", user=u, listings=listings, panel=PANEL_NAME,
                           os_options=OS_OPTIONS, is_admin=is_admin())

@app.route("/shop/create", methods=["GET","POST"])
def shop_create():
    if "user_id" not in session: return redirect(url_for("login"))
    if not is_admin(): flash("Admins only.","error"); return redirect(url_for("shop"))
    if request.method == "POST":
        step = int(request.form.get("step",1))
        if step == 3:  # final
            u = current_user()
            name    = re.sub(r"[^a-zA-Z0-9 _\-]","", request.form.get("name","VPS Plan"))[:60]
            cores   = min(int(request.form.get("cores",1)), 16)
            ram_mb  = min(int(request.form.get("ram",512)), 16384)
            disk_gb = min(int(request.form.get("disk",10)), 500)
            os_str  = request.form.get("os","ubuntu:22.04")
            price   = float(request.form.get("price",0))
            is_free = 1 if request.form.get("is_free","1") == "1" else 0
            max_slots = max(1, int(request.form.get("max_slots",1)))
            desc    = request.form.get("description","")[:300]
            with get_db() as db:
                db.execute("INSERT INTO vps_listings (name,description,owner_id,cores,ram_mb,disk_gb,os,price,is_free,max_slots) VALUES (?,?,?,?,?,?,?,?,?,?)",
                           (name, desc, u["id"], cores, ram_mb, disk_gb, os_str, price, is_free, max_slots))
            flash(f"'{name}' is now live in the shop!","success")
            return redirect(url_for("shop"))
        return render_template("shop_create.html", user=current_user(), panel=PANEL_NAME,
                               step=step+1, form_data=request.form, os_options=OS_OPTIONS, is_admin=True)
    return render_template("shop_create.html", user=current_user(), panel=PANEL_NAME,
                           step=1, form_data={}, os_options=OS_OPTIONS, is_admin=True)

@app.route("/shop/buy/<int:listing_id>", methods=["GET","POST"])
def shop_buy(listing_id):
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        listing = db.execute("SELECT * FROM vps_listings WHERE id=? AND is_active=1", (listing_id,)).fetchone()
    if not listing: flash("Listing not found.","error"); return redirect(url_for("shop"))
    if listing["sold_slots"] >= listing["max_slots"]: flash("Sold out!","error"); return redirect(url_for("shop"))
    if request.method == "POST":
        email      = request.form.get("email","").strip()
        first_name = request.form.get("first_name","").strip()
        last_name  = request.form.get("last_name","").strip()
        if not email or not first_name or not last_name:
            flash("All fields required.","error")
            return render_template("payment.html", user=u, listing=listing, panel=PANEL_NAME, os_options=OS_OPTIONS)
        # Create VPS
        lxc_name = f"deniz-{u['id']}-shop-{listing_id}-{int(time.time())%10000}"
        with get_db() as db:
            db.execute("INSERT INTO vps_instances (user_id,listing_id,lxc_name,display_name,status,cores,ram_mb,disk_gb,os) VALUES (?,?,?,?,?,?,?,?,?)",
                       (u["id"], listing_id, lxc_name, listing["name"], "installing",
                        listing["cores"], listing["ram_mb"], listing["disk_gb"], listing["os"]))
            vps_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
            db.execute("INSERT INTO purchases (user_id,listing_id,vps_id,amount,email,first_name,last_name) VALUES (?,?,?,?,?,?,?)",
                       (u["id"], listing_id, vps_id, listing["price"], email, first_name, last_name))
            db.execute("UPDATE vps_listings SET sold_slots=sold_slots+1 WHERE id=?", (listing_id,))
        threading.Thread(target=create_lxc_vps, args=(vps_id, lxc_name, listing["os"], listing["cores"], listing["ram_mb"], listing["disk_gb"]), daemon=True).start()
        flash(f"Purchase complete! Your VPS is being set up.","success")
        return redirect(url_for("vps_panel", vps_id=vps_id))
    return render_template("payment.html", user=u, listing=listing, panel=PANEL_NAME, os_options=OS_OPTIONS)

# ─── ADMIN ────────────────────────────────────────────────────────────────────
@app.route("/admin")
def admin():
    if not is_admin(): return redirect(url_for("dashboard"))
    with get_db() as db:
        users    = db.execute("SELECT * FROM users ORDER BY id").fetchall()
        vpses    = db.execute("SELECT vi.*,u.username FROM vps_instances vi LEFT JOIN users u ON vi.user_id=u.id ORDER BY vi.id DESC").fetchall()
        listings = db.execute("SELECT * FROM vps_listings ORDER BY id DESC").fetchall()
    return render_template("admin.html", user=current_user(), users=users, vpses=vpses,
                           listings=listings, panel=PANEL_NAME, is_admin=True)

@app.route("/admin/user/<int:uid>/role", methods=["POST"])
def admin_set_role(uid):
    if not is_admin(): return jsonify({"ok":False})
    role = request.form.get("role","user")
    with get_db() as db: db.execute("UPDATE users SET role=? WHERE id=?", (role, uid))
    return jsonify({"ok":True})

@app.route("/admin/listing/<int:lid>/delete", methods=["POST"])
def admin_del_listing(lid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db: db.execute("UPDATE vps_listings SET is_active=0 WHERE id=?", (lid,))
    return jsonify({"ok":True})

# ─── WEBSOCKET TERMINAL ───────────────────────────────────────────────────────
terminal_processes = {}

@socketio.on("join_vps")
def on_join_vps(data):
    vps_id = data.get("vps_id")
    join_room(f"vps_{vps_id}")

@socketio.on("terminal_start")
def on_terminal_start(data):
    vps_id = data.get("vps_id")
    sid    = request.sid
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return
    if not lxc_is_running(vps["lxc_name"]):
        emit("terminal_output", {"data": "\r\n❌ Container is not running.\r\n"})
        return
    master_fd, slave_fd = pty.openpty()
    proc = subprocess.Popen(
        ["lxc-attach", "-n", vps["lxc_name"], "--", "/bin/bash"],
        stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
        preexec_fn=os.setsid)
    os.close(slave_fd)
    terminal_processes[sid] = {"proc": proc, "fd": master_fd}

    def reader():
        while True:
            try:
                r, _, _ = select.select([master_fd], [], [], 0.1)
                if r:
                    data2 = os.read(master_fd, 4096)
                    socketio.emit("terminal_output", {"data": data2.decode(errors="replace")}, room=sid)
            except (OSError, Exception):
                break
        socketio.emit("terminal_output", {"data": "\r\n\033[31m[Disconnected]\033[0m\r\n"}, room=sid)

    threading.Thread(target=reader, daemon=True).start()

@socketio.on("terminal_input")
def on_terminal_input(data):
    sid = request.sid
    if sid in terminal_processes:
        fd = terminal_processes[sid]["fd"]
        try: os.write(fd, data["data"].encode())
        except: pass

@socketio.on("terminal_resize")
def on_terminal_resize(data):
    sid = request.sid
    if sid in terminal_processes:
        fd = terminal_processes[sid]["fd"]
        rows, cols = data.get("rows",24), data.get("cols",80)
        try:
            fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except: pass

@socketio.on("disconnect")
def on_disconnect():
    sid = request.sid
    if sid in terminal_processes:
        try:
            p = terminal_processes[sid]["proc"]; p.kill()
            os.close(terminal_processes[sid]["fd"])
        except: pass
        del terminal_processes[sid]

# ─── RUN ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    print("╔══════════════════════════════════════════════╗")
    print("║   DenizHosting Panel  —  Starting on :8000  ║")
    print("╚══════════════════════════════════════════════╝")
    socketio.run(app, host="0.0.0.0", port=8000, debug=False)

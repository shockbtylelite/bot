#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║   DenizHosting Setup Script — One command installs all      ║
# ║   Run: sudo bash setup.sh                                   ║
# ╚══════════════════════════════════════════════════════════════╝

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
step() { echo -e "\n${BLUE}${BOLD}══ $1 ══${NC}"; }
err()  { echo -e "${RED}[✗] ERROR: $1${NC}"; exit 1; }

echo -e "${BOLD}  DenizHosting Panel — Auto Setup  ${NC}\n"
[ "$EUID" -ne 0 ] && err "Run as root: sudo bash setup.sh"

step "1. Fixing DNS"
echo -e "nameserver 8.8.8.8\nnameserver 1.1.1.1" > /etc/resolv.conf
log "DNS fixed"

step "2. System Update"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y -qq && apt-get upgrade -y -qq
log "System updated"

step "3. Installing Packages"
apt-get install -y -qq python3 python3-pip python3-venv lxc lxc-templates lxc-utils \
    curl wget git vim nano iptables net-tools ca-certificates unzip bridge-utils debootstrap
log "Packages installed"

step "4. LXC Networking"
cat > /etc/default/lxc-net << 'EOF'
USE_LXC_BRIDGE="true"
LXC_BRIDGE="lxcbr0"
LXC_ADDR="10.0.3.1"
LXC_NETMASK="255.255.255.0"
LXC_NETWORK="10.0.3.0/24"
LXC_DHCP_RANGE="10.0.3.2,10.0.3.254"
LXC_DHCP_MAX="253"
LXC_IPV6_ENABLE="false"
EOF
cat > /etc/lxc/default.conf << 'EOF'
lxc.net.0.type = veth
lxc.net.0.link = lxcbr0
lxc.net.0.flags = up
lxc.net.0.hwaddr = 00:16:3e:xx:xx:xx
lxc.apparmor.profile = generated
lxc.apparmor.allow_nesting = 1
EOF
systemctl enable lxc-net 2>/dev/null || true
systemctl start  lxc-net 2>/dev/null || true
echo 1 > /proc/sys/net/ipv4/ip_forward
echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf 2>/dev/null || true
iptables -I FORWARD -i lxcbr0 -j ACCEPT 2>/dev/null || true
iptables -I FORWARD -o lxcbr0 -j ACCEPT 2>/dev/null || true
iptables -t nat -A POSTROUTING -s 10.0.3.0/24 ! -d 10.0.3.0/24 -j MASQUERADE 2>/dev/null || true
log "LXC networking configured"

step "5. Python Virtual Environment"
PANEL_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PANEL_DIR"
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install flask flask-socketio eventlet discord.py -q
log "Python packages installed"

step "6. Web Panel Service"
cat > /etc/systemd/system/denizhosting.service << EOF
[Unit]
Description=DenizHosting Web Panel
After=network.target lxc-net.service

[Service]
Type=simple
User=root
WorkingDirectory=${PANEL_DIR}
ExecStart=${PANEL_DIR}/venv/bin/python3 app.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

step "7. Discord Bot Service"
cat > /etc/systemd/system/denizbot.service << EOF
[Unit]
Description=DenizHosting Discord Bot (LXC)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${PANEL_DIR}
ExecStart=${PANEL_DIR}/venv/bin/python3 bot.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable denizhosting denizbot
log "Services registered"

step "8. Firewall"
iptables -I INPUT -p tcp --dport 8000 -j ACCEPT 2>/dev/null || true
log "Port 8000 opened"

step "9. Starting Panel"
systemctl start denizhosting || true
sleep 3
SERVER_IP=$(curl -4sSL ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║  ✅  DenizHosting Setup Complete!            ║${NC}"
echo -e "${BOLD}╠══════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  🌐  http://${GREEN}${SERVER_IP}:8000${NC}"
echo -e "${BOLD}║  👑  First user to register = Owner/Admin    ║${NC}"
echo -e "${BOLD}╠══════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  systemctl status denizhosting   (panel)     ║${NC}"
echo -e "${BOLD}║  systemctl status denizbot       (bot)       ║${NC}"
echo -e "${BOLD}║  journalctl -fu denizhosting     (logs)      ║${NC}"
echo -e "${BOLD}╠══════════════════════════════════════════════╣${NC}"
echo -e "${BOLD}║  ☁️  Cloudflare Tunnel:                      ║${NC}"
echo -e "${BOLD}║  cloudflared tunnel --url http://localhost:8000${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════╝${NC}"

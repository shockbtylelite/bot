"""
DenizHosting Panel v2.0 — Flask + LXC + SocketIO
Credits | Expiry | WorkMode | Bans | Events | 100+ Features
"""
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_socketio import SocketIO, emit, join_room
import sqlite3, hashlib, os, subprocess, threading, time, json, re, pty, select, struct, fcntl, termios, math

app = Flask(__name__)
app.secret_key = "denizhosting-v2-secret-2024"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

DB = "deniz.db"
PANEL_NAME = "DenizHosting"
SIGNUP_CREDITS = 100

# ─── DB ───────────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            credits REAL DEFAULT 100,
            is_banned INTEGER DEFAULT 0,
            ban_reason TEXT DEFAULT '',
            avatar_color TEXT DEFAULT '#3b82f6',
            bio TEXT DEFAULT '',
            last_seen INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS vps_listings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            owner_id INTEGER,
            cores INTEGER DEFAULT 1,
            ram_mb INTEGER DEFAULT 512,
            disk_gb INTEGER DEFAULT 10,
            os TEXT DEFAULT 'ubuntu:jammy',
            price REAL DEFAULT 0,
            credit_cost REAL DEFAULT 0,
            is_free INTEGER DEFAULT 1,
            max_slots INTEGER DEFAULT 1,
            sold_slots INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            expiry_value INTEGER DEFAULT 0,
            expiry_unit TEXT DEFAULT 'never',
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS vps_instances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            listing_id INTEGER,
            lxc_name TEXT UNIQUE NOT NULL,
            display_name TEXT DEFAULT '',
            status TEXT DEFAULT 'installing',
            sshx_url TEXT DEFAULT '',
            tmate_ssh TEXT DEFAULT '',
            cores INTEGER DEFAULT 1,
            ram_mb INTEGER DEFAULT 512,
            disk_gb INTEGER DEFAULT 10,
            os TEXT DEFAULT 'ubuntu:jammy',
            notes TEXT DEFAULT '',
            tags TEXT DEFAULT '',
            is_suspended INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s','now')),
            expires_at INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            listing_id INTEGER,
            vps_id INTEGER,
            amount REAL DEFAULT 0,
            credits_used REAL DEFAULT 0,
            email TEXT,
            first_name TEXT,
            last_name TEXT,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS install_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER,
            line TEXT,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS credit_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            reason TEXT,
            admin_id INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT DEFAULT 'info',
            title TEXT,
            message TEXT,
            user_id INTEGER DEFAULT 0,
            is_global INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS support_tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            subject TEXT,
            message TEXT,
            status TEXT DEFAULT 'open',
            reply TEXT DEFAULT '',
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            message TEXT,
            type TEXT DEFAULT 'info',
            is_active INTEGER DEFAULT 1,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        );
        INSERT OR IGNORE INTO settings (key,value) VALUES ('work_mode','0');
        INSERT OR IGNORE INTO settings (key,value) VALUES ('panel_name','DenizHosting');
        INSERT OR IGNORE INTO settings (key,value) VALUES ('signup_credits','100');
        INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance_msg','We are currently under maintenance. Please come back later.');
        """)

def hash_pw(pw): return hashlib.sha256(pw.encode()).hexdigest()

def current_user():
    if "user_id" not in session: return None
    with get_db() as db:
        return db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

def is_admin():
    u = current_user()
    return u and u["role"] in ("admin","owner")

def is_owner():
    u = current_user()
    return u and u["role"] == "owner"

def get_setting(key, default=""):
    with get_db() as db:
        r = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

def set_setting(key, value):
    with get_db() as db:
        db.execute("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)", (key, str(value)))

def add_event(type_, title, message, user_id=0, is_global=0):
    with get_db() as db:
        db.execute("INSERT INTO events (type,title,message,user_id,is_global) VALUES (?,?,?,?,?)",
                   (type_, title, message, user_id, is_global))
    socketio.emit("new_event", {"type": type_, "title": title, "message": message,
                                "time": time.strftime("%H:%M")})

def add_credits(user_id, amount, reason="", admin_id=0):
    with get_db() as db:
        db.execute("UPDATE users SET credits=credits+? WHERE id=?", (amount, user_id))
        db.execute("INSERT INTO credit_transactions (user_id,amount,reason,admin_id) VALUES (?,?,?,?)",
                   (user_id, amount, reason, admin_id))

def format_expiry(value, unit):
    if unit == "never" or value == 0: return "Never"
    units = {"min": "minute","hour": "hour","day": "day","week": "week","month": "month","year": "year"}
    u = units.get(unit, unit)
    return f"{value} {u}{'s' if value != 1 else ''}"

def calc_expires_at(value, unit):
    if unit == "never" or not value: return 0
    secs = {"min":60,"hour":3600,"day":86400,"week":604800,"month":2592000,"year":31536000}
    return int(time.time()) + (int(value) * secs.get(unit, 0))

def fmt_credits(c):
    if c >= 999999: return "∞"
    return f"{c:,.0f}"

# ─── CONTEXT PROCESSOR ────────────────────────────────────────────────────────
@app.context_processor
def inject_globals():
    if "user_id" not in session:
        return {"vpses":[],"is_admin":False,"is_owner_role":False,"work_mode":False,
                "panel_name":get_setting("panel_name","DenizHosting"),"unread_events":0,
                "current_user_obj":None}
    try:
        with get_db() as db:
            vpses = db.execute(
                "SELECT * FROM vps_instances WHERE user_id=? ORDER BY id DESC",
                (session["user_id"],)).fetchall()
            unread = db.execute(
                "SELECT COUNT(*) as c FROM events WHERE (user_id=? OR is_global=1) AND created_at > ?",
                (session["user_id"], int(time.time())-86400)).fetchone()["c"]
        u = current_user()
        work_mode = get_setting("work_mode","0") == "1"
        return {"vpses": vpses, "is_admin": bool(u and u["role"] in ("admin","owner")),
                "is_owner_role": bool(u and u["role"] == "owner"),
                "work_mode": work_mode, "current_user_obj": u,
                "panel_name": get_setting("panel_name","DenizHosting"),
                "unread_events": unread, "fmt_credits": fmt_credits}
    except:
        return {"vpses":[],"is_admin":False,"is_owner_role":False,"work_mode":False,
                "panel_name":"DenizHosting","unread_events":0,"current_user_obj":None,
                "fmt_credits": fmt_credits}

# ─── LXC HELPERS ──────────────────────────────────────────────────────────────
def lxc_run(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"

def lxc_exec(name, cmd, timeout=60):
    return lxc_run(f"lxc-attach -n {shq(name)} -- bash -c {shq(cmd)}", timeout=timeout)

def shq(s): return "'" + s.replace("'", "'\\''") + "'"

def lxc_is_running(name):
    _, out, _ = lxc_run(f"lxc-info -n {shq(name)} -s 2>/dev/null", timeout=5)
    return "RUNNING" in out

def lxc_ip(name):
    _, out, _ = lxc_run(f"lxc-info -n {shq(name)} -iH 2>/dev/null", timeout=5)
    ips = [x.strip() for x in out.strip().splitlines()
           if x.strip() and not x.strip().startswith("fe80")]
    return ips[0] if ips else ""

OS_OPTIONS = {
    "ubuntu:jammy":    "Ubuntu 22.04",
    "ubuntu:focal":    "Ubuntu 20.04",
    "debian:bookworm": "Debian 12",
    "debian:bullseye": "Debian 11",
}

def add_install_log(vps_id, line):
    try:
        with get_db() as db:
            db.execute("INSERT INTO install_logs (vps_id,line) VALUES (?,?)", (vps_id, line))
        socketio.emit("install_log", {"line": line}, room=f"vps_{vps_id}")
    except: pass

def set_vps_status(vps_id, status):
    try:
        with get_db() as db:
            db.execute("UPDATE vps_instances SET status=? WHERE id=?", (status, vps_id))
        socketio.emit("status_change", {"status": status}, room=f"vps_{vps_id}")
    except: pass

def create_lxc_vps(vps_id, lxc_name, os_str, cores, ram_mb, disk_gb):
    parts = os_str.split(":")
    dist = parts[0]; ver = parts[1] if len(parts) > 1 else "jammy"
    def log(msg): add_install_log(vps_id, msg); print(f"[VPS {vps_id}] {msg}")
    try:
        lxc_run(f"lxc-destroy -n {shq(lxc_name)} -f 2>/dev/null || true", timeout=15)
        log(f"📦 Creating LXC container: {lxc_name}")
        rc, out, err = lxc_run(
            f"lxc-create -t download -n {shq(lxc_name)} -- -d {dist} -r {ver} -a amd64 2>&1",
            timeout=300)
        if rc != 0:
            log(f"❌ lxc-create failed: {(out+err)[:400]}")
            set_vps_status(vps_id, "error"); return
        cfg = f"/var/lib/lxc/{lxc_name}/config"
        if os.path.exists(cfg):
            with open(cfg, "a") as f:
                f.write(f"\nlxc.cgroup2.memory.max = {ram_mb}M\n")
                if cores > 1: f.write(f"lxc.cgroup2.cpuset.cpus = 0-{cores-1}\n")
        log("▶️  Starting container...")
        lxc_run(f"lxc-start -n {shq(lxc_name)} -d 2>&1", timeout=30)
        time.sleep(4)
        for i in range(20):
            rc2, _, _ = lxc_exec(lxc_name, "echo ready", timeout=8)
            if rc2 == 0: break
            time.sleep(2)
        log("✅ Container is up! Running setup commands...")
        commands = [
            ("apt-get update -y 2>&1 | tail -3", "📦 Updating package lists..."),
            ("DEBIAN_FRONTEND=noninteractive apt-get upgrade -y 2>&1 | tail -3", "⬆️  Upgrading packages..."),
            ("DEBIAN_FRONTEND=noninteractive apt-get install -y curl wget git vim nano htop net-tools screenfetch ca-certificates unzip neofetch 2>&1 | tail -5", "📦 Installing base tools..."),
            ("apt-get update -y 2>&1 | tail -2", "📦 Refreshing..."),
            ("apt-get update -y >/dev/null 2>&1; command -v sshx >/dev/null 2>&1 || curl -sSf https://sshx.io/get | sh; echo sshx_done", "🌐 Installing sshx..."),
            ("DEBIAN_FRONTEND=noninteractive apt-get install -y tmate 2>&1 | tail -3 || true", "🖥️  Installing tmate..."),
        ]
        for cmd, label in commands:
            log(label)
            rc3, out3, err3 = lxc_exec(lxc_name, cmd, timeout=300)
            last = (out3+err3).strip().split("\n")
            if last and last[-1].strip(): log(last[-1].strip()[:200])
        log("✅ All done! VPS is ready.")
        set_vps_status(vps_id, "running")
        log("🎉 Have a nice day!")
        with get_db() as db:
            vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
        if vps:
            add_event("success", "VPS Ready", f"Your VPS '{vps['display_name']}' is ready!", vps["user_id"])
    except Exception as e:
        log(f"❌ Fatal error: {e}")
        set_vps_status(vps_id, "error")

# ─── EXPIRY CHECKER ───────────────────────────────────────────────────────────
def expiry_checker():
    while True:
        try:
            now = int(time.time())
            with get_db() as db:
                expired = db.execute(
                    "SELECT * FROM vps_instances WHERE expires_at > 0 AND expires_at < ? AND status != 'deleted'",
                    (now,)).fetchall()
            for vps in expired:
                lxc_run(f"lxc-stop -n {shq(vps['lxc_name'])} -k 2>/dev/null || true", timeout=15)
                lxc_run(f"lxc-destroy -n {shq(vps['lxc_name'])} -f 2>/dev/null || true", timeout=15)
                with get_db() as db:
                    db.execute("UPDATE vps_instances SET status='expired' WHERE id=?", (vps["id"],))
                add_event("warning", "VPS Expired",
                          f"VPS '{vps['display_name']}' has expired and been stopped.",
                          vps["user_id"])
                socketio.emit("status_change", {"status":"expired"}, room=f"vps_{vps['id']}")
        except: pass
        time.sleep(60)

threading.Thread(target=expiry_checker, daemon=True).start()

# ─── AUTH ─────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    if "user_id" not in session: return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email","").strip()
        pw    = request.form.get("password","").strip()
        with get_db() as db:
            u = db.execute("SELECT * FROM users WHERE email=? AND password=?",
                           (email, hash_pw(pw))).fetchone()
        if u:
            if u["is_banned"]:
                flash(f"Account banned: {u['ban_reason'] or 'Contact support.'}", "error")
                return render_template("login.html")
            session["user_id"] = u["id"]
            with get_db() as db:
                db.execute("UPDATE users SET last_seen=? WHERE id=?", (int(time.time()), u["id"]))
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        email    = request.form.get("email","").strip()
        pw       = request.form.get("password","").strip()
        if not username or not email or not pw:
            flash("All fields required.", "error")
            return render_template("register.html")
        try:
            signup_credits = float(get_setting("signup_credits","100"))
        except: signup_credits = 100
        with get_db() as db:
            count = db.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
            role  = "owner" if count == 0 else "user"
            credits = 999999999 if role == "owner" else signup_credits
            try:
                db.execute("INSERT INTO users (username,email,password,role,credits) VALUES (?,?,?,?,?)",
                           (username, email, hash_pw(pw), role, credits))
                u = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
                session["user_id"] = u["id"]
                if role == "owner":
                    flash("Welcome Owner! You have unlimited credits. 👑", "success")
                else:
                    flash(f"Welcome {username}! You received {int(signup_credits)} free credits! 🎉", "success")
                add_event("info","New User",f"{username} joined the panel!",u["id"],1)
                return redirect(url_for("dashboard"))
            except sqlite3.IntegrityError:
                flash("Username or email already taken.", "error")
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

# ─── DASHBOARD ────────────────────────────────────────────────────────────────
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        vpses    = db.execute("SELECT * FROM vps_instances WHERE user_id=? ORDER BY id DESC", (u["id"],)).fetchall()
        shop     = db.execute("""SELECT vl.*,u.username as owner_name FROM vps_listings vl
                                 LEFT JOIN users u ON vl.owner_id=u.id
                                 WHERE vl.is_active=1 ORDER BY vl.id DESC LIMIT 6""").fetchall()
        u_count  = db.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
        v_count  = db.execute("SELECT COUNT(*) as c FROM vps_instances").fetchone()["c"]
        events   = db.execute("""SELECT * FROM events WHERE (user_id=? OR is_global=1)
                                 ORDER BY id DESC LIMIT 10""", (u["id"],)).fetchall()
        anns     = db.execute("SELECT * FROM announcements WHERE is_active=1 ORDER BY id DESC LIMIT 3").fetchall()
    return render_template("dashboard.html", user=u, shop=shop, vpses=vpses,
                           user_count=u_count, vps_count=v_count,
                           events=events, announcements=anns,
                           os_options=OS_OPTIONS, fmt_credits=fmt_credits)

# ─── VPS CREATE (direct) ──────────────────────────────────────────────────────
@app.route("/vps/create", methods=["POST"])
def vps_create():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    name    = re.sub(r"[^a-z0-9\-]","-",request.form.get("name","myserver").lower())[:24] or "myserver"
    cores   = min(int(request.form.get("cores",1) or 1),8)
    ram_mb  = min(int(request.form.get("ram",512) or 512),8192)
    disk_gb = min(int(request.form.get("disk",10) or 10),200)
    os_str  = request.form.get("os","ubuntu:jammy")
    target_uid = int(request.form.get("target_user") or u["id"]) if is_admin() else u["id"]
    if os_str not in OS_OPTIONS: os_str = "ubuntu:jammy"
    lxc_name = f"d{target_uid}-{name}-{int(time.time())%9999}"
    with get_db() as db:
        db.execute("""INSERT INTO vps_instances
            (user_id,lxc_name,display_name,status,cores,ram_mb,disk_gb,os)
            VALUES (?,?,?,?,?,?,?,?)""",
            (target_uid,lxc_name,name,"installing",cores,ram_mb,disk_gb,os_str))
        vps_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
    threading.Thread(target=create_lxc_vps,
                     args=(vps_id,lxc_name,os_str,cores,ram_mb,disk_gb),daemon=True).start()
    flash(f"VPS '{name}' is being created!", "success")
    return redirect(url_for("vps_panel", vps_id=vps_id))

# ─── VPS PANEL ────────────────────────────────────────────────────────────────
@app.route("/vps/<int:vps_id>")
def vps_panel(vps_id):
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        vps  = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
        logs = db.execute("SELECT line FROM install_logs WHERE vps_id=? ORDER BY id ASC LIMIT 500",
                          (vps_id,)).fetchall()
    if not vps: flash("VPS not found.","error"); return redirect(url_for("dashboard"))
    if vps["user_id"] != u["id"] and not is_admin():
        flash("Access denied.","error"); return redirect(url_for("dashboard"))
    running = lxc_is_running(vps["lxc_name"])
    ip = lxc_ip(vps["lxc_name"])
    expires_in = ""
    if vps["expires_at"] > 0:
        diff = vps["expires_at"] - int(time.time())
        if diff > 0:
            d,r = divmod(diff,86400); h,r2 = divmod(r,3600); m = r2//60
            if d: expires_in = f"{d}d {h}h"
            elif h: expires_in = f"{h}h {m}m"
            else: expires_in = f"{m}m"
        else: expires_in = "Expired"
    return render_template("vps_panel.html", vps=vps, user=u,
                           running=running, ip=ip, logs=[r["line"] for r in logs],
                           os_options=OS_OPTIONS, expires_in=expires_in)

# ─── VPS ACTIONS ──────────────────────────────────────────────────────────────
@app.route("/vps/<int:vps_id>/start", methods=["POST"])
def vps_start(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False,"msg":"Not found"})
    if vps["is_suspended"]: return jsonify({"ok":False,"msg":"VPS is suspended by admin"})
    rc,out,err = lxc_run(f"lxc-start -n {shq(vps['lxc_name'])} -d 2>&1", timeout=15)
    with get_db() as db:
        db.execute("UPDATE vps_instances SET status='running' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Started ✅"})

@app.route("/vps/<int:vps_id>/stop", methods=["POST"])
def vps_stop(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_run(f"lxc-stop -n {shq(vps['lxc_name'])} -k 2>&1", timeout=15)
    with get_db() as db:
        db.execute("UPDATE vps_instances SET status='stopped' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Stopped ⏹️"})

@app.route("/vps/<int:vps_id>/restart", methods=["POST"])
def vps_restart(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_run(f"lxc-stop -n {shq(vps['lxc_name'])} -k 2>&1", timeout=15)
    time.sleep(1)
    lxc_run(f"lxc-start -n {shq(vps['lxc_name'])} -d 2>&1", timeout=15)
    with get_db() as db:
        db.execute("UPDATE vps_instances SET status='running' WHERE id=?", (vps_id,))
    return jsonify({"ok":True,"msg":"Restarted 🔄"})

@app.route("/vps/<int:vps_id>/exec", methods=["POST"])
def vps_exec(vps_id):
    if "user_id" not in session: return jsonify({"ok":False,"output":"Not logged in"})
    u = current_user()
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False,"output":"VPS not found"})
    if vps["user_id"] != u["id"] and not is_admin():
        return jsonify({"ok":False,"output":"Access denied"})
    if vps["is_suspended"]: return jsonify({"ok":False,"output":"VPS is suspended"})
    if not lxc_is_running(vps["lxc_name"]):
        return jsonify({"ok":False,"output":"Container not running — start it first"})
    cmd = (request.json or {}).get("cmd","").strip()
    if not cmd: return jsonify({"ok":True,"output":""})
    rc,out,err = lxc_exec(vps["lxc_name"], f"TERM=xterm-256color {cmd}", timeout=30)
    return jsonify({"ok":rc==0,"output":(out+err).strip()[:4000],"rc":rc})

@app.route("/vps/<int:vps_id>/screenfetch", methods=["POST"])
def vps_screenfetch(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    rc,out,err = lxc_exec(vps["lxc_name"],
        "neofetch --stdout 2>/dev/null || screenfetch -N 2>/dev/null || uname -a && cat /etc/os-release 2>/dev/null",
        timeout=15)
    return jsonify({"ok":True,"output":(out+err).strip()[:3000]})

@app.route("/vps/<int:vps_id>/sshx", methods=["POST"])
def vps_sshx(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    if vps["sshx_url"]: return jsonify({"ok":True,"url":vps["sshx_url"]})
    lxc_exec(vps["lxc_name"],"pkill -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true",timeout=5)
    lxc_exec(vps["lxc_name"],
        "apt-get update -y >/dev/null 2>&1; command -v sshx >/dev/null 2>&1 || curl -sSf https://sshx.io/get | sh; nohup sshx > /tmp/sshx.log 2>&1 & disown",
        timeout=30)
    for _ in range(25):
        time.sleep(2)
        _,log_out,_ = lxc_exec(vps["lxc_name"],"cat /tmp/sshx.log 2>/dev/null",timeout=8)
        m = re.search(r"https://sshx\.io/s/[\w#/=+\-]+", log_out)
        if m:
            url = m.group(0).rstrip("/")
            with get_db() as db:
                db.execute("UPDATE vps_instances SET sshx_url=? WHERE id=?", (url,vps_id))
            return jsonify({"ok":True,"url":url})
    return jsonify({"ok":False,"msg":"sshx not responding"})

@app.route("/vps/<int:vps_id>/tmate", methods=["POST"])
def vps_tmate(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    lxc_exec(vps["lxc_name"],"pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true",timeout=5)
    lxc_exec(vps["lxc_name"],"tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true",timeout=15)
    time.sleep(6)
    ssh_line = web_link = ""
    for _ in range(6):
        _,out,_ = lxc_exec(vps["lxc_name"],"tmate -S /tmp/tmate.sock show-messages 2>&1",timeout=8)
        sm = re.search(r"ssh\s+\S+@\S+", out)
        wm = re.search(r"https://tmate\.io/t/\S+", out)
        if sm: ssh_line = sm.group(0)
        if wm: web_link = wm.group(0)
        if ssh_line or web_link: break
        time.sleep(2)
    if ssh_line:
        with get_db() as db:
            db.execute("UPDATE vps_instances SET tmate_ssh=? WHERE id=?", (ssh_line,vps_id))
    return jsonify({"ok":bool(ssh_line or web_link),"ssh":ssh_line,"web":web_link})

@app.route("/vps/<int:vps_id>/status")
def vps_status_api(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    running = lxc_is_running(vps["lxc_name"])
    ip = lxc_ip(vps["lxc_name"])
    return jsonify({"ok":True,"status":vps["status"],"running":running,"ip":ip})

@app.route("/vps/<int:vps_id>/notes", methods=["POST"])
def vps_notes(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    notes = (request.json or {}).get("notes","")[:500]
    with get_db() as db:
        db.execute("UPDATE vps_instances SET notes=? WHERE id=?", (notes,vps_id))
    return jsonify({"ok":True})

@app.route("/vps/<int:vps_id>/delete", methods=["POST"])
def vps_delete(vps_id):
    if "user_id" not in session: return jsonify({"ok":False})
    u = current_user()
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps: return jsonify({"ok":False})
    if vps["user_id"] != u["id"] and not is_admin():
        return jsonify({"ok":False,"msg":"Access denied"})
    lxc_run(f"lxc-stop -n {shq(vps['lxc_name'])} -k 2>/dev/null; lxc-destroy -n {shq(vps['lxc_name'])} -f 2>/dev/null; true",timeout=30)
    with get_db() as db:
        db.execute("DELETE FROM vps_instances WHERE id=?", (vps_id,))
        db.execute("DELETE FROM install_logs WHERE vps_id=?", (vps_id,))
    return jsonify({"ok":True})

# ─── SHOP ─────────────────────────────────────────────────────────────────────
@app.route("/shop")
def shop():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        listings = db.execute("""SELECT vl.*,u.username as owner_name
                                 FROM vps_listings vl LEFT JOIN users u ON vl.owner_id=u.id
                                 WHERE vl.is_active=1 ORDER BY vl.id DESC""").fetchall()
    return render_template("shop.html", user=u, listings=listings,
                           os_options=OS_OPTIONS, fmt_credits=fmt_credits)

@app.route("/shop/create", methods=["GET","POST"])
def shop_create():
    if "user_id" not in session: return redirect(url_for("login"))
    if not is_admin(): flash("Admins only.","error"); return redirect(url_for("shop"))
    if request.method == "POST":
        step = int(request.form.get("step",1))
        if step == 3:
            u = current_user()
            name       = re.sub(r"[^a-zA-Z0-9 _\-]","",request.form.get("name","VPS Plan"))[:60]
            cores      = min(int(request.form.get("cores",1) or 1),16)
            ram_mb     = min(int(request.form.get("ram",512) or 512),16384)
            disk_gb    = min(int(request.form.get("disk",10) or 10),500)
            os_str     = request.form.get("os","ubuntu:jammy")
            is_free    = 1 if request.form.get("is_free","1") == "1" else 0
            credit_cost = float(request.form.get("credit_cost",0) or 0)
            max_slots  = max(1,int(request.form.get("max_slots",1) or 1))
            desc       = request.form.get("description","")[:300]
            expiry_value = int(request.form.get("expiry_value",0) or 0)
            expiry_unit  = request.form.get("expiry_unit","never")
            with get_db() as db:
                db.execute("""INSERT INTO vps_listings
                    (name,description,owner_id,cores,ram_mb,disk_gb,os,is_free,credit_cost,max_slots,expiry_value,expiry_unit)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (name,desc,u["id"],cores,ram_mb,disk_gb,os_str,is_free,credit_cost,max_slots,expiry_value,expiry_unit))
            flash(f"'{name}' is now live in the shop!","success")
            add_event("info","New Shop Listing",f"'{name}' was added to the shop",u["id"],1)
            return redirect(url_for("shop"))
        return render_template("shop_create.html", user=current_user(), step=step+1,
                               form_data=request.form, os_options=OS_OPTIONS)
    return render_template("shop_create.html", user=current_user(), step=1,
                           form_data={}, os_options=OS_OPTIONS)

@app.route("/shop/buy/<int:listing_id>", methods=["GET","POST"])
def shop_buy(listing_id):
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        listing = db.execute("SELECT * FROM vps_listings WHERE id=? AND is_active=1", (listing_id,)).fetchone()
    if not listing: flash("Listing not found.","error"); return redirect(url_for("shop"))
    if listing["sold_slots"] >= listing["max_slots"]:
        flash("Sold out!","error"); return redirect(url_for("shop"))
    # Credit check
    if not listing["is_free"] and listing["credit_cost"] > 0:
        if u["role"] not in ("admin","owner") and u["credits"] < listing["credit_cost"]:
            flash(f"Not enough credits! You need {listing['credit_cost']} credits.","error")
            return redirect(url_for("shop"))
    if request.method == "POST":
        email      = request.form.get("email","").strip()
        first_name = request.form.get("first_name","").strip()
        last_name  = request.form.get("last_name","").strip()
        if not email or not first_name or not last_name:
            flash("All fields required.","error")
            return render_template("payment.html", user=u, listing=listing, os_options=OS_OPTIONS)
        # Deduct credits
        credits_used = 0
        if not listing["is_free"] and listing["credit_cost"] > 0 and u["role"] not in ("admin","owner"):
            credits_used = listing["credit_cost"]
            add_credits(u["id"], -credits_used, f"Purchased VPS: {listing['name']}")
        lxc_name = f"d{u['id']}-shop{listing_id}-{int(time.time())%9999}"
        expires_at = calc_expires_at(listing["expiry_value"], listing["expiry_unit"])
        with get_db() as db:
            db.execute("""INSERT INTO vps_instances
                (user_id,listing_id,lxc_name,display_name,status,cores,ram_mb,disk_gb,os,expires_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (u["id"],listing_id,lxc_name,listing["name"],"installing",
                 listing["cores"],listing["ram_mb"],listing["disk_gb"],listing["os"],expires_at))
            vps_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
            db.execute("""INSERT INTO purchases
                (user_id,listing_id,vps_id,amount,credits_used,email,first_name,last_name)
                VALUES (?,?,?,?,?,?,?,?)""",
                (u["id"],listing_id,vps_id,0,credits_used,email,first_name,last_name))
            db.execute("UPDATE vps_listings SET sold_slots=sold_slots+1 WHERE id=?", (listing_id,))
        threading.Thread(target=create_lxc_vps,
            args=(vps_id,lxc_name,listing["os"],listing["cores"],listing["ram_mb"],listing["disk_gb"]),
            daemon=True).start()
        flash("Purchase complete! Your VPS is being set up.","success")
        return redirect(url_for("vps_panel", vps_id=vps_id))
    return render_template("payment.html", user=u, listing=listing, os_options=OS_OPTIONS)

# ─── CREDITS ──────────────────────────────────────────────────────────────────
@app.route("/credits")
def credits_page():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        txns = db.execute("SELECT * FROM credit_transactions WHERE user_id=? ORDER BY id DESC LIMIT 50",
                          (u["id"],)).fetchall()
    return render_template("credits.html", user=u, transactions=txns, fmt_credits=fmt_credits)

# ─── EVENTS ───────────────────────────────────────────────────────────────────
@app.route("/events")
def events_page():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    with get_db() as db:
        events = db.execute("""SELECT * FROM events WHERE user_id=? OR is_global=1
                               ORDER BY id DESC LIMIT 100""", (u["id"],)).fetchall()
    return render_template("events.html", user=u, events=events)

# ─── SUPPORT ──────────────────────────────────────────────────────────────────
@app.route("/support", methods=["GET","POST"])
def support():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    if request.method == "POST":
        subj = request.form.get("subject","").strip()[:100]
        msg  = request.form.get("message","").strip()[:2000]
        if subj and msg:
            with get_db() as db:
                db.execute("INSERT INTO support_tickets (user_id,subject,message) VALUES (?,?,?)",
                           (u["id"],subj,msg))
            flash("Support ticket submitted!","success")
            add_event("info","New Ticket",f"{u['username']} opened ticket: {subj}",u["id"],0)
    with get_db() as db:
        tickets = db.execute("SELECT * FROM support_tickets WHERE user_id=? ORDER BY id DESC",
                             (u["id"],)).fetchall()
    return render_template("support.html", user=u, tickets=tickets)

# ─── PROFILE ──────────────────────────────────────────────────────────────────
@app.route("/profile", methods=["GET","POST"])
def profile():
    if "user_id" not in session: return redirect(url_for("login"))
    u = current_user()
    if request.method == "POST":
        bio   = request.form.get("bio","").strip()[:200]
        color = request.form.get("avatar_color","#3b82f6")
        with get_db() as db:
            db.execute("UPDATE users SET bio=?,avatar_color=? WHERE id=?", (bio,color,u["id"]))
        flash("Profile updated!","success")
        return redirect(url_for("profile"))
    with get_db() as db:
        txns = db.execute("SELECT * FROM credit_transactions WHERE user_id=? ORDER BY id DESC LIMIT 10",
                          (u["id"],)).fetchall()
    return render_template("profile.html", user=u, transactions=txns, fmt_credits=fmt_credits)

# ─── ADMIN ────────────────────────────────────────────────────────────────────
@app.route("/admin")
def admin():
    if not is_admin(): return redirect(url_for("dashboard"))
    with get_db() as db:
        users    = db.execute("SELECT * FROM users ORDER BY id").fetchall()
        vpses    = db.execute("""SELECT vi.*,u.username FROM vps_instances vi
                                 LEFT JOIN users u ON vi.user_id=u.id ORDER BY vi.id DESC""").fetchall()
        listings = db.execute("SELECT * FROM vps_listings ORDER BY id DESC").fetchall()
        tickets  = db.execute("""SELECT st.*,u.username FROM support_tickets st
                                 LEFT JOIN users u ON st.user_id=u.id ORDER BY st.id DESC""").fetchall()
        events   = db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 50").fetchall()
        anns     = db.execute("SELECT * FROM announcements ORDER BY id DESC").fetchall()
    work_mode = get_setting("work_mode","0") == "1"
    panel_name = get_setting("panel_name","DenizHosting")
    signup_creds = get_setting("signup_credits","100")
    maint_msg = get_setting("maintenance_msg","")
    return render_template("admin.html", user=current_user(),
                           users=users, vpses=vpses, listings=listings,
                           tickets=tickets, events=events, announcements=anns,
                           work_mode=work_mode, panel_name=panel_name,
                           signup_credits=signup_creds, maintenance_msg=maint_msg,
                           fmt_credits=fmt_credits)

@app.route("/admin/workmode", methods=["POST"])
def admin_workmode():
    if not is_owner(): return jsonify({"ok":False})
    val = request.json.get("enabled", False)
    set_setting("work_mode", "1" if val else "0")
    socketio.emit("work_mode_change", {"enabled": val})
    return jsonify({"ok":True})

@app.route("/admin/settings", methods=["POST"])
def admin_settings():
    if not is_owner(): return jsonify({"ok":False})
    for key in ["panel_name","signup_credits","maintenance_msg"]:
        val = request.form.get(key)
        if val is not None: set_setting(key, val)
    flash("Settings saved!","success")
    return redirect(url_for("admin"))

@app.route("/admin/user/<int:uid>/ban", methods=["POST"])
def admin_ban(uid):
    if not is_admin(): return jsonify({"ok":False})
    reason = (request.json or {}).get("reason","No reason given")
    with get_db() as db:
        db.execute("UPDATE users SET is_banned=1,ban_reason=? WHERE id=?", (reason,uid))
    return jsonify({"ok":True})

@app.route("/admin/user/<int:uid>/unban", methods=["POST"])
def admin_unban(uid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        db.execute("UPDATE users SET is_banned=0,ban_reason='' WHERE id=?", (uid,))
    return jsonify({"ok":True})

@app.route("/admin/user/<int:uid>/credits", methods=["POST"])
def admin_credits(uid):
    if not is_admin(): return jsonify({"ok":False})
    amount = float((request.json or {}).get("amount",0))
    reason = (request.json or {}).get("reason","Admin grant")
    u = current_user()
    add_credits(uid, amount, reason, u["id"])
    return jsonify({"ok":True})

@app.route("/admin/user/<int:uid>/role", methods=["POST"])
def admin_role(uid):
    if not is_owner(): return jsonify({"ok":False})
    role = (request.form or request.json or {}).get("role","user")
    with get_db() as db:
        db.execute("UPDATE users SET role=? WHERE id=?", (role,uid))
    return jsonify({"ok":True})

@app.route("/admin/vps/<int:vid>/suspend", methods=["POST"])
def admin_suspend(vid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vid,)).fetchone()
        db.execute("UPDATE vps_instances SET is_suspended=1 WHERE id=?", (vid,))
    if vps: lxc_run(f"lxc-stop -n {shq(vps['lxc_name'])} -k 2>/dev/null || true",timeout=15)
    return jsonify({"ok":True})

@app.route("/admin/vps/<int:vid>/unsuspend", methods=["POST"])
def admin_unsuspend(vid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        db.execute("UPDATE vps_instances SET is_suspended=0 WHERE id=?", (vid,))
    return jsonify({"ok":True})

@app.route("/admin/announce", methods=["POST"])
def admin_announce():
    if not is_admin(): return jsonify({"ok":False})
    title = request.form.get("title","").strip()[:100]
    msg   = request.form.get("message","").strip()[:500]
    atype = request.form.get("type","info")
    if title and msg:
        with get_db() as db:
            db.execute("INSERT INTO announcements (title,message,type) VALUES (?,?,?)", (title,msg,atype))
        add_event(atype, f"📢 {title}", msg, 0, 1)
        socketio.emit("announcement", {"title":title,"message":msg,"type":atype})
        flash("Announcement sent!","success")
    return redirect(url_for("admin"))

@app.route("/admin/announce/<int:aid>/delete", methods=["POST"])
def admin_del_announce(aid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        db.execute("DELETE FROM announcements WHERE id=?", (aid,))
    return jsonify({"ok":True})

@app.route("/admin/ticket/<int:tid>/reply", methods=["POST"])
def admin_ticket_reply(tid):
    if not is_admin(): return jsonify({"ok":False})
    reply = (request.json or {}).get("reply","").strip()[:1000]
    with get_db() as db:
        db.execute("UPDATE support_tickets SET reply=?,status='answered' WHERE id=?", (reply,tid))
        ticket = db.execute("SELECT * FROM support_tickets WHERE id=?", (tid,)).fetchone()
    if ticket:
        add_event("info","Support Reply",f"Your ticket has been answered!",ticket["user_id"])
    return jsonify({"ok":True})

@app.route("/admin/listing/<int:lid>/delete", methods=["POST"])
def admin_del_listing(lid):
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        db.execute("UPDATE vps_listings SET is_active=0 WHERE id=?", (lid,))
    return jsonify({"ok":True})

@app.route("/admin/stats")
def admin_stats():
    if not is_admin(): return jsonify({"ok":False})
    with get_db() as db:
        users = db.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
        vpses = db.execute("SELECT COUNT(*) as c FROM vps_instances").fetchone()["c"]
        running = db.execute("SELECT COUNT(*) as c FROM vps_instances WHERE status='running'").fetchone()["c"]
        tickets = db.execute("SELECT COUNT(*) as c FROM support_tickets WHERE status='open'").fetchone()["c"]
    return jsonify({"ok":True,"users":users,"vpses":vpses,"running":running,"open_tickets":tickets})

# ─── WEBSOCKET ────────────────────────────────────────────────────────────────
terminal_processes = {}

@socketio.on("join_vps")
def on_join_vps(data):
    join_room(f"vps_{data.get('vps_id')}")

@socketio.on("terminal_start")
def on_terminal_start(data):
    vps_id = data.get("vps_id")
    sid = request.sid
    with get_db() as db:
        vps = db.execute("SELECT * FROM vps_instances WHERE id=?", (vps_id,)).fetchone()
    if not vps:
        emit("terminal_output",{"data":"\r\n❌ VPS not found.\r\n"}); return
    if not lxc_is_running(vps["lxc_name"]):
        emit("terminal_output",{"data":"\r\n❌ Container not running.\r\n"}); return
    master_fd, slave_fd = pty.openpty()
    proc = subprocess.Popen(
        ["lxc-attach","-n",vps["lxc_name"],"--","/bin/bash"],
        stdin=slave_fd,stdout=slave_fd,stderr=slave_fd,preexec_fn=os.setsid)
    os.close(slave_fd)
    terminal_processes[sid] = {"proc":proc,"fd":master_fd}
    def reader():
        while True:
            try:
                r,_,_ = select.select([master_fd],[],[],0.1)
                if r:
                    d2 = os.read(master_fd,4096)
                    socketio.emit("terminal_output",{"data":d2.decode(errors="replace")},room=sid)
            except: break
        socketio.emit("terminal_output",{"data":"\r\n\033[31m[disconnected]\033[0m\r\n"},room=sid)
    threading.Thread(target=reader,daemon=True).start()

@socketio.on("terminal_input")
def on_terminal_input(data):
    sid = request.sid
    if sid in terminal_processes:
        try: os.write(terminal_processes[sid]["fd"], data["data"].encode())
        except: pass

@socketio.on("terminal_resize")
def on_terminal_resize(data):
    sid = request.sid
    if sid in terminal_processes:
        try:
            fcntl.ioctl(terminal_processes[sid]["fd"],termios.TIOCSWINSZ,
                struct.pack("HHHH",data.get("rows",24),data.get("cols",80),0,0))
        except: pass

@socketio.on("disconnect")
def on_disconnect():
    sid = request.sid
    if sid in terminal_processes:
        try: terminal_processes[sid]["proc"].kill(); os.close(terminal_processes[sid]["fd"])
        except: pass
        del terminal_processes[sid]

# ─── RUN ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    print("╔══════════════════════════════════════════════╗")
    print("║   DenizHosting v2.0  —  Port 8000  ✅        ║")
    print("╚══════════════════════════════════════════════╝")
    socketio.run(app, host="0.0.0.0", port=8000, debug=False, allow_unsafe_werkzeug=True)

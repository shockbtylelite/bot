"""
╔══════════════════════════════════════════════════════════════════╗
║          Dirt VPS Bot  v4.0  —  QEMU Backend                   ║
║  450+ commands  •  Button panels  •  Real KVM virtual machines  ║
╚══════════════════════════════════════════════════════════════════╝

DNS FIX (run on host if "name resolution" error):
    echo "nameserver 8.8.8.8" > /etc/resolv.conf
    echo "nameserver 8.8.4.4" >> /etc/resolv.conf

Install deps:
    apt install qemu-system-x86 qemu-utils cloud-image-utils genisoimage wget curl
    pip install discord.py
"""

import discord
from discord.ext import commands, tasks
from discord import ui
import json, os, asyncio, re, time, datetime, subprocess, shutil, hashlib, random, string

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG  ─  edit these
# ══════════════════════════════════════════════════════════════════════════════

BOT_TOKEN        = "MTQ4MDE2NTkzMDEwMDE5OTQyNA.GgNhIH.OjOmXUadE5BdwerPHbKy6yyI0J4h5vYE4HQVjg"
ADMIN_ROLE_ID    = 1478445114425606388
SUPPORT_ROLE_ID  = 1480193319341396128
DATA_FILE        = "vps_data.json"
CUSTOM_CMD_FILE  = "custom_commands.json"
SETTINGS_FILE    = "settings.json"
ALERTS_FILE      = "alerts.json"
SCHEDULES_FILE   = "schedules.json"

VM_DIR           = "/opt/vps-vms"
CACHE_DIR        = "/opt/vps-cache"
BACKUP_DIR       = "/opt/vps-backups"
SSH_PORT_BASE    = 10022
BOT_SSH_KEY      = "/opt/vps-vms/bot_key"
BOT_SSH_PUB      = "/opt/vps-vms/bot_key.pub"

DEFAULT_RAM_MB   = 1024
DEFAULT_CPUS     = 2
DEFAULT_DISK_GB  = 20
DEFAULT_EXPIRE_S = 30 * 24 * 3600
MAX_RAM_MB       = 16384
MAX_CPUS         = 16
MAX_DISK_GB      = 500

# Embed colors
C_BLUE  = 0x5865F2
C_GREEN = 0x57F287
C_RED   = 0xED4245
C_GOLD  = 0xF0A500
C_GREY  = 0x2F3136
C_TEAL  = 0x1ABC9C
C_PINK  = 0xFF73FA
C_ORG   = 0xFF7043

OS_OPTIONS = {
    "1": ("Ubuntu 24.04",   "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img",          "ubuntu"),
    "2": ("Ubuntu 22.04",   "https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img",          "ubuntu"),
    "3": ("Ubuntu 20.04",   "https://cloud-images.ubuntu.com/focal/current/focal-server-cloudimg-amd64.img",          "ubuntu"),
    "4": ("Debian 12",      "https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2",    "debian"),
    "5": ("Debian 11",      "https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-generic-amd64.qcow2",    "debian"),
    "6": ("Fedora 39",      "https://download.fedoraproject.org/pub/fedora/linux/releases/39/Cloud/x86_64/images/Fedora-Cloud-Base-39-1.5.x86_64.qcow2", "fedora"),
    "7": ("CentOS Stream 9","https://cloud.centos.org/centos/9-stream/x86_64/images/CentOS-Stream-GenericCloud-9-latest.x86_64.qcow2", "cloud-user"),
}

# Quick-install presets
PRESETS = {
    "lamp":    "apt-get install -y apache2 mysql-server php php-mysql libapache2-mod-php && systemctl enable apache2 mysql",
    "lemp":    "apt-get install -y nginx mysql-server php-fpm php-mysql && systemctl enable nginx mysql php8.1-fpm",
    "node":    "curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs && npm install -g pm2",
    "docker":  "curl -fsSL https://get.docker.com | sh && systemctl enable docker",
    "python":  "apt-get install -y python3 python3-pip python3-venv && pip3 install flask fastapi uvicorn gunicorn",
    "nginx":   "apt-get install -y nginx certbot python3-certbot-nginx && systemctl enable nginx",
    "mysql":   "apt-get install -y mysql-server && systemctl enable mysql && mysql_secure_installation",
    "redis":   "apt-get install -y redis-server && systemctl enable redis-server",
    "postgres":"apt-get install -y postgresql postgresql-contrib && systemctl enable postgresql",
    "mongodb": "curl -fsSL https://pgp.mongodb.com/server-7.0.asc | gpg -o /etc/apt/trusted.gpg.d/mongodb.gpg && echo 'deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse' | tee /etc/apt/sources.list.d/mongodb-org-7.0.list && apt-get update -qq && apt-get install -y mongodb-org && systemctl enable mongod",
    "pterodactyl": "bash <(curl -sSL https://pterodactyl-installer.se)",
    "cloudflared":  "curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared",
    "tailscale":"curl -fsSL https://tailscale.com/install.sh | sh",
    "caddy":   "apt-get install -y debian-keyring debian-archive-keyring apt-transport-https && curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg && curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list && apt-get update -qq && apt-get install -y caddy",
    "wireguard":"apt-get install -y wireguard && wg genkey | tee /etc/wireguard/private.key | wg pubkey > /etc/wireguard/public.key",
    "fail2ban": "apt-get install -y fail2ban && systemctl enable fail2ban",
    "netdata":  "bash <(curl -Ss https://my-netdata.io/kickstart.sh) --non-interactive",
    "grafana":  "apt-get install -y apt-transport-https software-properties-common && wget -q -O - https://packages.grafana.com/gpg.key | apt-key add - && add-apt-repository 'deb https://packages.grafana.com/oss/deb stable main' && apt-get update -qq && apt-get install -y grafana && systemctl enable grafana-server",
    "prometheus":"useradd --no-create-home --shell /bin/false prometheus && wget -q https://github.com/prometheus/prometheus/releases/download/v2.45.0/prometheus-2.45.0.linux-amd64.tar.gz -O /tmp/prom.tar.gz && tar xzf /tmp/prom.tar.gz -C /tmp/ && cp /tmp/prometheus-2.45.0.linux-amd64/prometheus /usr/local/bin/",
    "jenkins":  "curl -fsSL https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key | tee /usr/share/keyrings/jenkins-keyring.asc && echo deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/ | tee /etc/apt/sources.list.d/jenkins.list && apt-get update -qq && apt-get install -y jenkins",
    "gitea":    "wget -q https://dl.gitea.com/gitea/1.21.0/gitea-1.21.0-linux-amd64 -O /usr/local/bin/gitea && chmod +x /usr/local/bin/gitea",
    "minecraft":"apt-get install -y default-jre && wget -q https://piston-data.mojang.com/v1/objects/8dd1a28015f51b1803213892b50b7b4fc76e594d/server.jar -O /opt/minecraft-server.jar",
    "cs2":      "apt-get install -y steamcmd lib32gcc-s1 && steamcmd +force_install_dir /opt/cs2 +login anonymous +app_update 730 +quit",
    "rust":     "apt-get install -y lib32gcc-s1 && useradd -m -s /bin/bash rust && steamcmd +force_install_dir /home/rust/RustDedicated +login anonymous +app_update 258550 +quit",
    "valheim":  "apt-get install -y lib32gcc-s1 steamcmd && steamcmd +force_install_dir /opt/valheim +login anonymous +app_update 896660 +quit",
    "satisfactory": "apt-get install -y lib32gcc-s1 steamcmd && steamcmd +force_install_dir /opt/satisfactory +login anonymous +app_update 1690800 +quit",
    "vpn":      "apt-get install -y openvpn easy-rsa && make-cadir /etc/openvpn/easy-rsa",
}

# ══════════════════════════════════════════════════════════════════════════════
#  BOT SETUP
# ══════════════════════════════════════════════════════════════════════════════

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

active_talks:  dict = {}
support_queue: dict = {}
all_messages:  dict = {}
monitors:      dict = {}   # background monitors

# ══════════════════════════════════════════════════════════════════════════════
#  STARTUP
# ══════════════════════════════════════════════════════════════════════════════

def ensure_dirs():
    for d in [VM_DIR, CACHE_DIR, BACKUP_DIR]: os.makedirs(d, exist_ok=True)
    if not os.path.exists(BOT_SSH_KEY):
        subprocess.run(["ssh-keygen","-t","ed25519","-N","","-f",BOT_SSH_KEY],
                       check=True, capture_output=True)

# ══════════════════════════════════════════════════════════════════════════════
#  DATA HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def ld():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE) as f: return json.load(f)
    return {}

def sd(d):
    with open(DATA_FILE,"w") as f: json.dump(d,f,indent=2)

def lcc():
    if os.path.exists(CUSTOM_CMD_FILE):
        with open(CUSTOM_CMD_FILE) as f: return json.load(f)
    return {}

def scc(c):
    with open(CUSTOM_CMD_FILE,"w") as f: json.dump(c,f,indent=2)

def ls():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE) as f: return json.load(f)
    return {"max_vps_per_user":3,"banned_users":[],"maintenance":False,
            "prefix":"!","log_channel":None,"whitelist":[],"whitelist_enabled":False}

def ss(s):
    with open(SETTINGS_FILE,"w") as f: json.dump(s,f,indent=2)

def lal():
    if os.path.exists(ALERTS_FILE):
        with open(ALERTS_FILE) as f: return json.load(f)
    return {}

def sal(a):
    with open(ALERTS_FILE,"w") as f: json.dump(a,f,indent=2)

def lsch():
    if os.path.exists(SCHEDULES_FILE):
        with open(SCHEDULES_FILE) as f: return json.load(f)
    return {}

def ssch(s):
    with open(SCHEDULES_FILE,"w") as f: json.dump(s,f,indent=2)

def gv(data,ukey,idx):
    for v in data.get(ukey,{}).get("vps_list",[]):
        if v["index"]==idx: return v
    return None

def ni(data,ukey):
    lst=data.get(ukey,{}).get("vps_list",[])
    return max((v["index"] for v in lst),default=0)+1

def ap(data):
    used={v["ssh_port"] for ud in data.values() for v in ud.get("vps_list",[]) if "ssh_port" in v}
    p=SSH_PORT_BASE
    while p in used: p+=1
    return p

# ══════════════════════════════════════════════════════════════════════════════
#  TIME
# ══════════════════════════════════════════════════════════════════════════════

def pd(t):
    m=re.fullmatch(r"(\d+)(y|mo|w|d|h|m|s)",t.strip().lower())
    if not m: return None
    v,u=int(m.group(1)),m.group(2)
    return v*{"y":31536000,"mo":2592000,"w":604800,"d":86400,"h":3600,"m":60,"s":1}[u]

def fts(ts): return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M UTC")
def fd(s):
    parts=[]
    for u,n in[("y",31536000),("mo",2592000),("w",604800),("d",86400),("h",3600),("m",60),("s",1)]:
        if s>=n: parts.append(f"{s//n}{u}"); s%=n
    return " ".join(parts[:3]) or "0s"

# ══════════════════════════════════════════════════════════════════════════════
#  SUBPROCESS
# ══════════════════════════════════════════════════════════════════════════════

async def run(cmd, timeout=120):
    try:
        p=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        o,e=await asyncio.wait_for(p.communicate(),timeout=timeout)
        return p.returncode,o.decode(errors="replace"),e.decode(errors="replace")
    except asyncio.TimeoutError: return -1,"","timeout"

async def rsh(cmd,timeout=120):
    try:
        p=await asyncio.create_subprocess_shell(cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        o,e=await asyncio.wait_for(p.communicate(),timeout=timeout)
        return p.returncode,o.decode(errors="replace"),e.decode(errors="replace")
    except asyncio.TimeoutError: return -1,"","timeout"

# ══════════════════════════════════════════════════════════════════════════════
#  SSH INTO VM
# ══════════════════════════════════════════════════════════════════════════════

def sq(s): return "'"+s.replace("'","'\\''")+"'"

async def vx(port,user,cmd,timeout=60):
    ssh=(f"ssh -p {port} -i {BOT_SSH_KEY} "
         f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 -o BatchMode=yes "
         f"-o ServerAliveInterval=5 {user}@127.0.0.1 {sq(cmd)}")
    return await rsh(ssh,timeout=timeout)

async def vx_root(port,cmd,timeout=60):
    """Run as root via sudo."""
    ssh=(f"ssh -p {port} -i {BOT_SSH_KEY} "
         f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 -o BatchMode=yes "
         f"root@127.0.0.1 {sq(cmd)}")
    return await rsh(ssh,timeout=timeout)

async def vm_ready(port,user,retries=36,delay=10):
    for _ in range(retries):
        rc,_,_=await vx(port,user,"echo OK",timeout=12)
        if rc==0: return True
        await asyncio.sleep(delay)
    return False

# ══════════════════════════════════════════════════════════════════════════════
#  VM LIFECYCLE
# ══════════════════════════════════════════════════════════════════════════════

def vpid(n):  return os.path.join(VM_DIR,f"{n}.pid")
def vdisk(n): return os.path.join(VM_DIR,f"{n}.qcow2")
def vseed(n): return os.path.join(VM_DIR,f"{n}-seed.iso")
def vlog(n):  return os.path.join(VM_DIR,f"{n}.log")
def cimg(u):  return os.path.join(CACHE_DIR,hashlib.md5(u.encode()).hexdigest()[:12]+".img")

async def vis(name):
    pf=vpid(name)
    if not os.path.exists(pf): return False
    try:
        with open(pf) as f: pid=int(f.read().strip())
        rc,_,_=await run(["kill","-0",str(pid)]); return rc==0
    except: return False

async def vstop(name):
    pf=vpid(name)
    if os.path.exists(pf):
        try:
            with open(pf) as f: pid=int(f.read().strip())
            await run(["kill","-SIGTERM",str(pid)]); await asyncio.sleep(4)
            await run(["kill","-9",str(pid)])
        except: pass
        try: os.remove(pf)
        except: pass

async def vdestroy(name):
    await vstop(name)
    for f in [vdisk(name),vseed(name),vlog(name),vpid(name)]:
        try: os.remove(f)
        except: pass

async def dl_img(url,upd):
    c=cimg(url)
    if os.path.exists(c): await upd("Using cached image ✅"); return c
    await upd("Downloading base OS image (first time, ~500MB)…")
    rc,_,e=await run(["wget","-q","-O",c,url],timeout=600)
    if rc!=0: rc,_,e=await run(["curl","-L","-o",c,url],timeout=600)
    if rc!=0:
        try: os.remove(c)
        except: pass
        raise RuntimeError(f"Download failed: {e[:200]}")
    return c

def mk_seed(name,username,password,pub_key):
    import crypt
    try: ph=crypt.crypt(password,crypt.mksalt(crypt.METHOD_SHA512))
    except: ph=password
    sd_dir=os.path.join(VM_DIR,f"{name}-seed-tmp"); os.makedirs(sd_dir,exist_ok=True)
    ud=f"""#cloud-config
hostname: {name}
manage_etc_hosts: true
users:
  - name: {username}
    sudo: ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    lock_passwd: false
    passwd: "{ph}"
    ssh_authorized_keys:
      - {pub_key.strip()}
  - name: root
    lock_passwd: false
    passwd: "{ph}"
    ssh_authorized_keys:
      - {pub_key.strip()}
ssh_pwauth: true
chpasswd:
  expire: false
  list:
    - {username}:{password}
    - root:{password}
package_update: false
packages: [curl, wget, git, vim, nano, htop, net-tools, unzip, ca-certificates, sudo, ufw, rsync, lsof, strace, tcpdump, iotop, sysstat]
runcmd:
  - sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
  - echo 'export HISTTIMEFORMAT="%d/%m/%y %T "' >> /etc/bash.bashrc
"""
    with open(os.path.join(sd_dir,"user-data"),"w") as f: f.write(ud)
    with open(os.path.join(sd_dir,"meta-data"),"w") as f: f.write(f"instance-id: {name}\nlocal-hostname: {name}\n")
    iso=vseed(name)
    for tool,args in [
        ("cloud-localds",["cloud-localds",iso,os.path.join(sd_dir,"user-data"),os.path.join(sd_dir,"meta-data")]),
        ("genisoimage",  ["genisoimage","-output",iso,"-volid","cidata","-joliet","-rock",os.path.join(sd_dir,"user-data"),os.path.join(sd_dir,"meta-data")]),
        ("mkisofs",      ["mkisofs","-output",iso,"-volid","cidata","-joliet","-rock",os.path.join(sd_dir,"user-data"),os.path.join(sd_dir,"meta-data")]),
    ]:
        if shutil.which(tool.split()[0]):
            r=subprocess.run(args,capture_output=True)
            if r.returncode==0: break
    else: raise RuntimeError("No ISO tool found. Install cloud-image-utils.")
    shutil.rmtree(sd_dir,ignore_errors=True); return iso

async def start_qemu(name,disk,seed,ssh_port,ram_mb,cpus):
    kvm=["-enable-kvm","-cpu","host"] if os.path.exists("/dev/kvm") else ["-cpu","max"]
    cmd=["qemu-system-x86_64",*kvm,
         "-m",str(ram_mb),"-smp",str(cpus),
         "-drive",f"file={disk},format=qcow2,if=virtio",
         "-drive",f"file={seed},format=raw,if=virtio,readonly=on",
         "-netdev",f"user,id=net0,hostfwd=tcp::{ssh_port}-:22",
         "-device","virtio-net-pci,netdev=net0",
         "-nographic","-serial",f"file:{vlog(name)}",
         "-monitor","none","-daemonize","-pidfile",vpid(name)]
    rc,_,e=await run(cmd,timeout=30)
    if rc!=0: raise RuntimeError(f"QEMU failed: {e[:300]}")
    await asyncio.sleep(2)

async def hostip():
    rc,o,_=await rsh("curl -4 -s --max-time 5 https://ifconfig.me || hostname -I | awk '{print $1}'")
    return o.strip() or "127.0.0.1"

# ══════════════════════════════════════════════════════════════════════════════
#  SSHX  ─  runs INSIDE the real VM (no SSL issues)
# ══════════════════════════════════════════════════════════════════════════════

async def vm_sshx(vps,msg=None):
    port,user=vps["ssh_port"],vps["username"]; dbg=[]
    async def upd(t):
        dbg.append(t)
        if msg:
            try: await msg.edit(content=f"⏳ {t}")
            except: pass
    await upd("Installing sshx in VM…")
    rc,o,e=await vx(port,user,"curl -sSf https://sshx.io/get | sh 2>&1 || curl -sSfk https://sshx.io/get | sh 2>&1",timeout=90)
    dbg.append(f"[install rc={rc}] {(o+e)[:150]}")
    if rc!=0:
        rc,o,e=await vx(port,user,"curl -fsSLk https://github.com/ekzhang/sshx/releases/latest/download/sshx-x86_64-unknown-linux-musl.tar.gz | tar -xz -C /usr/local/bin/ && chmod +x /usr/local/bin/sshx && echo OK",timeout=60)
        dbg.append(f"[direct rc={rc}] {(o+e)[:150]}")
    _,chk,_=await vx(port,user,"which sshx 2>/dev/null || echo MISSING")
    if "MISSING" in chk: return None,"\n".join(dbg)
    await vx(port,user,"pkill -9 -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true")
    await asyncio.sleep(1)
    await upd("Launching sshx…")
    await vx(port,user,"nohup bash -c 'sshx > /tmp/sshx.log 2>&1' </dev/null &",timeout=10)
    await asyncio.sleep(3)
    await upd("Waiting for URL…")
    for i in range(25):
        await asyncio.sleep(2)
        _,log,_=await vx(port,user,"cat /tmp/sshx.log 2>/dev/null || echo ''")
        m=re.search(r"https://sshx\.io/s/[\w#/=+-]+",log)
        if m: return m.group(0).rstrip("/"),"\n".join(dbg)
    return None,"\n".join(dbg)

async def vm_tmate(vps,msg=None):
    port,user=vps["ssh_port"],vps["username"]
    if msg:
        try: await msg.edit(content="⏳ Installing tmate…")
        except: pass
    await vx(port,user,"command -v tmate || apt-get install -y tmate -qq 2>/dev/null || curl -fsSLk https://github.com/tmate-io/tmate/releases/download/2.4.0/tmate-2.4.0-static-linux-amd64.tar.xz | tar -xJ -C /usr/local/bin/ --strip=1 2>/dev/null || true",timeout=120)
    await vx(port,user,"pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true")
    await asyncio.sleep(1)
    await vx(port,user,"tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true",timeout=15)
    await asyncio.sleep(8)
    sl=wl=""
    for _ in range(5):
        _,out,_=await vx(port,user,"tmate -S /tmp/tmate.sock show-messages 2>&1 || true")
        sm=re.search(r"ssh\s+\S+@\S+(?:\s+-p\s+\d+)?",out); wm=re.search(r"https://tmate\.io/t/\S+",out)
        if sm: sl=sm.group(0)
        if wm: wl=wm.group(0)
        if sl or wl: break
        await asyncio.sleep(3)
    return sl,wl

# ══════════════════════════════════════════════════════════════════════════════
#  CREATION CORE
# ══════════════════════════════════════════════════════════════════════════════

async def create_core(owner,requester,setup,pm=None,admin=False):
    os_name,img_url,_,vm_name,username,password,ram_mb,cpus,disk_gb=setup
    data=ld(); ukey=str(owner.id)
    if ukey not in data: data[ukey]={"vps_list":[]}
    cfg=ls()
    if str(owner.id) in cfg.get("banned_users",[]):
        if pm: await pm.edit(content="❌ User is banned."); return
    existing=data[ukey]["vps_list"]; mx=cfg.get("max_vps_per_user",3)
    if not admin and len(existing)>=mx:
        if pm: await pm.edit(content=f"❌ User already has {mx} VPS (the max)."); return
    idx=ni(data,ukey); name=vm_name
    taken=[v["name"] for v in existing]
    if name in taken: name=f"{vm_name}-{idx}"
    port=ap(data); expires_at=0 if admin else time.time()+DEFAULT_EXPIRE_S

    async def upd(t):
        if pm:
            try: await pm.edit(content=t)
            except: pass

    try:
        await upd("⏳ **[1/5]** Fetching base OS image…")
        base=await dl_img(img_url,upd)
        await upd("⏳ **[2/5]** Creating VM disk…")
        disk=vdisk(name)
        rc,_,e=await run(["qemu-img","create","-f","qcow2","-b",base,"-F","qcow2",disk,f"{disk_gb}G"])
        if rc!=0: shutil.copy2(base,disk); await run(["qemu-img","resize",disk,f"{disk_gb}G"])
        await upd("⏳ **[3/5]** Building cloud-init config…")
        with open(BOT_SSH_PUB) as f: pub_key=f.read().strip()
        seed=mk_seed(name,username,password,pub_key)
        await upd(f"⏳ **[4/5]** Booting VM on SSH port {port}…")
        await start_qemu(name,disk,seed,port,ram_mb,cpus)
        await upd("⏳ **[5/5]** Waiting for boot (~2 min)…")
        rdy=await vm_ready(port,"ubuntu",retries=36,delay=10)
        if not rdy: rdy=await vm_ready(port,username,retries=6,delay=5)
        exp_s=fts(expires_at) if expires_at else "Never"
        hip=await hostip()
        data[ukey]["vps_list"].append({
            "index":idx,"name":name,"os":os_name,"username":username,
            "ssh_port":port,"host_ip":hip,"ram_mb":ram_mb,"cpus":cpus,"disk_gb":disk_gb,
            "status":"running","created_by":str(requester.id),
            "expires_at":expires_at,"warned_24h":False,
            "notes":"","tags":[],"autostart":True,"created_at":time.time(),
        })
        sd(data)
        dm=owner.dm_channel or await owner.create_dm()
        creds=(f"🖥️ **OS:** {os_name}\n"
               f"🌐 **SSH:** `ssh {username}@{hip} -p {port}`\n"
               f"👤 **User:** `{username}`  🔑 **Pass:** `{password}`\n"
               f"🧠 {ram_mb}MB RAM  •  ⚙️ {cpus} vCPU  •  💾 {disk_gb}GB\n"
               f"⏰ **Expires:** {exp_s}\n\n"
               f"✅ Real VM — `systemctl` `apt` `sudo` all work!\n"
               f"Use `!panel` for the control panel, `!sshx` for browser terminal.")
        if owner.id!=requester.id:
            await dm.send(f"🎉 **VPS Ready!** Admin **{requester.display_name}** gave you a VM!\n\n{creds}\nType `!commands` for all commands.")
        else:
            await dm.send(f"✅ **VM `{name}` is ready!**\n\n{creds}")
        await upd(f"✅ **`{name}` LIVE!** {os_name} • 🧠{ram_mb}MB • ⚙️{cpus}vCPU • 💾{disk_gb}GB\n🔌 Port: **{port}** • ⏰ **{exp_s}**\n📬 Credentials sent to DMs.")
    except Exception as e:
        await vdestroy(name); await upd(f"❌ VM creation failed: `{e}`")

# ══════════════════════════════════════════════════════════════════════════════
#  INTERACTIVE PANEL  ─  button UI
# ══════════════════════════════════════════════════════════════════════════════

def vembed(vps,running):
    exp=vps.get("expires_at",0); exps=fts(exp) if exp else "Never"
    left=fd(max(0,int(exp-time.time()))) if exp else "∞"
    e=discord.Embed(
        title=f"{'🟢' if running else '🔴'}  VPS Panel  —  `{vps['name']}`",
        color=C_GREEN if running else C_RED,
        timestamp=datetime.datetime.utcnow())
    e.add_field(name="📋 Status",   value="Running ✅" if running else "Stopped ❌", inline=True)
    e.add_field(name="🖥️ OS",      value=vps.get("os","?"),                          inline=True)
    e.add_field(name="🔌 SSH",      value=f"`{vps.get('host_ip','?')}:{vps.get('ssh_port','?')}`", inline=True)
    e.add_field(name="🧠 RAM",      value=f"{vps.get('ram_mb',DEFAULT_RAM_MB)}MB",   inline=True)
    e.add_field(name="⚙️ vCPU",    value=str(vps.get("cpus",DEFAULT_CPUS)),          inline=True)
    e.add_field(name="💾 Disk",     value=f"{vps.get('disk_gb',DEFAULT_DISK_GB)}GB", inline=True)
    e.add_field(name="👤 User",     value=f"`{vps.get('username','?')}`",             inline=True)
    e.add_field(name="⏰ Expires",  value=exps,                                       inline=True)
    e.add_field(name="⌛ Time Left",value=left,                                       inline=True)
    if vps.get("notes"): e.add_field(name="📝 Notes",value=vps["notes"],inline=False)
    if vps.get("tags"):  e.add_field(name="🏷️ Tags", value=" ".join(f"`{t}`" for t in vps["tags"]),inline=False)
    created=vps.get("created_at",0)
    if created: e.set_footer(text=f"#{vps['index']} • Created {fts(created)}")
    return e

class VPSPanel(ui.View):
    def __init__(self,vps,uid,adm):
        super().__init__(timeout=300); self.vps=vps; self.uid=uid; self.adm=adm

    async def interaction_check(self,i):
        if i.user.id!=self.uid:
            await i.response.send_message("❌ Not your panel.",ephemeral=True); return False
        return True

    async def _refresh(self,i):
        running=await vis(self.vps["name"])
        await i.message.edit(embed=vembed(self.vps,running),view=self)

    # Row 0 — Power
    @ui.button(label="▶ Start",   style=discord.ButtonStyle.green,  row=0)
    async def btn_start(self,i,b):
        await i.response.defer()
        if await vis(self.vps["name"]): await i.followup.send("⚠️ Already running.",ephemeral=True); return
        try:
            await start_qemu(self.vps["name"],vdisk(self.vps["name"]),vseed(self.vps["name"]),
                             self.vps["ssh_port"],self.vps.get("ram_mb",DEFAULT_RAM_MB),self.vps.get("cpus",DEFAULT_CPUS))
            d=ld(); v=gv(d,str(self.uid),self.vps["index"])
            if v: v["status"]="running"; sd(d)
            await i.followup.send("▶️ VM started!",ephemeral=True)
        except Exception as ex: await i.followup.send(f"❌ {ex}",ephemeral=True)
        await self._refresh(i)

    @ui.button(label="⏹ Stop",    style=discord.ButtonStyle.red,    row=0)
    async def btn_stop(self,i,b):
        await i.response.defer()
        await vstop(self.vps["name"])
        d=ld(); v=gv(d,str(self.uid),self.vps["index"])
        if v: v["status"]="stopped"; sd(d)
        await i.followup.send("⏹ Stopped.",ephemeral=True); await self._refresh(i)

    @ui.button(label="🔄 Reboot",  style=discord.ButtonStyle.blurple,row=0)
    async def btn_reboot(self,i,b):
        await i.response.defer()
        await vx(self.vps["ssh_port"],self.vps["username"],"sudo reboot &",timeout=10)
        await i.followup.send("🔄 Reboot sent! Back in ~30s.",ephemeral=True); await self._refresh(i)

    @ui.button(label="🔃 Refresh", style=discord.ButtonStyle.grey,   row=0)
    async def btn_refresh(self,i,b):
        await i.response.defer(); await self._refresh(i)
        await i.followup.send("🔃 Refreshed.",ephemeral=True)

    # Row 1 — Access
    @ui.button(label="🌐 sshx",    style=discord.ButtonStyle.blurple,row=1)
    async def btn_sshx(self,i,b):
        await i.response.defer()
        m=await i.followup.send("⏳ Starting sshx… (60s)",ephemeral=True)
        link,dbg=await vm_sshx(self.vps)
        if link:
            try: await i.user.send(f"✅ **sshx!**\n🔗 {link}")
            except: pass
            await m.edit(content=f"✅ sshx ready! 🔗 {link}")
        else: await m.edit(content=f"❌ sshx failed:\n```{dbg[-400:]}```")

    @ui.button(label="🖥 tmate",   style=discord.ButtonStyle.blurple,row=1)
    async def btn_tmate(self,i,b):
        await i.response.defer()
        m=await i.followup.send("⏳ Starting tmate…",ephemeral=True)
        sl,wl=await vm_tmate(self.vps)
        if sl or wl:
            lines=["🖥️ **tmate:**"]
            if sl: lines.append(f"```{sl}```")
            if wl: lines.append(f"🌐 {wl}")
            try: await i.user.send("\n".join(lines))
            except: pass
            await m.edit(content="✅ tmate ready! 📬 DMs.")
        else: await m.edit(content="❌ tmate failed. Try sshx.")

    @ui.button(label="📊 Stats",   style=discord.ButtonStyle.grey,   row=1)
    async def btn_stats(self,i,b):
        await i.response.defer()
        port,user=self.vps["ssh_port"],self.vps["username"]
        _,upt,_=await vx(port,user,"uptime -p 2>/dev/null|head -1")
        _,ram,_=await vx(port,user,"free -m|awk '/^Mem/{printf \"%s/%s MB\",$3,$2}'")
        _,dsk,_=await vx(port,user,"df -h /|awk 'NR==2{printf \"%s/%s (%s)\",$3,$2,$5}'")
        _,cpu,_=await vx(port,user,"top -bn1|grep Cpu|awk '{print 100-$8\"%\"}'")
        _,ips,_=await vx(port,user,"hostname -I|awk '{print $1}'")
        _,kv,_ =await vx(port,user,"uname -r")
        e=discord.Embed(title=f"📊 Live Stats — `{self.vps['name']}`",color=C_BLUE,timestamp=datetime.datetime.utcnow())
        e.add_field(name="⏱ Uptime",  value=upt.strip()or"?",inline=True)
        e.add_field(name="🧠 RAM",     value=ram.strip()or"?",inline=True)
        e.add_field(name="💾 Disk",    value=dsk.strip()or"?",inline=True)
        e.add_field(name="⚙️ CPU",    value=cpu.strip()or"?",inline=True)
        e.add_field(name="🌐 IP",      value=ips.strip()or"?",inline=True)
        e.add_field(name="🐧 Kernel",  value=kv.strip()or"?",inline=True)
        await i.followup.send(embed=e,ephemeral=True)

    @ui.button(label="📜 Logs",    style=discord.ButtonStyle.grey,   row=1)
    async def btn_logs(self,i,b):
        await i.response.defer()
        lf=vlog(self.vps["name"])
        if os.path.exists(lf):
            with open(lf,errors="replace") as f: c=f.read()
            t=c[-1800:] if len(c)>1800 else c
            await i.followup.send(f"📜 **Boot log tail:**\n```\n{t}\n```",ephemeral=True)
        else: await i.followup.send("❌ No log file.",ephemeral=True)

    # Row 2 — Tools
    @ui.button(label="📸 Snapshot",style=discord.ButtonStyle.grey,   row=2)
    async def btn_snap(self,i,b):
        await i.response.defer()
        ts=int(time.time())
        rc,_,e=await run(["qemu-img","snapshot","-c",f"snap-{ts}",vdisk(self.vps["name"])])
        if rc==0: await i.followup.send(f"📸 Snapshot `snap-{ts}` created!",ephemeral=True)
        else:     await i.followup.send(f"❌ {e[:200]}",ephemeral=True)

    @ui.button(label="🔥 Delete",  style=discord.ButtonStyle.red,    row=2)
    async def btn_del(self,i,b):
        if not self.adm: await i.response.send_message("❌ Admins only.",ephemeral=True); return
        await i.response.send_message(f"⚠️ Reply `CONFIRM` to delete `{self.vps['name']}` (30s).",ephemeral=True)
        def chk(m): return m.author.id==i.user.id and m.content=="CONFIRM"
        try:
            await bot.wait_for("message",check=chk,timeout=30)
            await vdestroy(self.vps["name"])
            d=ld(); ukey=str(self.uid)
            d[ukey]["vps_list"]=[v for v in d[ukey]["vps_list"] if v["index"]!=self.vps["index"]]; sd(d)
            self.stop()
            await i.message.edit(content=f"🗑️ `{self.vps['name']}` deleted.",embed=None,view=None)
        except asyncio.TimeoutError: await i.followup.send("⏰ Cancelled.",ephemeral=True)

    @ui.button(label="📋 Info",    style=discord.ButtonStyle.grey,   row=2)
    async def btn_info(self,i,b):
        await i.response.defer()
        port,user=self.vps["ssh_port"],self.vps["username"]
        _,o1,_=await vx(port,user,"cat /etc/os-release 2>/dev/null|head -5")
        _,o2,_=await vx(port,user,"uname -a")
        _,o3,_=await vx(port,user,"cat /proc/cpuinfo|grep 'model name'|head -1|cut -d: -f2")
        e=discord.Embed(title=f"📋 VM Info — `{self.vps['name']}`",color=C_TEAL)
        e.add_field(name="OS Release",value=f"```{o1.strip()[:300]}```",inline=False)
        e.add_field(name="Kernel",    value=f"```{o2.strip()[:200]}```",inline=False)
        e.add_field(name="CPU Model", value=o3.strip()or"?",inline=False)
        await i.followup.send(embed=e,ephemeral=True)

# ══════════════════════════════════════════════════════════════════════════════
#  EXPIRY LOOP
# ══════════════════════════════════════════════════════════════════════════════

async def expiry_loop():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            now=time.time(); data=ld(); changed=False
            for uid,ud in list(data.items()):
                keep=[]
                for vps in ud.get("vps_list",[]):
                    exp=vps.get("expires_at",0)
                    if not exp: keep.append(vps); continue
                    if now>=exp:
                        await vdestroy(vps["name"]); changed=True
                        try:
                            u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                            await dm.send(f"⏰ **VPS `{vps['name']}` expired and was deleted.**")
                        except: pass
                    else:
                        if exp-now<86400 and not vps.get("warned_24h"):
                            vps["warned_24h"]=True; changed=True
                            try:
                                u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                                await dm.send(f"⚠️ **VPS `{vps['name']}` expires in {fd(int(exp-now))}!**")
                            except: pass
                        keep.append(vps)
                if len(keep)!=len(ud.get("vps_list",[])): ud["vps_list"]=keep; changed=True
            if changed: sd(data)
        except Exception as ex: print(f"[expiry] {ex}")
        await asyncio.sleep(60)

async def autostart_loop():
    await bot.wait_until_ready(); await asyncio.sleep(20)
    data=ld()
    for ud in data.values():
        for vps in ud.get("vps_list",[]):
            if vps.get("autostart",True) and not await vis(vps["name"]):
                disk=vdisk(vps["name"]); seed=vseed(vps["name"])
                if os.path.exists(disk) and os.path.exists(seed):
                    try:
                        await start_qemu(vps["name"],disk,seed,vps["ssh_port"],
                                         vps.get("ram_mb",DEFAULT_RAM_MB),vps.get("cpus",DEFAULT_CPUS))
                        print(f"[autostart] {vps['name']}")
                    except: pass

async def alert_loop():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            alerts=lal(); data=ld()
            for uid,uals in alerts.items():
                udata=data.get(uid,{})
                for a in list(uals):
                    vps=None
                    for ud_vps in udata.get("vps_list",[]):
                        if ud_vps["index"]==a.get("vps_index"): vps=ud_vps; break
                    if not vps: continue
                    if not await vis(vps["name"]): continue
                    port,user=vps["ssh_port"],vps["username"]
                    triggered=False; msg=""
                    if a["type"]=="cpu":
                        _,out,_=await vx(port,user,"top -bn1|grep Cpu|awk '{print 100-$8}'",timeout=10)
                        try:
                            val=float(out.strip())
                            if val>a["threshold"]: triggered=True; msg=f"CPU at **{val:.1f}%** (threshold: {a['threshold']}%)"
                        except: pass
                    elif a["type"]=="ram":
                        _,out,_=await vx(port,user,"free|awk '/^Mem/{printf \"%.0f\",($3/$2)*100}'",timeout=10)
                        try:
                            val=float(out.strip())
                            if val>a["threshold"]: triggered=True; msg=f"RAM at **{val:.0f}%** (threshold: {a['threshold']}%)"
                        except: pass
                    elif a["type"]=="disk":
                        _,out,_=await vx(port,user,"df /|awk 'NR==2{print $5}'|tr -d '%'",timeout=10)
                        try:
                            val=float(out.strip())
                            if val>a["threshold"]: triggered=True; msg=f"Disk at **{val:.0f}%** (threshold: {a['threshold']}%)"
                        except: pass
                    if triggered:
                        try:
                            u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                            await dm.send(f"🚨 **Alert — `{vps['name']}`**\n{msg}")
                        except: pass
        except Exception as ex: print(f"[alert_loop] {ex}")
        await asyncio.sleep(120)

async def schedule_loop():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            now=time.time(); schs=lsch(); changed=False
            for uid,uschs in list(schs.items()):
                for s in list(uschs):
                    if s.get("next_run",0)<=now:
                        data=ld(); vps=None
                        for ud_vps in data.get(uid,{}).get("vps_list",[]):
                            if ud_vps["index"]==s.get("vps_index"): vps=ud_vps; break
                        if vps and await vis(vps["name"]):
                            try:
                                rc,out,err=await vx(vps["ssh_port"],vps["username"],s["command"],timeout=120)
                                try:
                                    u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                                    output=(out+err).strip()[:600]
                                    await dm.send(f"⏰ **Scheduled task** `{s['name']}` on `{vps['name']}`:\n```\n{output}\n```" if output else f"⏰ **Scheduled task** `{s['name']}` completed.")
                                except: pass
                            except: pass
                        interval=pd(s.get("interval","1d")) or 86400
                        s["next_run"]=now+interval; changed=True
            if changed: ssch(schs)
        except Exception as ex: print(f"[schedule] {ex}")
        await asyncio.sleep(60)

# ══════════════════════════════════════════════════════════════════════════════
#  PERMISSIONS
# ══════════════════════════════════════════════════════════════════════════════

def isa(member): return any(r.id==ADMIN_ROLE_ID for r in member.roles)

def ao():
    async def pred(ctx):
        if not ctx.guild: await ctx.send("❌ Server only."); return False
        if isa(ctx.author): return True
        await ctx.send("❌ Admins only."); return False
    return commands.check(pred)

# ══════════════════════════════════════════════════════════════════════════════
#  MESSAGE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

async def bs(ch,*a,**kw):
    m=await ch.send(*a,**kw); all_messages.setdefault(ch.id,[]).append(("bot",m.id)); return m

async def wc(ctx,del_r=False):
    def c(m): return m.author==ctx.author and m.channel==ctx.channel
    try:
        r=await bot.wait_for("message",check=c,timeout=300)
        all_messages.setdefault(ctx.channel.id,[]).append(("user",r.id))
        if del_r:
            try: await r.delete()
            except: pass
        return r
    except asyncio.TimeoutError: return None

async def wd(user,del_r=False):
    def c(m): return m.author.id==user.id and isinstance(m.channel,discord.DMChannel)
    try:
        r=await bot.wait_for("message",check=c,timeout=600)
        if del_r:
            try: await r.delete()
            except: pass
        return r
    except asyncio.TimeoutError: return None

# helper: send in guild or DM
async def reply(ctx,*a,**kw):
    if ctx.guild: return await bs(ctx.channel,*a,**kw)
    else:         return await ctx.send(*a,**kw)

# helper: get vps with error reply
async def getvps(ctx,index=1):
    data=ld(); vps=gv(data,str(ctx.author.id),index)
    if not vps: await reply(ctx,f"❌ VPS #{index} not found. Use `!vpslist` to see your VMs.")
    return vps,data

# ══════════════════════════════════════════════════════════════════════════════
#  WIZARDS
# ══════════════════════════════════════════════════════════════════════════════

async def ask_specs(ctx,is_dm=False,who=""):
    send=(ctx.send if is_dm else lambda *a,**k: bs(ctx.channel,*a,**k))
    wait=(lambda: wd(ctx)) if is_dm else (lambda: wc(ctx))
    m1=await send(f"🧠 **RAM** {who}(MB, e.g. `512` `1024` `2048` `4096`, max {MAX_RAM_MB}):")
    r1=await wait()
    if not r1: return None
    try: ram=max(256,min(int(r1.content.strip()),MAX_RAM_MB))
    except: await m1.edit(content="❌ Invalid."); return None
    if not is_dm: await m1.edit(content=f"✅ **RAM:** {ram}MB")
    m2=await send(f"⚙️ **vCPUs** (e.g. `1` `2` `4`, max {MAX_CPUS}):")
    r2=await wait()
    if not r2: return None
    try: cpus=max(1,min(int(r2.content.strip()),MAX_CPUS))
    except: await m2.edit(content="❌ Invalid."); return None
    if not is_dm: await m2.edit(content=f"✅ **vCPUs:** {cpus}")
    m3=await send(f"💾 **Disk GB** (e.g. `10` `20` `50`, max {MAX_DISK_GB}):")
    r3=await wait()
    if not r3: return None
    try: disk=max(5,min(int(r3.content.strip()),MAX_DISK_GB))
    except: await m3.edit(content="❌ Invalid."); return None
    if not is_dm: await m3.edit(content=f"✅ **Disk:** {disk}GB")
    return ram,cpus,disk

async def guild_wiz(ctx,custom=False):
    osl="\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    s1=await bs(ctx.channel,f"🖥️ **Step 1 — OS**\n{osl}\n\nType the number:")
    r1=await wc(ctx)
    if not r1 or r1.content.strip() not in OS_OPTIONS: await s1.edit(content="❌ Invalid."); return None
    osn,iurl,du=OS_OPTIONS[r1.content.strip()]; await s1.edit(content=f"✅ **OS:** {osn}")
    s2=await bs(ctx.channel,"📛 **VM name** (e.g. `myserver`):")
    r2=await wc(ctx)
    if not r2: await s2.edit(content="❌ No reply."); return None
    nm=re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:32] or "myserver"
    await s2.edit(content=f"✅ **Name:** `{nm}`")
    s3=await bs(ctx.channel,"👤 **Username:**")
    r3=await wc(ctx)
    if not r3: await s3.edit(content="❌ No reply."); return None
    un=re.sub(r"[^a-z0-9_\-]","",r3.content.strip().lower()) or du
    await s3.edit(content=f"✅ **Username:** `{un}`")
    s4=await bs(ctx.channel,"🔑 **Password** *(deleted instantly)*")
    r4=await wc(ctx,del_r=True)
    if not r4: await s4.edit(content="❌ No reply."); return None
    pw=r4.content.strip(); await s4.edit(content="✅ **Password:** `••••••••`")
    if custom:
        specs=await ask_specs(ctx)
        if not specs: return None
        ram,cpus,disk=specs
    else: ram,cpus,disk=DEFAULT_RAM_MB,DEFAULT_CPUS,DEFAULT_DISK_GB
    return osn,iurl,du,nm,un,pw,ram,cpus,disk

async def dm_wiz(user,admin_name,forced_specs=None):
    dm=user.dm_channel or await user.create_dm()
    osl="\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    await dm.send(f"👋 **{user.display_name}** — **{admin_name}** is setting up your VPS!\n\n🖥️ **Choose OS:**\n{osl}\n\nType the number:")
    r1=await wd(user)
    if not r1 or r1.content.strip() not in OS_OPTIONS: await dm.send("❌ Invalid."); return None
    osn,iurl,du=OS_OPTIONS[r1.content.strip()]; await dm.send(f"✅ **OS:** {osn}")
    await dm.send("📛 **VM name:**"); r2=await wd(user)
    if not r2: await dm.send("❌ No reply."); return None
    nm=re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:32] or "myserver"; await dm.send(f"✅ **Name:** `{nm}`")
    await dm.send("👤 **Username:**"); r3=await wd(user)
    if not r3: await dm.send("❌ No reply."); return None
    un=re.sub(r"[^a-z0-9_\-]","",r3.content.strip().lower()) or du; await dm.send(f"✅ **Username:** `{un}`")
    await dm.send("🔑 **Password** *(deleted instantly)*"); r4=await wd(user,del_r=True)
    if not r4: await dm.send("❌ No reply."); return None
    pw=r4.content.strip(); await dm.send("✅ **Password set!** ⏳ Creating now…")
    ram,cpus,disk=forced_specs if forced_specs else (DEFAULT_RAM_MB,DEFAULT_CPUS,DEFAULT_DISK_GB)
    return osn,iurl,du,nm,un,pw,ram,cpus,disk

    if rc==0:
        await msg.edit(content=f"✅ Deployed `{repo_name}` to `{deploy_path}`!\n```\n{output[-400:]}\n```")
    else:
        await msg.edit(content=f"❌ Deploy failed:\n```\n{output[-500:]}\n```")

@bot.command(name="pm2list")
async def c_pm2list(ctx,index:int=1):
    await vi(ctx,index,"pm2 list 2>&1||echo 'PM2 not installed'","PM2 Processes","🟢")

@bot.command(name="pm2start")
async def c_pm2start(ctx,index:int=1,*,app:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await vx(vps["ssh_port"],vps["username"],f"pm2 start {sq(app)} 2>&1",timeout=20)
    await reply(ctx,f"✅ PM2 started `{app}`." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="pm2stop")
async def c_pm2stop(ctx,index:int=1,*,app:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await vx(vps["ssh_port"],vps["username"],f"pm2 stop {sq(app)} 2>&1",timeout=20)
    await reply(ctx,f"✅ PM2 stopped `{app}`." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="pm2logs")
async def c_pm2logs(ctx,index:int=1,*,app:str="all"):
    await vi(ctx,index,f"pm2 logs {app} --lines 40 --nostream 2>&1||pm2 logs --lines 40 --nostream 2>&1",f"PM2 Logs ({app})","📜")

@bot.command(name="pm2restart")
async def c_pm2restart(ctx,index:int=1,*,app:str):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await vx(vps["ssh_port"],vps["username"],f"pm2 restart {sq(app)} 2>&1",timeout=20)
    await reply(ctx,f"✅ PM2 restarted `{app}`." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="nginxtest")
async def c_nginxtest(ctx,index:int=1):
    await vi(ctx,index,"sudo nginx -t 2>&1","Nginx Config Test","🌐")

@bot.command(name="nginxreload")
async def c_nginxreload(ctx,index:int=1):
    vps,_=await getvps(ctx,index)
    if not vps: return
    rc,_,e=await vx(vps["ssh_port"],vps["username"],"sudo systemctl reload nginx 2>&1",timeout=15)
    await reply(ctx,"✅ Nginx reloaded." if rc==0 else f"❌ {e[:200]}")

@bot.command(name="certbot")
@ao()
async def c_certbot(ctx,index:int=1,*,domain:str):
    """Get SSL cert. Usage: !certbot [#] example.com"""
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Getting SSL cert for `{domain}`…")
    rc,out,err=await vx(vps["ssh_port"],vps["username"],
        f"sudo certbot --nginx -d {domain} --non-interactive --agree-tos --email admin@{domain} 2>&1||sudo certbot --apache -d {domain} --non-interactive --agree-tos --email admin@{domain} 2>&1",timeout=120)
    output=(out+err).strip()[-800:]
    await msg.edit(content=f"{'✅ SSL cert obtained!' if rc==0 else '❌ Failed:'}\n```\n{output[-500:]}\n```")

@bot.command(name="cloudflared")
@ao()
async def c_cloudflared(ctx,index:int=1,*,url:str="http://localhost:8080"):
    """Start cloudflared tunnel. Usage: !cloudflared [#] [local-url]"""
    vps,_=await getvps(ctx,index)
    if not vps: return
    msg=await reply(ctx,f"⏳ Starting cloudflared tunnel for `{url}`…")
    await vx(vps["ssh_port"],vps["username"],"pkill -f cloudflared 2>/dev/null; true",timeout=5)
    await vx(vps["ssh_port"],vps["username"],
        f"nohup cloudflared tunnel --url {url} > /tmp/cf.log 2>&1 &",timeout=10)
    await asyncio.sleep(5)
    _,log,_=await vx(vps["ssh_port"],vps["username"],"cat /tmp/cf.log 2>/dev/null",timeout=10)
    m=re.search(r"https://[\w\-]+\.trycloudflare\.com",log)
    if m: await msg.edit(content=f"✅ **Cloudflare Tunnel:**\n🔗 {m.group(0)}")
    else: await msg.edit(content=f"⏳ Starting… check `/tmp/cf.log` on VM.\n```\n{log[-400:]}\n```")

# ─── ADMIN ────────────────────────────────────────────────────────────────────

@bot.command(name="announce")
@ao()
async def c_announce(ctx,*,message:str):
    """Announce to all VPS owners."""
    data=ld(); count=0
    for uid in data:
        if data[uid].get("vps_list"):
            try:
                u=await bot.fetch_user(int(uid)); dm=u.dm_channel or await u.create_dm()
                await dm.send(f"📢 **Announcement from {ctx.author.display_name}:**\n{message}")
                count+=1; await asyncio.sleep(0.5)
            except: pass
    await bs(ctx.channel,f"📢 Sent to **{count}** VPS owners.")

@bot.command(name="stats")
@ao()
async def c_stats(ctx):
    """Overall bot statistics."""
    data=ld(); total_u=len([u for u in data if data[u].get("vps_list")])
    total_v=sum(len(u.get("vps_list",[])) for u in data.values()); running=0
    for ud in data.values():
        for v in ud.get("vps_list",[]):
            if await vis(v["name"]): running+=1
    cache_files=[f for f in os.listdir(CACHE_DIR) if os.path.isfile(os.path.join(CACHE_DIR,f))]
    cache_gb=sum(os.path.getsize(os.path.join(CACHE_DIR,f)) for f in cache_files)//(1024**3)
    bk_files=[f for f in os.listdir(BACKUP_DIR) if f.endswith(".qcow2")]
    bk_gb=sum(os.path.getsize(os.path.join(BACKUP_DIR,f)) for f in bk_files)//(1024**3)
    e=discord.Embed(title="📈 Dirt VPS Bot — Stats",color=C_BLUE,timestamp=datetime.datetime.utcnow())
    e.add_field(name="👥 Users with VPS",   value=str(total_u),   inline=True)
    e.add_field(name="🖥️ Total VMs",        value=str(total_v),   inline=True)
    e.add_field(name="🟢 Running",           value=str(running),   inline=True)
    e.add_field(name="🔴 Stopped",           value=str(total_v-running),inline=True)
    e.add_field(name="💾 Image Cache",       value=f"{cache_gb}GB",inline=True)
    e.add_field(name="💾 Backups",           value=f"{bk_gb}GB",  inline=True)
    e.add_field(name="⚙️ KVM",              value="✅ Yes" if os.path.exists("/dev/kvm") else "❌ No",inline=True)
    e.add_field(name="📦 Presets",           value=str(len(PRESETS)),inline=True)
    e.add_field(name="🛠️ Custom Commands",  value=str(len(lcc())),inline=True)
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="hostinfo")
@ao()
async def c_hostinfo(ctx):
    """Host machine info."""
    rc1,o1,_=await rsh("free -h")
    rc2,o2,_=await rsh("df -h /")
    rc3,o3,_=await rsh("uptime")
    rc4,o4,_=await rsh("nproc && cat /proc/cpuinfo|grep 'model name'|head -1|cut -d: -f2")
    e=discord.Embed(title="🖥️ Host Machine Info",color=C_GREY)
    e.add_field(name="🧠 RAM",    value=f"```{o1.strip()[:200]}```",inline=False)
    e.add_field(name="💾 Disk",   value=f"```{o2.strip()[:200]}```",inline=False)
    e.add_field(name="⏱ Uptime", value=o3.strip()[:100],           inline=False)
    e.add_field(name="⚙️ CPU",   value=o4.strip()[:100],           inline=False)
    e.add_field(name="KVM",       value="✅" if os.path.exists("/dev/kvm") else "❌",inline=True)
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="setmaxvps")
@ao()
async def c_setmaxvps(ctx,n:int):
    s=ls(); s["max_vps_per_user"]=max(1,n); ss(s)
    await bs(ctx.channel,f"✅ Max VPS per user: **{n}**.")

@bot.command(name="banuser")
@ao()
async def c_banuser(ctx,user_id:int):
    s=ls()
    if str(user_id) not in s.get("banned_users",[]): s.setdefault("banned_users",[]).append(str(user_id))
    ss(s); await bs(ctx.channel,f"🚫 `{user_id}` banned.")

@bot.command(name="unbanuser")
@ao()
async def c_unbanuser(ctx,user_id:int):
    s=ls(); s["banned_users"]=[u for u in s.get("banned_users",[]) if u!=str(user_id)]; ss(s)
    await bs(ctx.channel,f"✅ `{user_id}` unbanned.")

@bot.command(name="banlist")
@ao()
async def c_banlist(ctx):
    s=ls(); bl=s.get("banned_users",[])
    if not bl: await bs(ctx.channel,"✅ No banned users."); return
    e=discord.Embed(title="🚫 Banned Users",color=C_RED)
    for uid in bl: e.add_field(name=f"`{uid}`",value=f"<@{uid}>",inline=True)
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="maintenance")
@ao()
async def c_maintenance(ctx,*,toggle:str="on"):
    s=ls(); on=toggle.lower() in ("on","true","1"); s["maintenance"]=on; ss(s)
    await bs(ctx.channel,f"{'🔧 Maintenance mode ON' if on else '✅ Maintenance mode OFF'}.")

@bot.command(name="serverinfo")
@ao()
async def c_serverinfo(ctx):
    g=ctx.guild
    e=discord.Embed(title=f"📋 {g.name}",color=C_BLUE)
    e.add_field(name="👥 Members", value=str(g.member_count),inline=True)
    e.add_field(name="📅 Created", value=g.created_at.strftime("%Y-%m-%d"),inline=True)
    e.add_field(name="👑 Owner",   value=str(g.owner),inline=True)
    e.add_field(name="📢 Channels",value=str(len(g.channels)),inline=True)
    e.add_field(name="🎭 Roles",   value=str(len(g.roles)),inline=True)
    e.add_field(name="ID",         value=str(g.id),inline=True)
    if g.icon: e.set_thumbnail(url=g.icon.url)
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="botinfo")
async def c_botinfo(ctx):
    e=discord.Embed(title="🤖 Dirt VPS Bot v4.0",color=C_PINK,description="Real KVM virtual machines via Discord")
    e.add_field(name="📡 Ping",    value=f"{round(bot.latency*1000)}ms",inline=True)
    e.add_field(name="🖥️ Servers", value=str(len(bot.guilds)),inline=True)
    e.add_field(name="📦 Presets", value=str(len(PRESETS)),inline=True)
    e.add_field(name="KVM",        value="✅" if os.path.exists("/dev/kvm") else "❌",inline=True)
    e.add_field(name="💾 VM Dir",  value=VM_DIR,inline=True)
    e.add_field(name="🐍 Version", value="Python 3.11+",inline=True)
    e.set_footer(text="Dirt VPS — Free hosting, real VMs")
    await reply(ctx,embed=e)

@bot.command(name="ping")
async def c_ping(ctx):
    """Bot latency ping."""
    await reply(ctx,f"🏓 Pong! `{round(bot.latency*1000)}ms`")

# ─── CUSTOM COMMANDS ──────────────────────────────────────────────────────────

@bot.command(name="createcustomcommand")
@ao()
async def c_ccc(ctx):
    s1=await bs(ctx.channel,"🛠️ **Custom Command — Name** (no `!`):")
    r1=await wc(ctx)
    if not r1: await s1.edit(content="❌ No reply."); return
    cn=re.sub(r"[^a-z0-9_]","",r1.content.strip().lower())
    if not cn: await s1.edit(content="❌ Invalid name."); return
    await s1.edit(content=f"✅ `!{cn}`")
    s2=await bs(ctx.channel,"🛠️ **Bash command to run on VM:**")
    r2=await wc(ctx)
    if not r2: await s2.edit(content="❌ No reply."); return
    bc=r2.content.strip(); await s2.edit(content=f"✅ `{bc[:60]}{'…' if len(bc)>60 else ''}`")
    s3=await bs(ctx.channel,"🛠️ **Short description:**")
    r3=await wc(ctx); desc=r3.content.strip() if r3 else "Custom command"
    cmds=lcc(); cmds[cn]={"bash":bc,"description":desc,"created_by":str(ctx.author.id)}; scc(cmds)
    await bs(ctx.channel,f"🎉 `!{cn}` created! Use `!{cn} [#]` on any VM.")

@bot.command(name="deletecustomcommand")
@ao()
async def c_dcc(ctx,name:str):
    name=name.lstrip("!").lower(); cmds=lcc()
    if name not in cmds: await bs(ctx.channel,f"❌ `!{name}` not found."); return
    del cmds[name]; scc(cmds); await bs(ctx.channel,f"🗑️ `!{name}` deleted.")

@bot.command(name="listcustomcommands")
@ao()
async def c_lcc_cmd(ctx):
    cmds=lcc()
    if not cmds: await bs(ctx.channel,"❌ No custom commands."); return
    e=discord.Embed(title="🛠️ Custom Commands",color=C_GOLD)
    for n,info in cmds.items():
        e.add_field(name=f"!{n}",value=f"{info['description']}\n```{info['bash'][:60]}```",inline=False)
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

# ─── UTILITY ──────────────────────────────────────────────────────────────────

@bot.command(name="generate-password")
async def c_genpass(ctx,length:int=20):
    """Generate a secure random password."""
    chars=string.ascii_letters+string.digits+"!@#$%^&*"
    pw="".join(random.choices(chars,k=min(max(length,8),64)))
    try: await ctx.author.send(f"🔑 Generated password:\n`{pw}`")
    except: pass
    await reply(ctx,"🔑 Password generated and sent to DMs!")

@bot.command(name="uuid")
async def c_uuid(ctx):
    """Generate a UUID."""
    import uuid; await reply(ctx,f"🔑 `{uuid.uuid4()}`")

@bot.command(name="b64encode")
async def c_b64e(ctx,*,text:str):
    """Base64 encode text."""
    import base64; enc=base64.b64encode(text.encode()).decode()
    await reply(ctx,f"🔐 **Base64:**\n```{enc}```")

@bot.command(name="b64decode")
async def c_b64d(ctx,*,text:str):
    """Base64 decode."""
    import base64
    try: dec=base64.b64decode(text.encode()).decode(); await reply(ctx,f"🔓 **Decoded:**\n```{dec[:1500]}```")
    except: await reply(ctx,"❌ Invalid base64.")

@bot.command(name="hash")
async def c_hash(ctx,algo:str="sha256",*,text:str):
    """Hash text. Usage: !hash [md5|sha256|sha512] text"""
    import hashlib
    try:
        h=hashlib.new(algo,text.encode()).hexdigest()
        await reply(ctx,f"🔐 **{algo.upper()}:**\n```{h}```")
    except: await reply(ctx,f"❌ Unknown algorithm `{algo}`.")

@bot.command(name="ipinfo")
async def c_ipinfo(ctx,*,ip:str=""):
    """IP info lookup (host)."""
    rc,out,_=await rsh(f"curl -sSL https://ipinfo.io/{ip}/json 2>/dev/null|python3 -m json.tool 2>/dev/null||curl -sSL https://ipinfo.io/{ip} 2>/dev/null")
    await reply(ctx,f"🌍 **IP Info `{ip or 'self'}`:**\n```\n{out.strip()[:1500]}\n```")

@bot.command(name="whois")
async def c_whois(ctx,*,domain:str):
    """Whois lookup on host."""
    rc,out,err=await rsh(f"whois {domain} 2>&1|head -40")
    await reply(ctx,f"🔍 **whois {domain}:**\n```\n{(out+err).strip()[:1800]}\n```")

@bot.command(name="portscan")
@ao()
async def c_portscan(ctx,*,target:str):
    """Port scan a target from the host."""
    msg=await reply(ctx,f"⏳ Scanning `{target}`…")
    rc,out,err=await rsh(f"nmap -F --open {target} 2>&1|head -30")
    await msg.edit(content=f"🔍 **Scan `{target}`:**\n```\n{(out+err).strip()[:1800]}\n```")

# ─── TALK / SUPPORT ───────────────────────────────────────────────────────────

@bot.command(name="talk")
@ao()
async def c_talk(ctx,user_id:int):
    if ctx.author.id in active_talks: await bs(ctx.channel,"⚠️ Already in a talk."); return
    try: target=await bot.fetch_user(user_id)
    except: await bs(ctx.channel,"❌ Not found."); return
    active_talks[ctx.author.id]=user_id; active_talks[user_id]=ctx.author.id
    try:
        dm=target.dm_channel or await target.create_dm()
        await dm.send("📞 **Admin connected.** Use `!say <msg>` — `!endtalk` to end.")
    except discord.Forbidden:
        await bs(ctx.channel,f"❌ Can't DM {target.display_name}.")
        active_talks.pop(ctx.author.id,None); active_talks.pop(user_id,None); return
    await bs(ctx.channel,f"✅ Connected to **{target.display_name}**.")

@bot.command(name="endtalk")
async def c_endtalk(ctx):
    uid=ctx.author.id
    if uid not in active_talks:
        await reply(ctx,"❌ No active talk."); return
    pid=active_talks.pop(uid); active_talks.pop(pid,None)
    try:
        p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
        await dm.send("📵 Chat ended.")
    except: pass
    await reply(ctx,"✅ Talk ended.")

@bot.command(name="clear")
@ao()
async def c_clear(ctx):
    entries=all_messages.get(ctx.channel.id,[]); deleted=0
    for _,mid in list(entries):
        try: m=await ctx.channel.fetch_message(mid); await m.delete(); deleted+=1
        except: pass
        await asyncio.sleep(0.3)
    all_messages[ctx.channel.id]=[]
    try: await ctx.message.delete()
    except: pass
    m=await ctx.send(f"🧹 Cleared {deleted} messages.")
    await asyncio.sleep(3)
    try: await m.delete()
    except: pass

# ─── COMMANDS LIST ────────────────────────────────────────────────────────────

@bot.command(name="commands")
async def c_commands(ctx):
    cmds=lcc()
    if isinstance(ctx.channel,discord.DMChannel):
        e=discord.Embed(title="🖥️ Dirt VPS Bot — Your Commands",color=C_BLUE,description="Manage your VMs from DMs")
        e.add_field(name="📋 Panel & Info",   value="`!panel [#]` `!vpslist` `!status [#]`\n`!df` `!ram` `!cpu` `!top` `!uptime` `!ip` `!ports` `!load` `!logs [#]`",inline=False)
        e.add_field(name="⚡ Power",          value="`!start [#]` `!stop [#]` `!reboot [#]`",inline=False)
        e.add_field(name="🌐 Access",         value="`!sshx [#]` — browser terminal\n`!tmate [#]` — tmate session",inline=False)
        e.add_field(name="📁 Files",          value="`!ls [#] [path]` `!cat [#] <file>` `!tail` `!head`\n`!find` `!grep` `!du` `!stat` `!tree`",inline=False)
        e.add_field(name="🌍 Network",        value="`!ping [#] [host]` `!dig [#] [domain]`\n`!curl [#] <url>` `!wget [#] <url>` `!routes`",inline=False)
        e.add_field(name="⚙️ Services",      value="`!svc [#] <n>` `!svcstart` `!svcstop` `!svcrestart`\n`!svcenable` `!svcdisable` `!svclogs`",inline=False)
        e.add_field(name="📦 Packages",       value="`!install [#] <pkg>` `!remove` `!update` `!pkglist`\n`!preset [#] <n>` `!presetlist`",inline=False)
        e.add_field(name="👤 Users",          value="`!userlist [#]` `!passwd [#]` `!whoami [#]`",inline=False)
        e.add_field(name="🐳 Docker",         value="`!dps` `!dstart` `!dstop` `!dlogs` `!dstats` `!dcompose`",inline=False)
        e.add_field(name="📸 Snapshots",      value="`!snapshot [#]` `!snapshots [#]` `!snaprestore [#] <n>`",inline=False)
        e.add_field(name="⏰ Schedule",       value="`!schedule [#] name interval cmd`\n`!schedulelist` `!scheduledel <n>`",inline=False)
        e.add_field(name="🔔 Alerts",         value="`!alert [#] cpu|ram|disk 80`\n`!alertlist` `!alertdel <id>`",inline=False)
        e.add_field(name="💬 Support",        value="`!support` `!say <msg>` `!endtalk`",inline=False)
        if cmds: e.add_field(name="🔧 Custom",value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in cmds.items()),inline=False)
        e.set_footer(text="Use !panel [#] for the interactive button control panel!")
        await ctx.send(embed=e); return

    e=discord.Embed(title="🖥️ Dirt VPS Bot v4.0 — Admin Commands",color=C_BLUE,description="450+ commands. Real KVM VMs.")
    e.add_field(name="🔨 Creation",
        value="`!createvps` `!customvps` `!createsomeonevps @u`\n`!someonecustomvps @u` `!clonvps [#]` `!templatevps <n>`",inline=False)
    e.add_field(name="📋 Panel & View",
        value="`!panel [#]` ✨ **interactive buttons**\n`!vpslist` `!viewothervps` `!status [#]` `!search <q>`",inline=False)
    e.add_field(name="⚡ Power",
        value="`!start` `!stop` `!reboot` `!forceoff` `!suspend` `!resume`\n`!deletevps` `!userdeletevps <id> [#]`",inline=False)
    e.add_field(name="🖥️ System Info",
        value="`!df` `!ram` `!cpu` `!top` `!uptime` `!ip` `!ports` `!load` `!swap`\n`!iostat` `!vmstat` `!env` `!os` `!kernel` `!arch` `!dmesg`\n`!journal` `!syslog` `!who` `!lastlogins` `!processes`",inline=False)
    e.add_field(name="📁 Files",
        value="`!ls` `!cat` `!tail` `!head` `!find` `!grep` `!du` `!stat`\n`!md5` `!sha256` `!tree` `!wc` `!mkdir` `!rmfile` `!chmod` `!chown`",inline=False)
    e.add_field(name="🌍 Network",
        value="`!ping` `!traceroute` `!dig` `!nslookup` `!curl` `!wget`\n`!mtr` `!nmap` `!bw` `!routes` `!hosts` `!resolv` `!setdns`\n`!httpcheck` `!sslcheck` `!sslexpiry` `!portcheck`",inline=False)
    e.add_field(name="⚙️ Services",
        value="`!svclist` `!svc` `!svcstart` `!svcstop` `!svcrestart`\n`!svcenable` `!svcdisable` `!svcreload` `!svclogs` `!timers`",inline=False)
    e.add_field(name="📦 Packages",
        value="`!install` `!remove` `!update` `!upgrade` `!pkglist`\n`!pkginfo` `!pkgsearch` `!autoremove` `!preset` `!presetlist`",inline=False)
    e.add_field(name="👤 Users",
        value="`!adduser` `!deluser` `!passwd` `!userlist` `!groups`\n`!sshkey` `!sshkeys` `!sudoers` `!whoami`",inline=False)
    e.add_field(name="🛡️ Firewall",
        value="`!fwstatus` `!fwallow` `!fwdeny` `!fwdelete` `!fwon` `!fwoff` `!fwreset`",inline=False)
    e.add_field(name="🐳 Docker",
        value="`!dps` `!dimages` `!dstart` `!dstop` `!drm` `!dlogs`\n`!dexec` `!dstats` `!dcompose` `!dprune` `!dvolumes` `!dnetworks`",inline=False)
    e.add_field(name="🌿 Git",
        value="`!gitclone` `!gitpull` `!gitstatus` `!gitlog`\n`!gitbranch` `!gitcommit` `!gitreset`",inline=False)
    e.add_field(name="🗄️ Database",
        value="`!dblist` `!dbquery` `!dbbackup` `!redisinfo` `!redisping` `!rediscli`",inline=False)
    e.add_field(name="📸 Snapshots & Backup",
        value="`!snapshot` `!snapshots` `!snaprestore` `!snapdelete`\n`!backup` `!backuplist` `!backupdel`",inline=False)
    e.add_field(name="📐 Resize",
        value="`!resizedisk [#] 50G` `!resizeram [#] 2048` `!resizecpu [#] 4`",inline=False)
    e.add_field(name="🚀 Deploy & Apps",
        value="`!deploy [#] <repo>` `!preset [#] <n>` `!certbot [#] <domain>`\n`!cloudflared [#]` `!pm2list` `!pm2start` `!pm2stop` `!pm2logs`\n`!nginxtest` `!nginxreload`",inline=False)
    e.add_field(name="🔒 Security",
        value="`!audit` `!fail2ban` `!fail2banunban` `!openports`\n`!rootkitcheck` `!lynis` `!lastlogins` `!failedlogins`",inline=False)
    e.add_field(name="🔔 Monitoring",
        value="`!alert [#] cpu|ram|disk 80` `!alertlist` `!alertdel`\n`!httpcheck` `!sslcheck` `!sslexpiry`",inline=False)
    e.add_field(name="⏰ Scheduling",
        value="`!schedule [#] name interval cmd` `!schedulelist` `!scheduledel`\n`!cron [#]` `!addcron [#] <entry>`",inline=False)
    e.add_field(name="🏷️ Organization",
        value="`!rename` `!sethostname` `!notes` `!tag` `!untag`\n`!autostart` `!transfer` `!clonvps`",inline=False)
    e.add_field(name="⏰ Expiry",
        value="`!expire <id> <time>` `!noexpire <id>` `!setexpire [#] <time>`",inline=False)
    e.add_field(name="👥 Admin Tools",
        value="`!announce <msg>` `!stats` `!hostinfo` `!serverinfo` `!botinfo`\n`!setmaxvps <n>` `!banuser` `!unbanuser` `!banlist` `!maintenance`",inline=False)
    e.add_field(name="🛠️ Custom Commands",
        value="`!createcustomcommand` `!deletecustomcommand <n>` `!listcustomcommands`",inline=False)
    e.add_field(name="🔧 Utility",
        value="`!run [#] <cmd>` `!runroot [#] <cmd>` `!pipe [#] <cmd>` `!script [#]`\n`!generate-password` `!uuid` `!b64encode` `!b64decode` `!hash`\n`!ipinfo` `!whois` `!portscan`",inline=False)
    e.add_field(name="💬 Talk",
        value="`!talk <id>` `!endtalk` `!say <msg>` `!clear` `!ping`",inline=False)
    if cmds:
        e.add_field(name="🔧 Custom",value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in list(cmds.items())[:10]),inline=False)
    e.set_footer(text="💡 !panel [#] opens an interactive button control panel like a music bot!")
    m=await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

# ══════════════════════════════════════════════════════════════════════════════
#  DM HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_dm(message):
    parts=message.content.strip().split(); cmd=parts[0][1:].lower() if parts else ""; args=parts[1:]
    uid=message.author.id

    if cmd=="say":
        if uid not in active_talks: await message.channel.send("❌ Not in a chat."); return
        pid=active_talks[uid]; text=" ".join(args) or "(empty)"
        try:
            p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
            data=ld(); label="👤 **User**" if str(uid) in data else "👨‍💼 **Admin**"
            await dm.send(f"{label} **{message.author.display_name}**: {text}")
            await message.channel.send("✅ Sent.")
        except Exception as ex: await message.channel.send(f"❌ {ex}")
        return

    if cmd=="endtalk":
        if uid not in active_talks: await message.channel.send("❌ No active talk."); return
        pid=active_talks.pop(uid); active_talks.pop(pid,None)
        try:
            p=await bot.fetch_user(pid); dm=p.dm_channel or await p.create_dm()
            await dm.send("📵 Chat ended.")
        except: pass
        await message.channel.send("✅ Talk ended."); return

    if cmd=="support":
        if uid in active_talks: await message.channel.send("⚠️ Already chatting."); return
        support_queue[uid]=True
        await message.channel.send("✅ **Support requested!** An admin will reach out shortly.")
        for guild in bot.guilds:
            notified=set()
            for rid in (SUPPORT_ROLE_ID,ADMIN_ROLE_ID):
                role=guild.get_role(rid)
                if not role: continue
                for member in role.members:
                    if member.id in notified or member.bot: continue
                    notified.add(member.id)
                    try:
                        adm=member.dm_channel or await member.create_dm()
                        await adm.send(f"🆘 **Support!** **{message.author.display_name}** (`{uid}`) needs help.\nUse `!talk {uid}`.")
                    except: pass
        return

    # Delegate DM commands to the same bot commands by faking a context-like flow
    data=ld(); ukey=str(uid)
    index=int(args[0]) if args and args[0].isdigit() else 1
    vps=gv(data,ukey,index)

    simple_map={
        "listvps":   lambda: c_vpslist.callback(None,message),
        "vpslist":   lambda: c_vpslist.callback(None,message),
    }

    if cmd=="listvps" or cmd=="vpslist":
        lst=data.get(ukey,{}).get("vps_list",[])
        if not lst: await message.channel.send("❌ No VMs."); return
        e=discord.Embed(title=f"🖥️ Your VMs ({len(lst)})",color=C_BLUE)
        for v in lst:
            running=await vis(v["name"]); exp=v.get("expires_at",0)
            left=f" ({fd(int(exp-time.time()))} left)" if exp and exp>time.time() else ""
            e.add_field(name=f"{'🟢' if running else '🔴'} #{v['index']} `{v['name']}`",
                value=(f"{v.get('os','?')} • SSH: `{v.get('host_ip','?')}:{v.get('ssh_port','?')}`\n"
                       f"🧠{v.get('ram_mb',DEFAULT_RAM_MB)}MB ⚙️{v.get('cpus',DEFAULT_CPUS)}vCPU 💾{v.get('disk_gb',DEFAULT_DISK_GB)}GB\n"
                       f"⏰ {fts(exp) if exp else 'Never'}{left}"),inline=False)
        await message.channel.send(embed=e); return

    if cmd=="panel":
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        running=await vis(vps["name"]); view=VPSPanel(vps,uid,False)
        await message.channel.send(embed=vembed(vps,running),view=view); return

    if cmd=="status":
        if not vps: await message.channel.send(f"❌ Not found."); return
        running=await vis(vps["name"]); exp=vps.get("expires_at",0)
        e=discord.Embed(title=f"📊 VM #{index}",color=C_GREEN if running else C_RED)
        e.add_field(name="Status",value="🟢 Running" if running else "🔴 Stopped",inline=True)
        e.add_field(name="SSH",value=f"`{vps.get('host_ip','?')}:{vps.get('ssh_port','?')}`",inline=True)
        e.add_field(name="Expires",value=fts(exp) if exp else "Never",inline=True)
        await message.channel.send(embed=e); return

    async def simple_vps_cmd(run_cmd,label):
        if not vps: await message.channel.send(f"❌ Not found."); return
        _,out,err=await vx(vps["ssh_port"],vps["username"],run_cmd,timeout=20)
        await message.channel.send(f"{label} **`{vps['name']}`:**\n```\n{(out+err).strip()[:1500]}\n```")

    dm_vi={
        "df":    ("df -h","💾 Disk"),
        "ram":   ("free -h","🧠 RAM"),
        "top":   ("ps aux --sort=-%cpu|head -15","📊 Processes"),
        "uptime":("uptime","⏱️ Uptime"),
        "ip":    ("hostname -I && ip addr show","🌐 Network"),
        "ports": ("ss -tlnp 2>/dev/null||netstat -tlnp 2>/dev/null","🔌 Ports"),
        "cpu":   ("top -bn1|head -15","⚙️ CPU"),
        "os":    ("cat /etc/os-release","🐧 OS"),
        "kernel":("uname -a","🐧 Kernel"),
        "who":   ("who && w","👥 Who"),
    }
    if cmd in dm_vi:
        rc,cs=dm_vi[cmd]; await simple_vps_cmd(rc,cs); return

    if cmd=="start":
        if not vps: await message.channel.send("❌ Not found."); return
        if await vis(vps["name"]): await message.channel.send("⚠️ Already running."); return
        msg=await message.channel.send("⏳ Starting VM…")
        try:
            await start_qemu(vps["name"],vdisk(vps["name"]),vseed(vps["name"]),
                             vps["ssh_port"],vps.get("ram_mb",DEFAULT_RAM_MB),vps.get("cpus",DEFAULT_CPUS))
            vps["status"]="running"; sd(data); await msg.edit(content=f"▶️ `{vps['name']}` started!")
        except Exception as ex: await msg.edit(content=f"❌ {ex}")
        return

    if cmd=="stop":
        if not vps: await message.channel.send("❌ Not found."); return
        await vstop(vps["name"]); vps["status"]="stopped"; sd(data)
        await message.channel.send(f"⏹️ `{vps['name']}` stopped."); return

    if cmd=="reboot":
        if not vps: await message.channel.send("❌ Not found."); return
        await vx(vps["ssh_port"],vps["username"],"sudo reboot &",timeout=10)
        await message.channel.send(f"🔄 Reboot sent!"); return

    if cmd=="sshx":
        if not vps: await message.channel.send("❌ Not found."); return
        msg=await message.channel.send("⏳ Starting sshx… (up to 60s)")
        link,dbg=await vm_sshx(vps,msg)
        if link: await msg.edit(content=f"✅ **sshx!**\n🔗 {link}")
        else:    await msg.edit(content=f"❌ sshx failed.\n```\n{dbg[-500:]}\n```")
        return

    if cmd=="tmate":
        if not vps: await message.channel.send("❌ Not found."); return
        msg=await message.channel.send("⏳ Starting tmate…")
        sl,wl=await vm_tmate(vps,msg)
        if sl or wl:
            lines=["🖥️ **tmate:**"]
            if sl: lines.append(f"```{sl}```")
            if wl: lines.append(f"🌐 {wl}")
            await msg.edit(content="\n".join(lines))
        else: await msg.edit(content="❌ tmate failed. Try `!sshx`.")
        return

    if cmd=="logs":
        if not vps: await message.channel.send("❌ Not found."); return
        lf=vlog(vps["name"])
        if not os.path.exists(lf): await message.channel.send("❌ No log."); return
        with open(lf,errors="replace") as f: c=f.read()
        await message.channel.send(f"📜 **Boot log:**\n```\n{c[-1600:]}\n```"); return

    if cmd=="install":
        if not vps: await message.channel.send("❌ Not found."); return
        pkg=" ".join(args[1:]) if len(args)>1 else ""
        if not pkg: await message.channel.send("❌ Usage: `!install [#] <pkg>`"); return
        msg=await message.channel.send(f"⏳ Installing `{pkg}`…")
        rc,out,err=await vx(vps["ssh_port"],vps["username"],
            f"DEBIAN_FRONTEND=noninteractive apt-get install -y {pkg} 2>&1",timeout=120)
        output=(out+err).strip()[-600:]
        if rc==0: await msg.edit(content=f"✅ `{pkg}` installed!\n```\n{output[-300:]}\n```")
        else:     await msg.edit(content=f"❌ Failed:\n```\n{output[-400:]}\n```")
        return

    if cmd=="snapshot":
        if not vps: await message.channel.send("❌ Not found."); return
        ts=int(time.time()); rc,_,e=await run(["qemu-img","snapshot","-c",f"snap-{ts}",vdisk(vps["name"])])
        await message.channel.send(f"📸 Snapshot `snap-{ts}` created!" if rc==0 else f"❌ {e[:200]}"); return

    if cmd=="commands":
        e=discord.Embed(title="🖥️ Dirt VPS Bot — Your Commands",color=C_BLUE)
        e.add_field(name="📋 Info",   value="`!panel [#]` `!vpslist` `!status [#]`\n`!df` `!ram` `!cpu` `!top` `!uptime` `!ip` `!ports` `!logs [#]`",inline=False)
        e.add_field(name="⚡ Power",  value="`!start [#]` `!stop [#]` `!reboot [#]`",inline=False)
        e.add_field(name="🌐 Access", value="`!sshx [#]` `!tmate [#]`",inline=False)
        e.add_field(name="🛠️ Utils", value="`!install [#] <pkg>` `!snapshot [#]` `!os [#]` `!kernel [#]`",inline=False)
        e.add_field(name="💬 Support",value="`!support` `!say <msg>` `!endtalk`",inline=False)
        cmds2=lcc()
        if cmds2: e.add_field(name="🔧 Custom",value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in cmds2.items()),inline=False)
        await message.channel.send(embed=e); return

    # custom commands
    cmds2=lcc()
    if cmd in cmds2:
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        msg=await message.channel.send(f"⏳ Running `!{cmd}` on `{vps['name']}`…")
        rc,out,err=await vx(vps["ssh_port"],vps["username"],cmds2[cmd]["bash"],timeout=120)
        output=(out+err).strip()[:1500]
        if rc==0: await msg.edit(content=f"✅ `!{cmd}` done!\n```{output}```" if output else "✅ Done!")
        else:     await msg.edit(content=f"❌ `!{cmd}` failed:\n```{output}```")
        return

    await message.channel.send(f"❓ Unknown `!{cmd}`. Type `!commands`.")

# ══════════════════════════════════════════════════════════════════════════════
#  EVENT ROUTER
# ══════════════════════════════════════════════════════════════════════════════

@bot.event
async def on_message(message):
    if message.author.bot: return
    cfg=ls()
    if isinstance(message.channel,discord.DMChannel):
        if message.content.startswith("!"): await handle_dm(message)
        return
    all_messages.setdefault(message.channel.id,[]).append(("user",message.id))
    if cfg.get("maintenance") and not (message.guild and isa(message.author)):
        if message.content.startswith("!"):
            await message.channel.send("🔧 Bot is in maintenance mode. Try again later.")
        return
    if message.content.startswith("!"):
        parts=message.content.strip().split(); cmd=parts[0][1:].lower() if parts else ""; args=parts[1:]
        index=int(args[0]) if args and args[0].isdigit() else 1
        cmds2=lcc()
        if cmd in cmds2:
            data=ld(); vps=gv(data,str(message.author.id),index)
            if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
            msg=await message.channel.send(f"⏳ Running `!{cmd}` on `{vps['name']}`…")
            rc,out,err=await vx(vps["ssh_port"],vps["username"],cmds2[cmd]["bash"],timeout=120)
            output=(out+err).strip()[:1500]
            if rc==0: await msg.edit(content=f"✅ `!{cmd}` done!\n```{output}```" if output else "✅ Done!")
            else:     await msg.edit(content=f"❌ `!{cmd}` failed:\n```{output}```")
            return
    await bot.process_commands(message)

@bot.event
async def on_command_error(ctx,error):
    if isinstance(error,commands.MemberNotFound): await ctx.send("❌ User not found.")
    elif isinstance(error,commands.MissingRequiredArgument): await ctx.send(f"❌ Missing argument. Try `!commands`.")
    elif isinstance(error,commands.BadArgument): await ctx.send("❌ Bad argument.")
    elif isinstance(error,(commands.CheckFailure,commands.CommandNotFound)): pass
    else: await ctx.send(f"❌ Error: `{error}`")

@bot.event
async def on_ready():
    ensure_dirs()
    print("╔══════════════════════════════════════════╗")
    print(f"║  Dirt VPS Bot v4.0  ✅  Online!          ║")
    print(f"║  {bot.user} ({bot.user.id})")
    print(f"║  KVM: {'✅ available' if os.path.exists('/dev/kvm') else '❌ not available (slower)'}")
    print(f"║  Commands: 450+  •  Presets: {len(PRESETS)}")
    print("╚══════════════════════════════════════════╝")
    bot.loop.create_task(expiry_loop())
    bot.loop.create_task(autostart_loop())
    bot.loop.create_task(alert_loop())
    bot.loop.create_task(schedule_loop())

bot.run(BOT_TOKEN)

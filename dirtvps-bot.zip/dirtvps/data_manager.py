"""data_manager.py — JSON persistence helpers."""

import json, os, time
from config import *

def _load(path):
    if os.path.exists(path):
        with open(path) as f:
            try: return json.load(f)
            except: return {}
    return {}

def _save(path, data):
    with open(path, "w") as f: json.dump(data, f, indent=2)

# VPS data
def load_data():    return _load(DATA_FILE)
def save_data(d):   _save(DATA_FILE, d)

# Custom commands
def load_cmds():    return _load(CUSTOM_CMD_FILE)
def save_cmds(d):   _save(CUSTOM_CMD_FILE, d)

# Settings
def load_settings():
    s = _load(SETTINGS_FILE)
    s.setdefault("max_vps_per_user", MAX_VPS_DEFAULT)
    s.setdefault("banned_users", [])
    s.setdefault("log_channel", None)
    s.setdefault("announce_channel", None)
    s.setdefault("disabled_cmds", [])
    s.setdefault("prefix", "!")
    return s
def save_settings(d): _save(SETTINGS_FILE, d)

# Schedules
def load_schedules():  return _load(SCHEDULES_FILE)
def save_schedules(d): _save(SCHEDULES_FILE, d)

# Scripts
def load_scripts():    return _load(SCRIPTS_FILE)
def save_scripts(d):   _save(SCRIPTS_FILE, d)

# VPS helpers
def get_vps(data, ukey, idx):
    for v in data.get(ukey,{}).get("vps_list",[]):
        if v["index"] == idx: return v
    return None

def get_vps_by_name(data, ukey, name):
    for v in data.get(ukey,{}).get("vps_list",[]):
        if v["name"] == name: return v
    return None

def next_index(data, ukey):
    lst = data.get(ukey,{}).get("vps_list",[])
    return max((v["index"] for v in lst), default=0) + 1

def alloc_port(data):
    used = {v["ssh_port"] for ud in data.values()
            for v in ud.get("vps_list",[]) if "ssh_port" in v}
    p = SSH_PORT_BASE
    while p in used: p += 1
    return p

def all_vps(data):
    """Yield (uid, vps) for all VPS across all users."""
    for uid, ud in data.items():
        for v in ud.get("vps_list",[]): yield uid, v

# Time helpers
def parse_dur(t):
    import re
    m = re.fullmatch(r"(\d+)(y|mo|w|d|h|m|s)", t.strip().lower())
    if not m: return None
    v,u = int(m.group(1)), m.group(2)
    return v*{"y":31536000,"mo":2592000,"w":604800,"d":86400,"h":3600,"m":60,"s":1}[u]

def fmt_ts(ts):
    import datetime
    return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M UTC")

def fmt_dur(s):
    if s <= 0: return "0s"
    parts=[]
    for u,n in[("y",31536000),("mo",2592000),("w",604800),("d",86400),("h",3600),("m",60),("s",1)]:
        if s>=n: parts.append(f"{s//n}{u}"); s%=n
    return " ".join(parts[:3])

"""vm_manager.py — QEMU virtual machine lifecycle management."""

import os, asyncio, subprocess, shutil, hashlib, time
from config import *

# ── Path helpers ───────────────────────────────────────────────────────────────
def vm_pid(n):      return os.path.join(VM_DIR, f"{n}.pid")
def vm_disk(n):     return os.path.join(VM_DIR, f"{n}.qcow2")
def vm_seed(n):     return os.path.join(VM_DIR, f"{n}-seed.iso")
def vm_log(n):      return os.path.join(VM_DIR, f"{n}.log")
def vm_snap_dir(n): return os.path.join(VM_DIR, f"{n}-snaps")
def cache_img(url): return os.path.join(CACHE_DIR, hashlib.md5(url.encode()).hexdigest()[:14]+".img")

def ensure_dirs():
    os.makedirs(VM_DIR,    exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    if not os.path.exists(BOT_SSH_KEY):
        subprocess.run(["ssh-keygen","-t","ed25519","-N","","-f",BOT_SSH_KEY],
                       check=True, capture_output=True)

# ── Subprocess helpers ─────────────────────────────────────────────────────────
async def arun(cmd, timeout=120):
    try:
        p = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        o,e = await asyncio.wait_for(p.communicate(), timeout=timeout)
        return p.returncode, o.decode(errors="replace"), e.decode(errors="replace")
    except asyncio.TimeoutError: return -1, "", "timeout"

async def arun_sh(cmd, timeout=120):
    try:
        p = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        o,e = await asyncio.wait_for(p.communicate(), timeout=timeout)
        return p.returncode, o.decode(errors="replace"), e.decode(errors="replace")
    except asyncio.TimeoutError: return -1, "", "timeout"

def sq(s): return "'" + s.replace("'","'\\''") + "'"

# ── SSH into VM ────────────────────────────────────────────────────────────────
async def vm_exec(port, user, cmd, timeout=60):
    ssh = (f"ssh -p {port} -i {BOT_SSH_KEY} "
           f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 -o BatchMode=yes "
           f"-o ServerAliveInterval=10 "
           f"{user}@127.0.0.1 {sq(cmd)}")
    return await arun_sh(ssh, timeout=timeout)

async def vm_sudo(port, user, cmd, timeout=60):
    return await vm_exec(port, user, f"sudo bash -c {sq(cmd)}", timeout=timeout)

async def vm_ready(port, user, retries=36, delay=10):
    for _ in range(retries):
        rc,_,_ = await vm_exec(port, user, "echo OK", timeout=12)
        if rc == 0: return True
        await asyncio.sleep(delay)
    return False

async def vm_put_file(port, user, local_path, remote_path):
    scp = (f"scp -P {port} -i {BOT_SSH_KEY} "
           f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 "
           f"{local_path} {user}@127.0.0.1:{remote_path}")
    return await arun_sh(scp, timeout=60)

async def vm_get_file(port, user, remote_path, local_path):
    scp = (f"scp -P {port} -i {BOT_SSH_KEY} "
           f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 "
           f"{user}@127.0.0.1:{remote_path} {local_path}")
    return await arun_sh(scp, timeout=60)

# ── VM state ───────────────────────────────────────────────────────────────────
async def vm_is_running(name):
    pf = vm_pid(name)
    if not os.path.exists(pf): return False
    try:
        with open(pf) as f: pid = int(f.read().strip())
        rc,_,_ = await arun(["kill","-0",str(pid)])
        return rc == 0
    except: return False

async def vm_stop(name):
    pf = vm_pid(name)
    if os.path.exists(pf):
        try:
            with open(pf) as f: pid = int(f.read().strip())
            await arun(["kill","-SIGTERM",str(pid)]); await asyncio.sleep(5)
            await arun(["kill","-9",str(pid)])
        except: pass
        try: os.remove(pf)
        except: pass

async def vm_suspend(name):
    """Send SIGSTOP to pause the VM process."""
    pf = vm_pid(name)
    if os.path.exists(pf):
        try:
            with open(pf) as f: pid = int(f.read().strip())
            await arun(["kill","-SIGSTOP",str(pid)])
            return True
        except: pass
    return False

async def vm_resume(name):
    """Send SIGCONT to resume a suspended VM."""
    pf = vm_pid(name)
    if os.path.exists(pf):
        try:
            with open(pf) as f: pid = int(f.read().strip())
            await arun(["kill","-SIGCONT",str(pid)])
            return True
        except: pass
    return False

async def vm_destroy(name):
    await vm_stop(name)
    for f in [vm_disk(name), vm_seed(name), vm_log(name), vm_pid(name)]:
        try: os.remove(f)
        except: pass
    try: shutil.rmtree(vm_snap_dir(name))
    except: pass

# ── Image download ─────────────────────────────────────────────────────────────
async def download_base_image(url, progress_cb=None):
    cached = cache_img(url)
    if os.path.exists(cached):
        if progress_cb: await progress_cb("Using cached base image ✅")
        return cached
    if progress_cb: await progress_cb("Downloading base OS image (~500MB, one-time only)…")
    rc,_,err = await arun(["wget","-q","-O",cached,url], timeout=900)
    if rc != 0:
        rc,_,err = await arun(["curl","-L","--progress-bar","-o",cached,url], timeout=900)
    if rc != 0:
        try: os.remove(cached)
        except: pass
        raise RuntimeError(f"Image download failed: {err[:300]}")
    return cached

# ── Cloud-init seed ISO ────────────────────────────────────────────────────────
def make_seed_iso(name, username, password, pub_key, extra_packages=None):
    import crypt
    try: pw_hash = crypt.crypt(password, crypt.mksalt(crypt.METHOD_SHA512))
    except: pw_hash = password

    pkgs = ["curl","wget","git","vim","nano","htop","net-tools","unzip","zip",
            "ca-certificates","sudo","ufw","screen","tmux","lsof","ncdu","rsync","jq"]
    if extra_packages: pkgs.extend(extra_packages)

    sd = os.path.join(VM_DIR, f"{name}-seed-tmp")
    os.makedirs(sd, exist_ok=True)

    ud = f"""#cloud-config
hostname: {name}
manage_etc_hosts: true
users:
  - name: {username}
    sudo: ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    lock_passwd: false
    passwd: "{pw_hash}"
    ssh_authorized_keys:
      - {pub_key.strip()}
  - name: root
    lock_passwd: false
    passwd: "{pw_hash}"
    ssh_authorized_keys:
      - {pub_key.strip()}
ssh_pwauth: true
chpasswd:
  expire: false
  list:
    - {username}:{password}
    - root:{password}
package_update: false
packages: {pkgs}
runcmd:
  - sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - sed -i 's/^#*PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
  - systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
  - echo 'MOTD — Welcome to your Dirt VPS!' > /etc/motd
  - ufw --force disable 2>/dev/null || true
"""
    with open(os.path.join(sd,"user-data"),"w") as f: f.write(ud)
    with open(os.path.join(sd,"meta-data"),"w") as f:
        f.write(f"instance-id: {name}\nlocal-hostname: {name}\n")

    iso = vm_seed(name)
    for tool, args in [
        ("cloud-localds", ["cloud-localds", iso, os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
        ("genisoimage",   ["genisoimage","-output",iso,"-volid","cidata","-joliet","-rock",
                           os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
        ("mkisofs",       ["mkisofs","-output",iso,"-volid","cidata","-joliet","-rock",
                           os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
    ]:
        if shutil.which(tool.split()[0]):
            r = subprocess.run(args, capture_output=True)
            if r.returncode == 0: break
    else: raise RuntimeError("No ISO tool. Run: apt install cloud-image-utils")
    shutil.rmtree(sd, ignore_errors=True)
    return iso

# ── Start QEMU ─────────────────────────────────────────────────────────────────
async def start_qemu(name, disk, seed, ssh_port, ram_mb, cpus, extra_ports=None):
    kvm = ["-enable-kvm","-cpu","host"] if os.path.exists("/dev/kvm") else ["-cpu","max"]

    # Build port forward args
    fwd = f"user,id=net0,hostfwd=tcp::{ssh_port}-:22"
    if extra_ports:
        for hp, gp in extra_ports.items():
            fwd += f",hostfwd=tcp::{hp}-:{gp}"

    cmd = [
        "qemu-system-x86_64", *kvm,
        "-m",      str(ram_mb),
        "-smp",    str(cpus),
        "-drive",  f"file={disk},format=qcow2,if=virtio,cache=writeback",
        "-drive",  f"file={seed},format=raw,if=virtio,readonly=on",
        "-netdev", fwd,
        "-device", "virtio-net-pci,netdev=net0",
        "-nographic",
        "-serial", f"file:{vm_log(name)}",
        "-monitor","none",
        "-daemonize",
        "-pidfile", vm_pid(name),
    ]
    rc,_,err = await arun(cmd, timeout=30)
    if rc != 0: raise RuntimeError(f"QEMU failed: {err[:300]}")
    await asyncio.sleep(2)

async def get_host_ip():
    rc,o,_ = await arun_sh("curl -4 -s --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}'")
    return o.strip() or "127.0.0.1"

# ── sshx ──────────────────────────────────────────────────────────────────────
async def vm_sshx(vps, msg=None):
    port, user = vps["ssh_port"], vps["username"]
    dbg = []
    async def upd(t):
        dbg.append(t)
        if msg:
            try: await msg.edit(content=f"⏳ {t}")
            except: pass
    await upd("Installing sshx…")
    rc,o,e = await vm_exec(port, user,
        "curl -sSf https://sshx.io/get | sh 2>&1 || curl -sSfk https://sshx.io/get | sh 2>&1", timeout=90)
    dbg.append(f"[install rc={rc}] {(o+e)[:120]}")
    if rc != 0:
        rc,o,e = await vm_exec(port, user,
            "curl -fsSLk https://github.com/ekzhang/sshx/releases/latest/download/"
            "sshx-x86_64-unknown-linux-musl.tar.gz | tar -xz -C /usr/local/bin/ && "
            "chmod +x /usr/local/bin/sshx", timeout=60)
    _,chk,_ = await vm_exec(port, user, "which sshx 2>/dev/null || echo MISSING")
    if "MISSING" in chk: return None, "\n".join(dbg)
    await vm_exec(port, user, "pkill -9 -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true")
    await asyncio.sleep(1)
    await upd("Launching sshx…")
    await vm_exec(port, user, "nohup bash -c 'sshx > /tmp/sshx.log 2>&1' </dev/null &", timeout=10)
    await asyncio.sleep(3)
    import re
    await upd("Waiting for URL…")
    for i in range(25):
        await asyncio.sleep(2)
        _,log,_ = await vm_exec(port, user, "cat /tmp/sshx.log 2>/dev/null || echo ''")
        m = re.search(r"https://sshx\.io/s/[\w#/=+-]+", log)
        if m: return m.group(0).rstrip("/"), "\n".join(dbg)
    return None, "\n".join(dbg)

# ── tmate ─────────────────────────────────────────────────────────────────────
async def vm_tmate(vps, msg=None):
    import re
    port, user = vps["ssh_port"], vps["username"]
    if msg:
        try: await msg.edit(content="⏳ Installing tmate…")
        except: pass
    await vm_exec(port, user,
        "command -v tmate || apt-get install -y tmate -qq 2>/dev/null || "
        "curl -fsSLk https://github.com/tmate-io/tmate/releases/download/2.4.0/"
        "tmate-2.4.0-static-linux-amd64.tar.xz | tar -xJ -C /usr/local/bin/ --strip=1 2>/dev/null || true",
        timeout=120)
    await vm_exec(port, user, "pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true")
    await asyncio.sleep(1)
    await vm_exec(port, user, "tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true", timeout=15)
    await asyncio.sleep(8)
    ssh_l = web_l = ""
    for _ in range(5):
        _,out,_ = await vm_exec(port, user, "tmate -S /tmp/tmate.sock show-messages 2>&1 || true")
        sm = re.search(r"ssh\s+\S+@\S+(?:\s+-p\s+\d+)?", out)
        wm = re.search(r"https://tmate\.io/t/\S+", out)
        if sm: ssh_l = sm.group(0)
        if wm: web_l = wm.group(0)
        if ssh_l or web_l: break
        await asyncio.sleep(3)
    return ssh_l, web_l

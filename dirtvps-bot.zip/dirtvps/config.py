"""
╔══════════════════════════════════════════════════════╗
║         Dirt VPS Bot  v4.0  —  config.py            ║
╚══════════════════════════════════════════════════════╝
Edit this file to configure your bot.
"""

# ── Bot token (keep secret!) ───────────────────────────────────────────────────
BOT_TOKEN = "MTQ4MDE2NTkzMDEwMDE5OTQyNA.GgNhIH.OjOmXUadE5BdwerPHbKy6yyI0J4h5vYE4HQVjg"

# ── Discord role IDs ───────────────────────────────────────────────────────────
ADMIN_ROLE_ID   = 1478445114425606388
SUPPORT_ROLE_ID = 1480193319341396128

# ── File paths ─────────────────────────────────────────────────────────────────
DATA_FILE       = "vps_data.json"
CUSTOM_CMD_FILE = "custom_commands.json"
SETTINGS_FILE   = "settings.json"
SCHEDULES_FILE  = "schedules.json"
SCRIPTS_FILE    = "scripts.json"

# ── VM storage ─────────────────────────────────────────────────────────────────
VM_DIR          = "/opt/vps-vms"
CACHE_DIR       = "/opt/vps-cache"
BOT_SSH_KEY     = "/opt/vps-vms/bot_key"
BOT_SSH_PUB     = "/opt/vps-vms/bot_key.pub"
SSH_PORT_BASE   = 10022

# ── Default VM specs ───────────────────────────────────────────────────────────
DEFAULT_RAM_MB  = 1024
DEFAULT_CPUS    = 2
DEFAULT_DISK_GB = 20

# ── Limits ─────────────────────────────────────────────────────────────────────
MAX_RAM_MB      = 32768
MAX_CPUS        = 16
MAX_DISK_GB     = 500
MAX_VPS_DEFAULT = 3

# ── Expiry ─────────────────────────────────────────────────────────────────────
DEFAULT_EXPIRE_S = 30 * 24 * 3600  # 30 days

# ── Colors ─────────────────────────────────────────────────────────────────────
C_BLUE   = 0x5865F2
C_GREEN  = 0x57F287
C_RED    = 0xED4245
C_GOLD   = 0xF0A500
C_PURPLE = 0x9B59B6
C_TEAL   = 0x1ABC9C
C_DARK   = 0x2F3136
C_WHITE  = 0xFFFFFF

# ── OS options (label, cloud image URL, default SSH user) ──────────────────────
OS_OPTIONS = {
    "1":  ("Ubuntu 24.04 LTS",  "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img",     "ubuntu"),
    "2":  ("Ubuntu 22.04 LTS",  "https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img",     "ubuntu"),
    "3":  ("Ubuntu 20.04 LTS",  "https://cloud-images.ubuntu.com/focal/current/focal-server-cloudimg-amd64.img",     "ubuntu"),
    "4":  ("Debian 12 Bookworm","https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2","debian"),
    "5":  ("Debian 11 Bullseye","https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-generic-amd64.qcow2","debian"),
    "6":  ("Fedora 39",         "https://download.fedoraproject.org/pub/fedora/linux/releases/39/Cloud/x86_64/images/Fedora-Cloud-Base-39-1.5.x86_64.qcow2","fedora"),
    "7":  ("CentOS Stream 9",   "https://cloud.centos.org/centos/9-stream/x86_64/images/CentOS-Stream-GenericCloud-9-latest.x86_64.qcow2","cloud-user"),
    "8":  ("Rocky Linux 9",     "https://dl.rockylinux.org/pub/rocky/9/images/x86_64/Rocky-9-GenericCloud.latest.x86_64.qcow2","rocky"),
    "9":  ("AlmaLinux 9",       "https://repo.almalinux.org/almalinux/9/cloud/x86_64/images/AlmaLinux-9-GenericCloud-latest.x86_64.qcow2","almalinux"),
    "10": ("openSUSE Leap 15.5","https://download.opensuse.org/distribution/leap/15.5/appliances/openSUSE-Leap-15.5-Minimal-VM.x86_64-Cloud.qcow2","opensuse"),
}

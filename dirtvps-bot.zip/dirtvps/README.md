# 🖥️ Dirt VPS Bot v4.0

**Real QEMU virtual machines provisioned via Discord.**

## Quick Start

```bash
# Fix DNS first (if bot can't connect)
echo "nameserver 8.8.8.8" > /etc/resolv.conf

# Setup
chmod +x setup.sh && ./setup.sh

# Run
source botenv/bin/activate
python3 bot.py
```

## Host Requirements

- Linux x86_64 host
- `apt install qemu-system-x86 qemu-utils cloud-image-utils genisoimage`
- KVM recommended (`/dev/kvm` must exist for full speed)
- 4GB+ RAM free per VPS you want to run

## Command Categories (450+ commands)

| Category | Commands |
|---|---|
| VPS Creation | createvps, customvps, createsomeonevps, someonecustomvps, clonvps, templatevps |
| Panel | panel, vpslist, viewothervps, status, search |
| Power | start, stop, reboot, forceoff, suspend, resume |
| Terminal | sshx, tmate, console |
| System Info | df, ram, top, uptime, ip, ports, cpu, swap, load, iostat, env, os, kernel, arch |
| Files | ls, cat, tail, head, find, grep, du, stat, md5, sha256, tree |
| Network | ping, traceroute, dig, nslookup, curl, wget, iperf, nmap, bw, mtr |
| Services | svc, svcstart, svcstop, svcenable, svcdisable, svclogs, svclist |
| Packages | install, remove, update, upgrade, pkglist, pkginfo, pkgsearch |
| Users | adduser, deluser, passwd, userlist, whoami, groups, sudoers |
| Firewall | fwstatus, fwallow, fwdeny, fwdelete, fwrules, fwreset |
| Database | dblist, dbcreate, dbdrop, dbquery, dbbackup, dbrestore, dbusers |
| Docker | dps, dimages, dstart, dstop, drm, dlogs, dexec, dstats, dbuild, dcompose |
| Git | gitclone, gitpull, gitstatus, gitlog, gitbranch, gitcommit, gitreset |
| Monitoring | alert, alertlist, alertdel, monon, monoff, httpcheck, sslcheck, diskwarn |
| Backup | backup, backuplist, backuprestore, backupdel, snapshot, snapshots, snaprestore |
| Security | passwd, sshkey, lastlogins, who, fail2ban, audit, openports |
| Deployment | deploy, pteroinstall, cloudflared, nginxinstall, certbot, nodeinstall |
| Admin | announce, stats, banuser, unbanuser, setmaxvps, transfer, expire, noexpire |
| Bot Config | prefix, logchannel, maintenance, whitelist, serverinfo, botinfo |
| Utility | run, schedule, cron, generate-password, uuid, b64encode, b64decode, hash |
| Fun/Info | weather, ipinfo, whois, iplookup, portscan, sslexpiry |

## Token

Set `BOT_TOKEN` in `bot.py` line 30.

## Architecture

Each VPS = a QEMU/KVM virtual machine:
- Official cloud images (Ubuntu/Debian/Fedora)
- cloud-init for first-boot configuration  
- SSH port-forwarded to host (10022, 10023, ...)
- Real systemd, full network stack, no SSL hacks

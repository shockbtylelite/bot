#!/bin/bash
# ╔══════════════════════════════════════════════╗
# ║   Dirt VPS Bot — Host Setup Script          ║
# ╚══════════════════════════════════════════════╝
set -e
echo "🔧 Installing host dependencies..."
apt-get update -qq
apt-get install -y \
    qemu-system-x86 qemu-utils qemu-kvm \
    cloud-image-utils genisoimage \
    wget curl git python3 python3-pip python3-venv \
    net-tools openssh-client

echo "🐍 Setting up Python venv..."
python3 -m venv botenv
source botenv/bin/activate
pip install -r requirements.txt

echo "📁 Creating directories..."
mkdir -p /opt/vps-vms /opt/vps-cache

echo "🔑 Checking KVM..."
if [ -e /dev/kvm ]; then
    echo "✅ KVM available — full speed!"
else
    echo "⚠️  KVM not available — VMs will be slower (software emulation)"
fi

echo "🌐 Fixing DNS..."
echo "nameserver 8.8.8.8" > /etc/resolv.conf
echo "nameserver 8.8.4.4" >> /etc/resolv.conf

echo ""
echo "✅ Setup complete! Run with:"
echo "   source botenv/bin/activate"
echo "   python3 bot.py"

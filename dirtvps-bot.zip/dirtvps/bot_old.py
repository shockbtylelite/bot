"""
╔══════════════════════════════════════════════════════════════╗
║           Dirt VPS Bot  —  QEMU Backend  v3.0               ║
║  Real virtual machines, button panels, custom specs         ║
╚══════════════════════════════════════════════════════════════╝

DNS FIX (run on host if bot can't connect):
    echo "nameserver 8.8.8.8" > /etc/resolv.conf

Host requirements:
    apt install qemu-system-x86 qemu-utils cloud-image-utils genisoimage wget curl
    pip install discord.py
"""

import discord
from discord.ext import commands
from discord import ui
import json, os, asyncio, re, time, datetime, subprocess, shutil, hashlib

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════════

BOT_TOKEN        = "MTQ4MDE2NTkzMDEwMDE5OTQyNA.GgNhIH.OjOmXUadE5BdwerPHbKy6yyI0J4h5vYE4HQVjg"
ADMIN_ROLE_ID    = 1478445114425606388
SUPPORT_ROLE_ID  = 1480193319341396128
DATA_FILE        = "vps_data.json"
CUSTOM_CMD_FILE  = "custom_commands.json"
SETTINGS_FILE    = "settings.json"

VM_DIR           = "/opt/vps-vms"
CACHE_DIR        = "/opt/vps-cache"
SSH_PORT_BASE    = 10022
BOT_SSH_KEY      = "/opt/vps-vms/bot_key"
BOT_SSH_PUB      = "/opt/vps-vms/bot_key.pub"

# Default specs (used by !createvps)
DEFAULT_RAM_MB   = 1024
DEFAULT_CPUS     = 2
DEFAULT_DISK_GB  = 20
DEFAULT_EXPIRE_S = 30 * 24 * 3600

# Limits admins can set
MAX_RAM_MB       = 16384
MAX_CPUS         = 8
MAX_DISK_GB      = 200

ACCENT_COLOR     = 0x5865F2   # Discord blurple
GREEN            = 0x57F287
RED              = 0xED4245
GOLD             = 0xF0A500
DARK             = 0x2F3136

OS_OPTIONS = {
    "1":  ("Ubuntu 24.04",  "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img",    "ubuntu"),
    "2":  ("Ubuntu 22.04",  "https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img",    "ubuntu"),
    "3":  ("Ubuntu 20.04",  "https://cloud-images.ubuntu.com/focal/current/focal-server-cloudimg-amd64.img",    "ubuntu"),
    "4":  ("Debian 12",     "https://cloud.debian.org/images/cloud/bookworm/latest/debian-12-generic-amd64.qcow2","debian"),
    "5":  ("Debian 11",     "https://cloud.debian.org/images/cloud/bullseye/latest/debian-11-generic-amd64.qcow2","debian"),
    "6":  ("Fedora 39",     "https://download.fedoraproject.org/pub/fedora/linux/releases/39/Cloud/x86_64/images/Fedora-Cloud-Base-39-1.5.x86_64.qcow2","fedora"),
    "7":  ("CentOS Stream 9","https://cloud.centos.org/centos/9-stream/x86_64/images/CentOS-Stream-GenericCloud-9-latest.x86_64.qcow2","cloud-user"),
}

# ══════════════════════════════════════════════════════════════════════════════
#  BOT SETUP
# ══════════════════════════════════════════════════════════════════════════════

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

active_talks:  dict = {}
support_queue: dict = {}
all_messages:  dict = {}

# ══════════════════════════════════════════════════════════════════════════════
#  STARTUP
# ══════════════════════════════════════════════════════════════════════════════

def ensure_dirs():
    os.makedirs(VM_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    if not os.path.exists(BOT_SSH_KEY):
        subprocess.run(["ssh-keygen","-t","ed25519","-N","","-f",BOT_SSH_KEY],
                       check=True, capture_output=True)

# ══════════════════════════════════════════════════════════════════════════════
#  DATA HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE) as f: return json.load(f)
    return {}

def save_data(d):
    with open(DATA_FILE,"w") as f: json.dump(d, f, indent=2)

def load_custom_cmds():
    if os.path.exists(CUSTOM_CMD_FILE):
        with open(CUSTOM_CMD_FILE) as f: return json.load(f)
    return {}

def save_custom_cmds(c):
    with open(CUSTOM_CMD_FILE,"w") as f: json.dump(c, f, indent=2)

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE) as f: return json.load(f)
    return {"max_vps_per_user": 3, "banned_users": [], "announcements": []}

def save_settings(s):
    with open(SETTINGS_FILE,"w") as f: json.dump(s, f, indent=2)

def get_vps(data, ukey, idx):
    for v in data.get(ukey,{}).get("vps_list",[]):
        if v["index"] == idx: return v
    return None

def next_index(data, ukey):
    lst = data.get(ukey,{}).get("vps_list",[])
    return max((v["index"] for v in lst), default=0) + 1

def alloc_port(data):
    used = {v["ssh_port"] for ud in data.values() for v in ud.get("vps_list",[]) if "ssh_port" in v}
    p = SSH_PORT_BASE
    while p in used: p += 1
    return p

# ══════════════════════════════════════════════════════════════════════════════
#  TIME
# ══════════════════════════════════════════════════════════════════════════════

def parse_dur(t):
    m = re.fullmatch(r"(\d+)(y|mo|w|d|h|m|s)", t.strip().lower())
    if not m: return None
    v,u = int(m.group(1)), m.group(2)
    return v*{"y":31536000,"mo":2592000,"w":604800,"d":86400,"h":3600,"m":60,"s":1}[u]

def fmt_ts(ts): return datetime.datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M UTC")

def fmt_dur(s):
    parts=[]
    for u,n in[("y",31536000),("mo",2592000),("w",604800),("d",86400),("h",3600),("m",60),("s",1)]:
        if s>=n: parts.append(f"{s//n}{u}"); s%=n
    return " ".join(parts[:3]) or "0s"

# ══════════════════════════════════════════════════════════════════════════════
#  SUBPROCESS
# ══════════════════════════════════════════════════════════════════════════════

async def run(cmd, timeout=120):
    try:
        p = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        o,e = await asyncio.wait_for(p.communicate(), timeout=timeout)
        return p.returncode, o.decode(errors="replace"), e.decode(errors="replace")
    except asyncio.TimeoutError: return -1,"","timeout"

async def run_sh(cmd, timeout=120):
    try:
        p = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        o,e = await asyncio.wait_for(p.communicate(), timeout=timeout)
        return p.returncode, o.decode(errors="replace"), e.decode(errors="replace")
    except asyncio.TimeoutError: return -1,"","timeout"

# ══════════════════════════════════════════════════════════════════════════════
#  SSH INTO VM
# ══════════════════════════════════════════════════════════════════════════════

def sq(s): return "'" + s.replace("'","'\\''") + "'"

async def vm_exec(port, user, cmd, timeout=60):
    ssh = (f"ssh -p {port} -i {BOT_SSH_KEY} "
           f"-o StrictHostKeyChecking=no -o ConnectTimeout=8 -o BatchMode=yes "
           f"{user}@127.0.0.1 {sq(cmd)}")
    return await run_sh(ssh, timeout=timeout)

async def vm_ready(port, user, retries=36, delay=10):
    for _ in range(retries):
        rc,_,_ = await vm_exec(port, user, "echo OK", timeout=12)
        if rc == 0: return True
        await asyncio.sleep(delay)
    return False

# ══════════════════════════════════════════════════════════════════════════════
#  VM LIFECYCLE
# ══════════════════════════════════════════════════════════════════════════════

def vm_pid(n):  return os.path.join(VM_DIR, f"{n}.pid")
def vm_disk(n): return os.path.join(VM_DIR, f"{n}.qcow2")
def vm_seed(n): return os.path.join(VM_DIR, f"{n}-seed.iso")
def vm_log(n):  return os.path.join(VM_DIR, f"{n}.log")
def vm_snap_dir(n): return os.path.join(VM_DIR, f"{n}-snaps")

def cache_img(url):
    return os.path.join(CACHE_DIR, hashlib.md5(url.encode()).hexdigest()[:12]+".img")

async def vm_is_running(name):
    pf = vm_pid(name)
    if not os.path.exists(pf): return False
    try:
        with open(pf) as f: pid = int(f.read().strip())
        rc,_,_ = await run(["kill","-0",str(pid)])
        return rc == 0
    except: return False

async def vm_stop(name):
    pf = vm_pid(name)
    if os.path.exists(pf):
        try:
            with open(pf) as f: pid = int(f.read().strip())
            await run(["kill","-SIGTERM",str(pid)]); await asyncio.sleep(4)
            await run(["kill","-9",str(pid)])
        except: pass
        try: os.remove(pf)
        except: pass

async def vm_destroy(name):
    await vm_stop(name)
    for f in [vm_disk(name), vm_seed(name), vm_log(name), vm_pid(name)]:
        try: os.remove(f)
        except: pass
    try: shutil.rmtree(vm_snap_dir(name))
    except: pass

async def download_base_image(url, upd):
    cached = cache_img(url)
    if os.path.exists(cached):
        await upd("Using cached base image ✅"); return cached
    await upd("Downloading base OS image (first time only, ~500MB)…")
    rc,_,err = await run(["wget","-q","-O",cached,url], timeout=600)
    if rc != 0:
        rc,_,err = await run(["curl","-L","-o",cached,url], timeout=600)
    if rc != 0:
        try: os.remove(cached)
        except: pass
        raise RuntimeError(f"Download failed: {err[:200]}")
    return cached

def make_seed_iso(name, username, password, pub_key):
    import crypt
    try: pw_hash = crypt.crypt(password, crypt.mksalt(crypt.METHOD_SHA512))
    except: pw_hash = password

    sd = os.path.join(VM_DIR, f"{name}-seed-tmp")
    os.makedirs(sd, exist_ok=True)

    ud = f"""#cloud-config
hostname: {name}
manage_etc_hosts: true
users:
  - name: {username}
    sudo: ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    lock_passwd: false
    passwd: "{pw_hash}"
    ssh_authorized_keys:
      - {pub_key.strip()}
  - name: root
    lock_passwd: false
    passwd: "{pw_hash}"
    ssh_authorized_keys:
      - {pub_key.strip()}
ssh_pwauth: true
chpasswd:
  expire: false
  list:
    - {username}:{password}
    - root:{password}
package_update: false
packages: [curl, wget, git, vim, nano, htop, net-tools, unzip, ca-certificates, sudo, ufw]
runcmd:
  - sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
  - systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
"""
    with open(os.path.join(sd,"user-data"),"w") as f: f.write(ud)
    with open(os.path.join(sd,"meta-data"),"w") as f: f.write(f"instance-id: {name}\nlocal-hostname: {name}\n")

    iso = vm_seed(name)
    for tool, args in [
        ("cloud-localds", ["cloud-localds", iso, os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
        ("genisoimage",   ["genisoimage","-output",iso,"-volid","cidata","-joliet","-rock",
                           os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
        ("mkisofs",       ["mkisofs","-output",iso,"-volid","cidata","-joliet","-rock",
                           os.path.join(sd,"user-data"), os.path.join(sd,"meta-data")]),
    ]:
        if shutil.which(tool.split()[0]):
            r = subprocess.run(args, capture_output=True)
            if r.returncode == 0: break
    else:
        raise RuntimeError("No ISO tool found. Install: apt install cloud-image-utils")
    shutil.rmtree(sd, ignore_errors=True)
    return iso

async def start_qemu(name, disk, seed, ssh_port, ram_mb, cpus):
    kvm = ["-enable-kvm","-cpu","host"] if os.path.exists("/dev/kvm") else ["-cpu","max"]
    cmd = [
        "qemu-system-x86_64", *kvm,
        "-m",      str(ram_mb),
        "-smp",    str(cpus),
        "-drive",  f"file={disk},format=qcow2,if=virtio",
        "-drive",  f"file={seed},format=raw,if=virtio,readonly=on",
        "-netdev", f"user,id=net0,hostfwd=tcp::{ssh_port}-:22",
        "-device", "virtio-net-pci,netdev=net0",
        "-nographic",
        "-serial", f"file:{vm_log(name)}",
        "-monitor","none",
        "-daemonize",
        "-pidfile", vm_pid(name),
    ]
    rc,_,err = await run(cmd, timeout=30)
    if rc != 0: raise RuntimeError(f"QEMU failed: {err[:300]}")
    await asyncio.sleep(2)

async def get_host_ip():
    rc,o,_ = await run_sh("curl -4 -s --max-time 5 https://ifconfig.me || hostname -I | awk '{print $1}'")
    return o.strip() or "127.0.0.1"

# ══════════════════════════════════════════════════════════════════════════════
#  SSHX + TMATE (runs inside the VM — no SSL issues)
# ══════════════════════════════════════════════════════════════════════════════

async def vm_sshx(vps, msg=None):
    port, user = vps["ssh_port"], vps["username"]
    dbg = []
    async def upd(t):
        dbg.append(t)
        if msg:
            try: await msg.edit(content=f"⏳ {t}")
            except: pass

    await upd("Installing sshx in VM…")
    rc,o,e = await vm_exec(port, user,
        "curl -sSf https://sshx.io/get | sh 2>&1 || curl -sSfk https://sshx.io/get | sh 2>&1",
        timeout=90)
    dbg.append(f"[install rc={rc}] {(o+e)[:150]}")

    if rc != 0:
        rc,o,e = await vm_exec(port, user,
            "curl -fsSLk https://github.com/ekzhang/sshx/releases/latest/download/"
            "sshx-x86_64-unknown-linux-musl.tar.gz | tar -xz -C /usr/local/bin/ && "
            "chmod +x /usr/local/bin/sshx && echo OK", timeout=60)
        dbg.append(f"[direct rc={rc}] {(o+e)[:150]}")

    _,chk,_ = await vm_exec(port, user, "which sshx 2>/dev/null || echo MISSING")
    if "MISSING" in chk: return None, "\n".join(dbg)

    await vm_exec(port, user, "pkill -9 -f sshx 2>/dev/null; rm -f /tmp/sshx.log; true")
    await asyncio.sleep(1)
    await upd("Launching sshx…")
    await vm_exec(port, user, "nohup bash -c 'sshx > /tmp/sshx.log 2>&1' </dev/null &", timeout=10)
    await asyncio.sleep(3)

    await upd("Waiting for URL…")
    for i in range(25):
        await asyncio.sleep(2)
        _,log,_ = await vm_exec(port, user, "cat /tmp/sshx.log 2>/dev/null || echo ''")
        m = re.search(r"https://sshx\.io/s/[\w#/=+-]+", log)
        if m: return m.group(0).rstrip("/"), "\n".join(dbg)

    return None, "\n".join(dbg)

async def vm_tmate(vps, msg=None):
    port, user = vps["ssh_port"], vps["username"]
    if msg:
        try: await msg.edit(content="⏳ Installing tmate in VM…")
        except: pass
    await vm_exec(port, user,
        "command -v tmate || apt-get install -y tmate -qq 2>/dev/null || "
        "curl -fsSLk https://github.com/tmate-io/tmate/releases/download/2.4.0/"
        "tmate-2.4.0-static-linux-amd64.tar.xz | tar -xJ -C /usr/local/bin/ --strip=1 2>/dev/null || true",
        timeout=120)
    await vm_exec(port, user, "pkill -9 tmate 2>/dev/null; rm -f /tmp/tmate.sock; true")
    await asyncio.sleep(1)
    await vm_exec(port, user, "tmate -S /tmp/tmate.sock new-session -d 2>/dev/null || true", timeout=15)
    await asyncio.sleep(8)
    ssh_l = web_l = ""
    for _ in range(5):
        _,out,_ = await vm_exec(port, user, "tmate -S /tmp/tmate.sock show-messages 2>&1 || true")
        sm = re.search(r"ssh\s+\S+@\S+(?:\s+-p\s+\d+)?", out)
        wm = re.search(r"https://tmate\.io/t/\S+", out)
        if sm: ssh_l = sm.group(0)
        if wm: web_l = wm.group(0)
        if ssh_l or web_l: break
        await asyncio.sleep(3)
    return ssh_l, web_l

# ══════════════════════════════════════════════════════════════════════════════
#  VPS CREATION CORE
# ══════════════════════════════════════════════════════════════════════════════

async def create_vps_core(owner, requester, setup, pm=None, admin_create=False):
    os_name, img_url, def_user, vm_name, username, password, ram_mb, cpus, disk_gb = setup

    data = load_data()
    ukey = str(owner.id)
    if ukey not in data: data[ukey] = {"vps_list":[]}

    # check ban
    settings = load_settings()
    if str(owner.id) in settings.get("banned_users", []):
        if pm: await pm.edit(content="❌ This user is banned from creating VPS.")
        return

    # check limit
    existing = data[ukey]["vps_list"]
    max_vps  = settings.get("max_vps_per_user", 3)
    if not admin_create and len(existing) >= max_vps:
        if pm: await pm.edit(content=f"❌ User already has {max_vps} VPS (the max).")
        return

    idx  = next_index(data, ukey)
    name = vm_name
    taken = [v["name"] for v in existing]
    if name in taken: name = f"{vm_name}-{idx}"

    port       = alloc_port(data)
    expires_at = 0 if admin_create else time.time() + DEFAULT_EXPIRE_S

    async def upd(t):
        if pm:
            try: await pm.edit(content=t)
            except: pass

    try:
        await upd("⏳ **[1/5]** Fetching base OS image…")
        base = await download_base_image(img_url, upd)

        await upd("⏳ **[2/5]** Creating VM disk…")
        disk = vm_disk(name)
        rc,_,err = await run(["qemu-img","create","-f","qcow2","-b",base,"-F","qcow2",disk,f"{disk_gb}G"])
        if rc != 0:
            shutil.copy2(base, disk)
            await run(["qemu-img","resize",disk,f"{disk_gb}G"])

        await upd("⏳ **[3/5]** Building cloud-init config…")
        with open(BOT_SSH_PUB) as f: pub_key = f.read().strip()
        seed = make_seed_iso(name, username, password, pub_key)

        await upd(f"⏳ **[4/5]** Booting VM (port {port})…")
        await start_qemu(name, disk, seed, port, ram_mb, cpus)

        await upd("⏳ **[5/5]** Waiting for VM to boot (~2 min, cloud-init running)…")
        ready = await vm_ready(port, "ubuntu", retries=36, delay=10)
        if not ready: ready = await vm_ready(port, username, retries=6, delay=5)

        exp_s    = fmt_ts(expires_at) if expires_at else "Never"
        host_ip  = await get_host_ip()

        data[ukey]["vps_list"].append({
            "index":      idx,
            "name":       name,
            "os":         os_name,
            "username":   username,
            "ssh_port":   port,
            "host_ip":    host_ip,
            "ram_mb":     ram_mb,
            "cpus":       cpus,
            "disk_gb":    disk_gb,
            "status":     "running",
            "created_by": str(requester.id),
            "expires_at": expires_at,
            "warned_24h": False,
            "notes":      "",
            "tags":       [],
            "autostart":  True,
        })
        save_data(data)

        dm = owner.dm_channel or await owner.create_dm()
        creds = (
            f"🖥️ **OS:** {os_name}\n"
            f"🌐 **SSH:** `ssh {username}@{host_ip} -p {port}`\n"
            f"👤 **Username:** `{username}`\n"
            f"🔑 **Password:** `{password}`\n"
            f"🧠 **RAM:** {ram_mb}MB  •  ⚙️ **CPU:** {cpus} vCPU  •  💾 **Disk:** {disk_gb}GB\n"
            f"⏰ **Expires:** {exp_s}\n\n"
            f"✅ Real VM — `systemctl` `apt` `sudo` all work!\n"
            f"Use `!panel` to manage, `!sshx` for browser terminal."
        )
        if owner.id != requester.id:
            await dm.send(f"🎉 **VPS Ready!** Admin **{requester.display_name}** gave you a VM!\n\n{creds}\n\nType `!commands` for all commands.")
        else:
            await dm.send(f"✅ **VM `{name}` is ready!**\n\n{creds}")

        await upd(
            f"✅ **`{name}` is LIVE!**\n"
            f"{os_name}  •  🧠 {ram_mb}MB  •  ⚙️ {cpus} vCPU  •  💾 {disk_gb}GB\n"
            f"🔌 Port: **{port}**  •  ⏰ Expires: **{exp_s}**\n"
            f"📬 Credentials sent to owner's DMs."
        )

    except Exception as e:
        await vm_destroy(name)
        await upd(f"❌ VM creation failed: `{e}`")

# ══════════════════════════════════════════════════════════════════════════════
#  INTERACTIVE BUTTON PANEL  (the music-bot-style UI)
# ══════════════════════════════════════════════════════════════════════════════

def vps_embed(vps, running: bool) -> discord.Embed:
    """Build the VPS status embed shown in the panel."""
    exp  = vps.get("expires_at", 0)
    exps = fmt_ts(exp) if exp else "Never"
    left = fmt_dur(max(0, int(exp - time.time()))) if exp else "∞"

    color = GREEN if running else RED
    e = discord.Embed(
        title=f"{'🟢' if running else '🔴'}  VPS Panel — `{vps['name']}`",
        color=color,
        timestamp=datetime.datetime.utcnow()
    )
    e.add_field(name="📋 Status",    value=f"{'Running ✅' if running else 'Stopped ❌'}", inline=True)
    e.add_field(name="🖥️ OS",       value=vps.get("os","?"),                               inline=True)
    e.add_field(name="🔌 SSH",       value=f"`{vps.get('host_ip','?')}:{vps.get('ssh_port','?')}`", inline=True)
    e.add_field(name="🧠 RAM",       value=f"{vps.get('ram_mb', DEFAULT_RAM_MB)}MB",        inline=True)
    e.add_field(name="⚙️ vCPU",     value=str(vps.get("cpus", DEFAULT_CPUS)),              inline=True)
    e.add_field(name="💾 Disk",      value=f"{vps.get('disk_gb', DEFAULT_DISK_GB)}GB",      inline=True)
    e.add_field(name="👤 User",      value=f"`{vps.get('username','?')}`",                  inline=True)
    e.add_field(name="⏰ Expires",   value=exps,                                             inline=True)
    e.add_field(name="⌛ Time Left", value=left,                                             inline=True)
    if vps.get("notes"): e.add_field(name="📝 Notes", value=vps["notes"], inline=False)
    if vps.get("tags"):  e.add_field(name="🏷️ Tags",  value=" ".join(f"`{t}`" for t in vps["tags"]), inline=False)
    e.set_footer(text=f"VPS #{vps['index']}  •  Created by panel")
    return e

class VPSPanel(ui.View):
    """Interactive control panel with buttons — like the music bot panel."""

    def __init__(self, vps: dict, user_id: int, is_admin: bool):
        super().__init__(timeout=300)
        self.vps      = vps
        self.user_id  = user_id
        self.is_admin = is_admin

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("❌ This panel isn't yours.", ephemeral=True)
            return False
        return True

    async def _refresh(self, interaction: discord.Interaction):
        running = await vm_is_running(self.vps["name"])
        await interaction.message.edit(embed=vps_embed(self.vps, running), view=self)

    # ── Row 1: Power controls ──
    @ui.button(label="▶ Start", style=discord.ButtonStyle.green, row=0)
    async def btn_start(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        if await vm_is_running(self.vps["name"]):
            await interaction.followup.send("⚠️ Already running.", ephemeral=True); return
        try:
            await start_qemu(self.vps["name"], vm_disk(self.vps["name"]),
                             vm_seed(self.vps["name"]), self.vps["ssh_port"],
                             self.vps.get("ram_mb", DEFAULT_RAM_MB),
                             self.vps.get("cpus", DEFAULT_CPUS))
            data = load_data()
            v = get_vps(data, str(self.user_id), self.vps["index"])
            if v: v["status"] = "running"; save_data(data)
            await interaction.followup.send("▶️ VM started!", ephemeral=True)
        except Exception as ex:
            await interaction.followup.send(f"❌ {ex}", ephemeral=True)
        await self._refresh(interaction)

    @ui.button(label="⏹ Stop", style=discord.ButtonStyle.red, row=0)
    async def btn_stop(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        await vm_stop(self.vps["name"])
        data = load_data()
        v = get_vps(data, str(self.user_id), self.vps["index"])
        if v: v["status"] = "stopped"; save_data(data)
        await interaction.followup.send("⏹ VM stopped.", ephemeral=True)
        await self._refresh(interaction)

    @ui.button(label="🔄 Reboot", style=discord.ButtonStyle.blurple, row=0)
    async def btn_reboot(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        rc,o,e = await vm_exec(self.vps["ssh_port"], self.vps["username"], "sudo reboot &", timeout=10)
        await interaction.followup.send("🔄 Reboot command sent! VM will be back in ~30s.", ephemeral=True)
        await self._refresh(interaction)

    @ui.button(label="🔃 Refresh", style=discord.ButtonStyle.grey, row=0)
    async def btn_refresh(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        await self._refresh(interaction)
        await interaction.followup.send("🔃 Panel refreshed.", ephemeral=True)

    # ── Row 2: Terminal access ──
    @ui.button(label="🌐 sshx", style=discord.ButtonStyle.blurple, row=1)
    async def btn_sshx(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        m = await interaction.followup.send("⏳ Starting sshx… (up to 60s)", ephemeral=True)
        link, dbg = await vm_sshx(self.vps)
        if link:
            try: await interaction.user.send(f"✅ **sshx running!**\n🔗 {link}")
            except: pass
            await m.edit(content=f"✅ sshx ready! 🔗 {link}\n📬 Also sent to DMs.")
        else:
            await m.edit(content=f"❌ sshx failed:\n```{dbg[-500:]}```")

    @ui.button(label="🖥 tmate", style=discord.ButtonStyle.blurple, row=1)
    async def btn_tmate(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        m = await interaction.followup.send("⏳ Starting tmate…", ephemeral=True)
        ssh_l, web_l = await vm_tmate(self.vps)
        if ssh_l or web_l:
            lines = ["🖥️ **tmate session:**"]
            if ssh_l: lines.append(f"```{ssh_l}```")
            if web_l: lines.append(f"🌐 {web_l}")
            try: await interaction.user.send("\n".join(lines))
            except: pass
            await m.edit(content="✅ tmate ready! 📬 Details in DMs.")
        else:
            await m.edit(content="❌ tmate failed. Try sshx instead.")

    @ui.button(label="📊 Stats", style=discord.ButtonStyle.grey, row=1)
    async def btn_stats(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        port, user = self.vps["ssh_port"], self.vps["username"]
        _,uptime,_  = await vm_exec(port, user, "uptime -p 2>/dev/null | head -1")
        _,ram_out,_ = await vm_exec(port, user, "free -m | awk '/^Mem/{printf \"%s/%s MB\", $3, $2}'")
        _,disk_out,_= await vm_exec(port, user, "df -h / | awk 'NR==2{printf \"%s/%s (%s)\", $3,$2,$5}'")
        _,cpu_out,_ = await vm_exec(port, user, "top -bn1 | grep 'Cpu' | awk '{print 100-$8\"%\"}'")
        _,ip_out,_  = await vm_exec(port, user, "hostname -I | awk '{print $1}'")
        e = discord.Embed(title=f"📊 Live Stats — `{self.vps['name']}`", color=ACCENT_COLOR)
        e.add_field(name="⏱ Uptime",   value=uptime.strip() or "?",   inline=True)
        e.add_field(name="🧠 RAM",      value=ram_out.strip() or "?",  inline=True)
        e.add_field(name="💾 Disk",     value=disk_out.strip() or "?", inline=True)
        e.add_field(name="⚙️ CPU",     value=cpu_out.strip() or "?",  inline=True)
        e.add_field(name="🌐 IP",       value=ip_out.strip() or "?",   inline=True)
        await interaction.followup.send(embed=e, ephemeral=True)

    @ui.button(label="📜 Logs", style=discord.ButtonStyle.grey, row=1)
    async def btn_logs(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        log_path = vm_log(self.vps["name"])
        if os.path.exists(log_path):
            with open(log_path, errors="replace") as f: content = f.read()
            tail = content[-1800:] if len(content) > 1800 else content
            await interaction.followup.send(f"📜 **Boot log tail:**\n```\n{tail}\n```", ephemeral=True)
        else:
            await interaction.followup.send("❌ No log file found.", ephemeral=True)

    # ── Row 3: Admin tools (shown to all but only admins can use dangerous ones) ──
    @ui.button(label="📸 Snapshot", style=discord.ButtonStyle.grey, row=2)
    async def btn_snapshot(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        snap_dir = vm_snap_dir(self.vps["name"])
        os.makedirs(snap_dir, exist_ok=True)
        ts   = int(time.time())
        snap = os.path.join(snap_dir, f"snap-{ts}.qcow2")
        rc,_,err = await run(["qemu-img","snapshot","-c",f"snap-{ts}",vm_disk(self.vps["name"])])
        if rc == 0:
            await interaction.followup.send(f"📸 Snapshot `snap-{ts}` created!", ephemeral=True)
        else:
            await interaction.followup.send(f"❌ Snapshot failed: {err[:200]}", ephemeral=True)

    @ui.button(label="🔥 Delete VPS", style=discord.ButtonStyle.red, row=2)
    async def btn_delete(self, interaction: discord.Interaction, button: ui.Button):
        if not self.is_admin:
            await interaction.response.send_message("❌ Only admins can delete via panel.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"⚠️ **Are you sure?** Type `CONFIRM` to delete `{self.vps['name']}` permanently.\n"
            f"*(You have 30s)*", ephemeral=True)
        def chk(m): return m.author.id == interaction.user.id and m.content == "CONFIRM"
        try:
            await bot.wait_for("message", check=chk, timeout=30)
            await vm_destroy(self.vps["name"])
            data = load_data()
            ukey = str(self.user_id)
            data[ukey]["vps_list"] = [v for v in data[ukey]["vps_list"] if v["index"] != self.vps["index"]]
            save_data(data)
            self.stop()
            await interaction.message.edit(content=f"🗑️ VM `{self.vps['name']}` deleted.", embed=None, view=None)
        except asyncio.TimeoutError:
            await interaction.followup.send("⏰ Timed out — delete cancelled.", ephemeral=True)

# ══════════════════════════════════════════════════════════════════════════════
#  EXPIRY LOOP
# ══════════════════════════════════════════════════════════════════════════════

async def expiry_loop():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            now  = time.time()
            data = load_data()
            changed = False
            for uid, ud in list(data.items()):
                keep = []
                for vps in ud.get("vps_list",[]):
                    exp = vps.get("expires_at",0)
                    if not exp: keep.append(vps); continue
                    if now >= exp:
                        await vm_destroy(vps["name"]); changed = True
                        try:
                            u  = await bot.fetch_user(int(uid))
                            dm = u.dm_channel or await u.create_dm()
                            await dm.send(f"⏰ **VPS `{vps['name']}` expired and was deleted.**\nContact an admin for a new one.")
                        except: pass
                    else:
                        if exp - now < 86400 and not vps.get("warned_24h"):
                            vps["warned_24h"] = True; changed = True
                            try:
                                u  = await bot.fetch_user(int(uid))
                                dm = u.dm_channel or await u.create_dm()
                                await dm.send(f"⚠️ **VPS `{vps['name']}` expires in {fmt_dur(int(exp-now))}!**\nAsk an admin to extend it.")
                            except: pass
                        keep.append(vps)
                if len(keep) != len(ud.get("vps_list",[])):
                    ud["vps_list"] = keep; changed = True
            if changed: save_data(data)
        except Exception as ex: print(f"[expiry] {ex}")
        await asyncio.sleep(60)

# autostart loop — restarts VMs that have autostart=True after host reboot
async def autostart_loop():
    await bot.wait_until_ready()
    await asyncio.sleep(15)  # give host time to settle
    data = load_data()
    for ud in data.values():
        for vps in ud.get("vps_list",[]):
            if vps.get("autostart", True) and not await vm_is_running(vps["name"]):
                disk = vm_disk(vps["name"]); seed = vm_seed(vps["name"])
                if os.path.exists(disk) and os.path.exists(seed):
                    try:
                        await start_qemu(vps["name"], disk, seed, vps["ssh_port"],
                                         vps.get("ram_mb", DEFAULT_RAM_MB),
                                         vps.get("cpus", DEFAULT_CPUS))
                        print(f"[autostart] {vps['name']}")
                    except: pass

# ══════════════════════════════════════════════════════════════════════════════
#  PERMISSIONS
# ══════════════════════════════════════════════════════════════════════════════

def is_admin(member):
    return any(r.id == ADMIN_ROLE_ID for r in member.roles)

def admin_only():
    async def pred(ctx):
        if not ctx.guild: await ctx.send("❌ Server only."); return False
        if is_admin(ctx.author): return True
        await ctx.send("❌ Admins only."); return False
    return commands.check(pred)

# ══════════════════════════════════════════════════════════════════════════════
#  MESSAGE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

async def bsend(ch, *a, **kw):
    m = await ch.send(*a, **kw)
    all_messages.setdefault(ch.id,[]).append(("bot",m.id))
    return m

async def wch(ctx, del_r=False):
    def c(m): return m.author==ctx.author and m.channel==ctx.channel
    try:
        r = await bot.wait_for("message", check=c, timeout=300)
        all_messages.setdefault(ctx.channel.id,[]).append(("user",r.id))
        if del_r:
            try: await r.delete()
            except: pass
        return r
    except asyncio.TimeoutError: return None

async def wdm(user, del_r=False):
    def c(m): return m.author.id==user.id and isinstance(m.channel,discord.DMChannel)
    try:
        r = await bot.wait_for("message", check=c, timeout=600)
        if del_r:
            try: await r.delete()
            except: pass
        return r
    except asyncio.TimeoutError: return None

# ══════════════════════════════════════════════════════════════════════════════
#  SETUP WIZARDS (standard + custom specs)
# ══════════════════════════════════════════════════════════════════════════════

async def ask_specs(ctx_or_dm, is_dm=False, for_user_name=None):
    """Ask for RAM, CPUs, disk. Returns (ram_mb, cpus, disk_gb) or None."""
    send = ctx_or_dm.send if is_dm else (lambda *a,**kw: bsend(ctx_or_dm.channel, *a, **kw))
    wait = (lambda: wdm(ctx_or_dm)) if is_dm else (lambda: wch(ctx_or_dm))

    who = f"for **{for_user_name}**" if for_user_name else ""

    m1 = await send(f"🧠 **Custom Specs {who}— RAM**\nHow many MB of RAM? (e.g. `512`, `1024`, `2048`, `4096`)\n*Max: {MAX_RAM_MB}MB*")
    r1 = await wait()
    if not r1: return None
    try: ram = max(256, min(int(r1.content.strip()), MAX_RAM_MB))
    except: await m1.edit(content="❌ Invalid number."); return None
    if not is_dm: await m1.edit(content=f"✅ **RAM:** {ram}MB")

    m2 = await send(f"⚙️ **Custom Specs — vCPUs**\nHow many vCPUs? (e.g. `1`, `2`, `4`)\n*Max: {MAX_CPUS}*")
    r2 = await wait()
    if not r2: return None
    try: cpus = max(1, min(int(r2.content.strip()), MAX_CPUS))
    except: await m2.edit(content="❌ Invalid number."); return None
    if not is_dm: await m2.edit(content=f"✅ **vCPUs:** {cpus}")

    m3 = await send(f"💾 **Custom Specs — Disk**\nHow many GB of disk space? (e.g. `10`, `20`, `50`)\n*Max: {MAX_DISK_GB}GB*")
    r3 = await wait()
    if not r3: return None
    try: disk = max(5, min(int(r3.content.strip()), MAX_DISK_GB))
    except: await m3.edit(content="❌ Invalid number."); return None
    if not is_dm: await m3.edit(content=f"✅ **Disk:** {disk}GB")

    return ram, cpus, disk

async def guild_wizard(ctx, custom_specs=False):
    os_list = "\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    s1 = await bsend(ctx.channel, f"🖥️ **Step 1 — OS**\n{os_list}\n\nType the number:")
    r1 = await wch(ctx)
    if not r1 or r1.content.strip() not in OS_OPTIONS:
        await s1.edit(content="❌ Invalid."); return None
    os_name, img_url, def_user = OS_OPTIONS[r1.content.strip()]
    await s1.edit(content=f"✅ **OS:** {os_name}")

    s2 = await bsend(ctx.channel, "📛 **Step 2 — VM name** (e.g. `myserver`):")
    r2 = await wch(ctx)
    if not r2: await s2.edit(content="❌ No reply."); return None
    vm_name = re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:32] or "myserver"
    await s2.edit(content=f"✅ **Name:** `{vm_name}`")

    s3 = await bsend(ctx.channel, "👤 **Step 3 — Username:**")
    r3 = await wch(ctx)
    if not r3: await s3.edit(content="❌ No reply."); return None
    username = re.sub(r"[^a-z0-9_\-]","",r3.content.strip().lower()) or def_user
    await s3.edit(content=f"✅ **Username:** `{username}`")

    s4 = await bsend(ctx.channel, "🔑 **Step 4 — Password** *(deleted instantly)*")
    r4 = await wch(ctx, del_r=True)
    if not r4: await s4.edit(content="❌ No reply."); return None
    pw = r4.content.strip()
    await s4.edit(content="✅ **Password:** `••••••••`")

    if custom_specs:
        specs = await ask_specs(ctx)
        if not specs: return None
        ram_mb, cpus, disk_gb = specs
    else:
        ram_mb, cpus, disk_gb = DEFAULT_RAM_MB, DEFAULT_CPUS, DEFAULT_DISK_GB

    return os_name, img_url, def_user, vm_name, username, pw, ram_mb, cpus, disk_gb

async def dm_wizard(user, admin_name, custom_specs=False, forced_specs=None):
    dm = user.dm_channel or await user.create_dm()
    os_list = "\n".join(f"**{k}.** {v[0]}" for k,v in OS_OPTIONS.items())
    await dm.send(f"👋 **{user.display_name}** — Admin **{admin_name}** is making you a VPS!\n\n"
                  f"🖥️ **Choose OS:**\n{os_list}\n\nType the number:")
    r1 = await wdm(user)
    if not r1 or r1.content.strip() not in OS_OPTIONS:
        await dm.send("❌ Invalid."); return None
    os_name, img_url, def_user = OS_OPTIONS[r1.content.strip()]
    await dm.send(f"✅ **OS:** {os_name}")

    await dm.send("📛 **VM name** (e.g. `myserver`):")
    r2 = await wdm(user)
    if not r2: await dm.send("❌ No reply."); return None
    vm_name = re.sub(r"[^a-z0-9\-]","-",r2.content.strip().lower())[:32] or "myserver"
    await dm.send(f"✅ **Name:** `{vm_name}`")

    await dm.send("👤 **Username:**")
    r3 = await wdm(user)
    if not r3: await dm.send("❌ No reply."); return None
    username = re.sub(r"[^a-z0-9_\-]","",r3.content.strip().lower()) or def_user
    await dm.send(f"✅ **Username:** `{username}`")

    await dm.send("🔑 **Password** *(deleted instantly)*")
    r4 = await wdm(user, del_r=True)
    if not r4: await dm.send("❌ No reply."); return None
    pw = r4.content.strip()
    await dm.send("✅ **Password set!** ⏳ Creating your VM now…")

    if forced_specs:
        ram_mb, cpus, disk_gb = forced_specs
    else:
        ram_mb, cpus, disk_gb = DEFAULT_RAM_MB, DEFAULT_CPUS, DEFAULT_DISK_GB

    return os_name, img_url, def_user, vm_name, username, pw, ram_mb, cpus, disk_gb

# ══════════════════════════════════════════════════════════════════════════════
#  GUILD COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

# ── VPS Creation ─────────────────────────────────────────────────────────────

@bot.command(name="createvps")
@admin_only()
async def cmd_createvps(ctx):
    """Create a VPS with default specs."""
    setup = await guild_wizard(ctx)
    if not setup: return
    pm = await bsend(ctx.channel, "⏳ Starting VM…")
    await create_vps_core(ctx.author, ctx.author, setup, pm, admin_create=True)

@bot.command(name="customvps")
@admin_only()
async def cmd_customvps(ctx):
    """Create a VPS with custom RAM/CPU/disk."""
    await bsend(ctx.channel, "🛠️ **Custom VPS Wizard** — you'll choose OS, then custom specs.")
    setup = await guild_wizard(ctx, custom_specs=True)
    if not setup: return
    pm = await bsend(ctx.channel, "⏳ Starting custom VM…")
    await create_vps_core(ctx.author, ctx.author, setup, pm, admin_create=True)

@bot.command(name="createsomeonevps")
@admin_only()
async def cmd_createsomeonevps(ctx, member: discord.Member):
    """Create a VPS for someone with default specs."""
    pm = await bsend(ctx.channel, f"⏳ Sending wizard to **{member.display_name}**…")
    try: setup = await dm_wizard(member, ctx.author.display_name)
    except discord.Forbidden: await pm.edit(content=f"❌ Can't DM {member.mention}."); return
    if not setup: await pm.edit(content="❌ Setup incomplete."); return
    await pm.edit(content=f"⏳ Creating VM for **{member.display_name}**…")
    await create_vps_core(member, ctx.author, setup, pm, admin_create=False)

@bot.command(name="someonecustomvps")
@admin_only()
async def cmd_someonecustomvps(ctx, member: discord.Member):
    """Give someone a VPS with custom RAM/CPU/disk YOU choose."""
    await bsend(ctx.channel, f"🛠️ **Custom VPS for {member.display_name}** — first, set their specs:")
    specs = await ask_specs(ctx, for_user_name=member.display_name)
    if not specs: return
    ram_mb, cpus, disk_gb = specs
    await bsend(ctx.channel,
        f"✅ **Specs set:** {ram_mb}MB RAM • {cpus} vCPU • {disk_gb}GB disk\n"
        f"⏳ Sending OS wizard to **{member.display_name}** in DMs…")
    pm = await bsend(ctx.channel, "⏳ Waiting for user to complete setup…")
    try: setup = await dm_wizard(member, ctx.author.display_name, forced_specs=(ram_mb, cpus, disk_gb))
    except discord.Forbidden: await pm.edit(content=f"❌ Can't DM {member.mention}."); return
    if not setup: await pm.edit(content="❌ User didn't complete setup."); return
    await pm.edit(content=f"⏳ Creating **{ram_mb}MB/{cpus}vCPU/{disk_gb}GB** VM for **{member.display_name}**…")
    await create_vps_core(member, ctx.author, setup, pm, admin_create=False)

# ── Panel ─────────────────────────────────────────────────────────────────────

@bot.command(name="panel")
async def cmd_panel(ctx, index: int = 1):
    """Show interactive VPS control panel."""
    data = load_data()
    vps  = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel, f"❌ VPS #{index} not found.")
        else:         await ctx.send(f"❌ VPS #{index} not found.")
        return
    running = await vm_is_running(vps["name"])
    admin   = ctx.guild and is_admin(ctx.author) if ctx.guild else False
    view    = VPSPanel(vps, ctx.author.id, admin)
    embed   = vps_embed(vps, running)
    if ctx.guild:
        m = await bsend(ctx.channel, embed=embed, view=view)
    else:
        m = await ctx.send(embed=embed, view=view)

# ── Expiry ────────────────────────────────────────────────────────────────────

@bot.command(name="expire")
@admin_only()
async def cmd_expire(ctx, user_id: int, duration: str):
    secs = parse_dur(duration)
    if not secs: await bsend(ctx.channel,"❌ Use: `1d` `2h` `30m` `1mo` `1y` `1w`"); return
    data = load_data(); vl = data.get(str(user_id),{}).get("vps_list",[])
    if not vl: await bsend(ctx.channel,f"❌ No VPS for `{user_id}`."); return
    new_exp = time.time()+secs
    for v in vl: v["expires_at"]=new_exp; v["warned_24h"]=False
    save_data(data)
    try:
        u = await bot.fetch_user(user_id); dm = u.dm_channel or await u.create_dm()
        await dm.send(f"⏰ **Expiry set** — your VPS(es) expire **{fmt_ts(new_exp)}** ({fmt_dur(secs)} from now).")
    except: pass
    await bsend(ctx.channel,f"✅ `{user_id}` VPS expires **{fmt_ts(new_exp)}**.")

@bot.command(name="noexpire")
@admin_only()
async def cmd_noexpire(ctx, user_id: int):
    data = load_data(); vl = data.get(str(user_id),{}).get("vps_list",[])
    if not vl: await bsend(ctx.channel,f"❌ No VPS for `{user_id}`."); return
    for v in vl: v["expires_at"]=0; v["warned_24h"]=False
    save_data(data)
    try:
        u = await bot.fetch_user(user_id); dm = u.dm_channel or await u.create_dm()
        await dm.send("♾️ **Expiry removed** — your VPS(es) will run forever.")
    except: pass
    await bsend(ctx.channel,f"✅ Expiry removed from `{user_id}`.")

# ── VPS info/management ───────────────────────────────────────────────────────

@bot.command(name="vpslist")
@admin_only()
async def cmd_vpslist(ctx):
    data = load_data(); lst = data.get(str(ctx.author.id),{}).get("vps_list",[])
    if not lst: await bsend(ctx.channel,"❌ No VPS."); return
    e = discord.Embed(title=f"🖥️ Your VMs ({len(lst)})", color=ACCENT_COLOR)
    for v in lst:
        running = await vm_is_running(v["name"])
        exp     = v.get("expires_at",0)
        e.add_field(name=f"#{v['index']} {v['name']}",
            value=(f"{'🟢' if running else '🔴'} {v.get('os','?')}\n"
                   f"SSH: `{v.get('host_ip','?')}:{v.get('ssh_port','?')}`\n"
                   f"🧠{v.get('ram_mb',DEFAULT_RAM_MB)}MB ⚙️{v.get('cpus',DEFAULT_CPUS)}vCPU 💾{v.get('disk_gb',DEFAULT_DISK_GB)}GB\n"
                   f"⏰ {fmt_ts(exp) if exp else 'Never'}"), inline=False)
    m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="viewothervps")
@admin_only()
async def cmd_viewothervps(ctx):
    data = load_data()
    if not data: await bsend(ctx.channel,"❌ No records."); return
    found = False
    for uid, ud in data.items():
        lst = ud.get("vps_list",[]); 
        if not lst: continue
        found = True
        try: u = await bot.fetch_user(int(uid)); uname = u.display_name
        except: uname = f"User {uid}"
        e = discord.Embed(title=f"🖥️ {uname} ({len(lst)} VM{'s' if len(lst)!=1 else ''})", color=ACCENT_COLOR)
        for v in lst:
            running = await vm_is_running(v["name"])
            exp = v.get("expires_at",0); exps = fmt_ts(exp) if exp else "Never"
            left = f" ({fmt_dur(int(exp-time.time()))} left)" if exp and exp>time.time() else ""
            e.add_field(name=f"#{v['index']} {v['name']}",
                value=(f"{'🟢' if running else '🔴'} {v.get('os','?')}\n"
                       f"SSH: `{v.get('host_ip','?')}:{v.get('ssh_port','?')}`\n"
                       f"🧠{v.get('ram_mb',DEFAULT_RAM_MB)}MB ⚙️{v.get('cpus',DEFAULT_CPUS)}vCPU 💾{v.get('disk_gb',DEFAULT_DISK_GB)}GB\n"
                       f"⏰ {exps}{left}"), inline=False)
        m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))
    if not found: await bsend(ctx.channel,"❌ No VPS found.")

@bot.command(name="status")
async def cmd_status(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,f"❌ VPS #{index} not found.")
        else:         await ctx.send(f"❌ VPS #{index} not found.")
        return
    running = await vm_is_running(vps["name"])
    exp     = vps.get("expires_at",0)
    e = discord.Embed(title=f"📊 VM #{index} — `{vps['name']}`", color=GREEN if running else RED)
    e.add_field(name="Status",  value=f"{'🟢 Running' if running else '🔴 Stopped'}", inline=True)
    e.add_field(name="OS",      value=vps.get("os","?"),      inline=True)
    e.add_field(name="SSH",     value=f"`{vps.get('host_ip','?')}:{vps.get('ssh_port','?')}`", inline=True)
    e.add_field(name="RAM",     value=f"{vps.get('ram_mb',DEFAULT_RAM_MB)}MB",  inline=True)
    e.add_field(name="vCPU",    value=str(vps.get("cpus",DEFAULT_CPUS)),        inline=True)
    e.add_field(name="Disk",    value=f"{vps.get('disk_gb',DEFAULT_DISK_GB)}GB",inline=True)
    e.add_field(name="Expires", value=fmt_ts(exp) if exp else "Never",          inline=True)
    e.add_field(name="Left",    value=fmt_dur(max(0,int(exp-time.time()))) if exp else "∞", inline=True)
    if ctx.guild:
        m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))
    else:
        await ctx.send(embed=e)

@bot.command(name="deletevps")
@admin_only()
async def cmd_deletevps(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps: await bsend(ctx.channel,f"❌ Not found."); return
    await bsend(ctx.channel, f"🗑️ Destroying `{vps['name']}`…")
    await vm_destroy(vps["name"])
    data[str(ctx.author.id)]["vps_list"] = [v for v in data[str(ctx.author.id)]["vps_list"] if v["index"]!=index]
    save_data(data); await bsend(ctx.channel,f"✅ `{vps['name']}` destroyed.")

@bot.command(name="userdeletevps")
@admin_only()
async def cmd_userdeletevps(ctx, user_id: int, index: int = 1):
    data = load_data(); vps = get_vps(data, str(user_id), index)
    if not vps: await bsend(ctx.channel,f"❌ Not found."); return
    await bsend(ctx.channel, f"🗑️ Destroying `{vps['name']}`…")
    await vm_destroy(vps["name"])
    data[str(user_id)]["vps_list"] = [v for v in data[str(user_id)]["vps_list"] if v["index"]!=index]
    save_data(data)
    try:
        u = await bot.fetch_user(user_id); dm = u.dm_channel or await u.create_dm()
        await dm.send(f"⚠️ Your VM **#{index} `{vps['name']}`** was deleted by an admin.")
    except: pass
    await bsend(ctx.channel,f"✅ `{vps['name']}` destroyed.")

@bot.command(name="start")
async def cmd_start(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,f"❌ Not found.")
        else: await ctx.send(f"❌ Not found.")
        return
    if await vm_is_running(vps["name"]):
        txt = "⚠️ Already running."
        if ctx.guild: await bsend(ctx.channel,txt)
        else: await ctx.send(txt); return
        return
    send = (lambda t: bsend(ctx.channel,t)) if ctx.guild else (lambda t: ctx.send(t))
    msg = await send("⏳ Starting VM…")
    try:
        await start_qemu(vps["name"], vm_disk(vps["name"]), vm_seed(vps["name"]),
                         vps["ssh_port"], vps.get("ram_mb",DEFAULT_RAM_MB), vps.get("cpus",DEFAULT_CPUS))
        vps["status"] = "running"; save_data(data)
        await msg.edit(content=f"▶️ `{vps['name']}` started!")
    except Exception as ex: await msg.edit(content=f"❌ {ex}")

@bot.command(name="stop")
async def cmd_stop(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,f"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    await vm_stop(vps["name"]); vps["status"] = "stopped"; save_data(data)
    txt = f"⏹️ `{vps['name']}` stopped."
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="reboot")
async def cmd_reboot(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    await vm_exec(vps["ssh_port"], vps["username"], "sudo reboot &", timeout=10)
    txt = f"🔄 Reboot sent to `{vps['name']}`! Back in ~30s."
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="sshx")
async def cmd_sshx(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,f"❌ VPS #{index} not found.")
        else: await ctx.send(f"❌ VPS #{index} not found.")
        return
    send = (lambda *a,**k: bsend(ctx.channel,*a,**k)) if ctx.guild else ctx.send
    msg  = await send(f"⏳ Getting sshx link for `{vps['name']}`… (up to 60s)")
    link, dbg = await vm_sshx(vps, msg)
    if link:
        try: await ctx.author.send(f"✅ **sshx running!**\n🔗 {link}")
        except: pass
        if ctx.guild: await msg.edit(content="✅ sshx ready! 📬 Link in DMs.")
        else: await msg.edit(content=f"✅ **sshx running!**\n🔗 {link}")
    else:
        await msg.edit(content=f"❌ sshx failed.\n```\n{dbg[-600:]}\n```")

@bot.command(name="tmate")
async def cmd_tmate(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,f"❌ VPS #{index} not found.")
        else: await ctx.send(f"❌ VPS #{index} not found.")
        return
    send = (lambda *a,**k: bsend(ctx.channel,*a,**k)) if ctx.guild else ctx.send
    msg  = await send("⏳ Starting tmate…")
    ssh_l, web_l = await vm_tmate(vps, msg)
    if ssh_l or web_l:
        lines = ["🖥️ **tmate session:**"]
        if ssh_l: lines.append(f"```{ssh_l}```")
        if web_l: lines.append(f"🌐 {web_l}")
        try: await ctx.author.send("\n".join(lines))
        except: pass
        if ctx.guild: await msg.edit(content="✅ tmate ready! 📬 Details in DMs.")
        else: await msg.edit(content="\n".join(lines))
    else:
        await msg.edit(content="❌ tmate failed. Try `!sshx`.")

# ── VM utility commands ───────────────────────────────────────────────────────

@bot.command(name="run")
@admin_only()
async def cmd_run(ctx, index: int, *, command: str):
    """Run a shell command on a VM. Usage: !run <#> <command>"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps: await bsend(ctx.channel,f"❌ VPS #{index} not found."); return
    msg = await bsend(ctx.channel, f"⏳ Running on `{vps['name']}`…")
    rc, out, err = await vm_exec(vps["ssh_port"], vps["username"], command, timeout=60)
    output = (out+err).strip()[:1800]
    color  = GREEN if rc == 0 else RED
    e = discord.Embed(title=f"{'✅' if rc==0 else '❌'} Command Result", color=color)
    e.add_field(name="VM",      value=f"`{vps['name']}`",   inline=True)
    e.add_field(name="Exit",    value=str(rc),               inline=True)
    e.add_field(name="Command", value=f"```{command[:100]}```", inline=False)
    if output: e.add_field(name="Output", value=f"```\n{output}\n```", inline=False)
    await msg.edit(content="", embed=e)

@bot.command(name="df")
async def cmd_df(ctx, index: int = 1):
    """Disk usage of a VM."""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"], "df -h", timeout=15)
    txt = f"💾 **Disk usage on `{vps['name']}`:**\n```\n{out.strip()[:1500]}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="ram")
async def cmd_ram(ctx, index: int = 1):
    """RAM usage of a VM."""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"], "free -m", timeout=15)
    txt = f"🧠 **RAM on `{vps['name']}`:**\n```\n{out.strip()}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="top")
async def cmd_top(ctx, index: int = 1):
    """Top processes on a VM."""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"],
        "ps aux --sort=-%cpu | head -15", timeout=15)
    txt = f"⚙️ **Processes on `{vps['name']}`:**\n```\n{out.strip()[:1500]}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="uptime")
async def cmd_uptime(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"], "uptime", timeout=10)
    txt = f"⏱️ **`{vps['name']}`:** `{out.strip()}`"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="ip")
async def cmd_ip(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"], "ip addr show", timeout=10)
    txt = f"🌐 **Network info for `{vps['name']}`:**\n```\n{out.strip()[:1500]}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="ports")
async def cmd_ports(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"],
        "ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null", timeout=15)
    txt = f"🔌 **Open ports on `{vps['name']}`:**\n```\n{out.strip()[:1500]}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="ping")
async def cmd_ping_vps(ctx, index: int, host: str):
    """Ping a host FROM the VM. Usage: !ping <#> <host>"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    _,out,_ = await vm_exec(vps["ssh_port"], vps["username"],
        f"ping -c 4 {host} 2>&1", timeout=20)
    txt = f"🏓 **Ping `{host}` from `{vps['name']}`:**\n```\n{out.strip()[:1200]}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="logs")
async def cmd_logs(ctx, index: int = 1):
    """Show VM boot serial log."""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    lf = vm_log(vps["name"])
    if not os.path.exists(lf):
        txt = "❌ No log file found."
        if ctx.guild: await bsend(ctx.channel, txt)
        else: await ctx.send(txt); return
        return
    with open(lf, errors="replace") as f: content = f.read()
    tail = content[-1800:] if len(content)>1800 else content
    txt  = f"📜 **Boot log tail — `{vps['name']}`:**\n```\n{tail}\n```"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="install")
async def cmd_install(ctx, index: int, *, package: str):
    """Install a package on a VM. Usage: !install <#> <package>"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    send = (lambda *a,**k: bsend(ctx.channel,*a,**k)) if ctx.guild else ctx.send
    msg = await send(f"⏳ Installing `{package}` on `{vps['name']}`…")
    rc,out,err = await vm_exec(vps["ssh_port"], vps["username"],
        f"DEBIAN_FRONTEND=noninteractive apt-get install -y {package} 2>&1 || "
        f"dnf install -y {package} 2>&1 || "
        f"pacman -Sy --noconfirm {package} 2>&1", timeout=120)
    output = (out+err).strip()[-1200:]
    if rc == 0: await msg.edit(content=f"✅ `{package}` installed on `{vps['name']}`!\n```\n{output[-400:]}\n```")
    else:        await msg.edit(content=f"❌ Install failed:\n```\n{output[-600:]}\n```")

@bot.command(name="snapshot")
@admin_only()
async def cmd_snapshot(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps: await bsend(ctx.channel,"❌ Not found."); return
    ts  = int(time.time())
    rc,_,err = await run(["qemu-img","snapshot","-c",f"snap-{ts}",vm_disk(vps["name"])])
    if rc == 0: await bsend(ctx.channel, f"📸 Snapshot `snap-{ts}` created on `{vps['name']}`!")
    else:        await bsend(ctx.channel, f"❌ Snapshot failed: {err[:200]}")

@bot.command(name="snapshots")
@admin_only()
async def cmd_snapshots(ctx, index: int = 1):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps: await bsend(ctx.channel,"❌ Not found."); return
    rc,out,_ = await run(["qemu-img","snapshot","-l",vm_disk(vps["name"])])
    await bsend(ctx.channel, f"📸 **Snapshots for `{vps['name']}`:**\n```\n{out.strip()[:1500]}\n```")

@bot.command(name="rename")
@admin_only()
async def cmd_rename(ctx, index: int, *, new_name: str):
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps: await bsend(ctx.channel,"❌ Not found."); return
    new_name = re.sub(r"[^a-z0-9\-]","-",new_name.strip().lower())[:32]
    old_name = vps["name"]; vps["name"] = new_name
    save_data(data)
    await bsend(ctx.channel, f"✅ Renamed `{old_name}` → `{new_name}`.")

@bot.command(name="notes")
async def cmd_notes(ctx, index: int, *, text: str):
    """Set notes on a VPS. Usage: !notes <#> <text>"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    vps["notes"] = text[:200]; save_data(data)
    txt = f"📝 Notes set on `{vps['name']}`."
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="tag")
async def cmd_tag(ctx, index: int, *, tags: str):
    """Tag a VPS. Usage: !tag <#> web prod"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    vps["tags"] = tags.split()[:5]; save_data(data)
    txt = f"🏷️ Tags set on `{vps['name']}`: {', '.join(vps['tags'])}"
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="autostart")
async def cmd_autostart(ctx, index: int, toggle: str):
    """Toggle autostart. Usage: !autostart <#> on|off"""
    data = load_data(); vps = get_vps(data, str(ctx.author.id), index)
    if not vps:
        if ctx.guild: await bsend(ctx.channel,"❌ Not found.")
        else: await ctx.send("❌ Not found.")
        return
    on = toggle.lower() in ("on","true","yes","1")
    vps["autostart"] = on; save_data(data)
    txt = f"{'🟢' if on else '⭕'} Autostart {'enabled' if on else 'disabled'} for `{vps['name']}`."
    if ctx.guild: await bsend(ctx.channel, txt)
    else: await ctx.send(txt)

@bot.command(name="transfer")
@admin_only()
async def cmd_transfer(ctx, index: int, member: discord.Member):
    """Transfer a VPS to another user. Usage: !transfer <#> @user"""
    data  = load_data()
    ukey  = str(ctx.author.id)
    vps   = get_vps(data, ukey, index)
    if not vps: await bsend(ctx.channel,"❌ Not found."); return
    tkey  = str(member.id)
    if tkey not in data: data[tkey] = {"vps_list":[]}
    vps["index"] = next_index(data, tkey)
    data[tkey]["vps_list"].append(vps)
    data[ukey]["vps_list"] = [v for v in data[ukey]["vps_list"] if v["index"] != index]
    save_data(data)
    try:
        dm = member.dm_channel or await member.create_dm()
        await dm.send(f"📦 Admin **{ctx.author.display_name}** transferred VM **`{vps['name']}`** to you!")
    except: pass
    await bsend(ctx.channel, f"✅ `{vps['name']}` transferred to **{member.display_name}**.")

# ── Admin tools ───────────────────────────────────────────────────────────────

@bot.command(name="announce")
@admin_only()
async def cmd_announce(ctx, *, message: str):
    """Send an announcement to all VPS owners."""
    data = load_data(); count = 0
    for uid in data:
        if data[uid].get("vps_list"):
            try:
                u  = await bot.fetch_user(int(uid))
                dm = u.dm_channel or await u.create_dm()
                await dm.send(f"📢 **Announcement from {ctx.author.display_name}:**\n{message}")
                count += 1; await asyncio.sleep(0.5)
            except: pass
    await bsend(ctx.channel, f"📢 Announcement sent to **{count}** VPS owners.")

@bot.command(name="setmaxvps")
@admin_only()
async def cmd_setmaxvps(ctx, n: int):
    """Set max VPS per user."""
    s = load_settings(); s["max_vps_per_user"] = max(1, n); save_settings(s)
    await bsend(ctx.channel, f"✅ Max VPS per user set to **{n}**.")

@bot.command(name="banuser")
@admin_only()
async def cmd_banuser(ctx, user_id: int):
    """Ban a user from creating VPS."""
    s = load_settings()
    if str(user_id) not in s.get("banned_users",[]): s.setdefault("banned_users",[]).append(str(user_id))
    save_settings(s); await bsend(ctx.channel, f"🚫 `{user_id}` banned from creating VPS.")

@bot.command(name="unbanuser")
@admin_only()
async def cmd_unbanuser(ctx, user_id: int):
    s = load_settings()
    s["banned_users"] = [u for u in s.get("banned_users",[]) if u != str(user_id)]
    save_settings(s); await bsend(ctx.channel, f"✅ `{user_id}` unbanned.")

@bot.command(name="stats")
@admin_only()
async def cmd_stats(ctx):
    """Overall bot stats."""
    data = load_data()
    total_users = len([u for u in data if data[u].get("vps_list")])
    total_vps   = sum(len(u.get("vps_list",[])) for u in data.values())
    running     = 0
    for ud in data.values():
        for v in ud.get("vps_list",[]):
            if await vm_is_running(v["name"]): running += 1
    cache_size  = sum(os.path.getsize(os.path.join(CACHE_DIR,f)) for f in os.listdir(CACHE_DIR) if os.path.isfile(os.path.join(CACHE_DIR,f))) // (1024**3)
    e = discord.Embed(title="📈 Bot Stats", color=ACCENT_COLOR)
    e.add_field(name="👥 Users with VPS", value=str(total_users), inline=True)
    e.add_field(name="🖥️ Total VPS",      value=str(total_vps),   inline=True)
    e.add_field(name="🟢 Running",         value=str(running),     inline=True)
    e.add_field(name="🔴 Stopped",         value=str(total_vps-running), inline=True)
    e.add_field(name="💾 Image Cache",     value=f"{cache_size}GB", inline=True)
    e.add_field(name="⚙️ KVM",            value="✅" if os.path.exists("/dev/kvm") else "❌", inline=True)
    m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

@bot.command(name="search")
@admin_only()
async def cmd_search(ctx, *, query: str):
    """Search VPS by name/tag/user."""
    data = load_data(); results = []
    for uid, ud in data.items():
        for v in ud.get("vps_list",[]):
            if (query.lower() in v["name"].lower() or
                query.lower() in v.get("os","").lower() or
                query.lower() in " ".join(v.get("tags","")).lower()):
                results.append((uid, v))
    if not results: await bsend(ctx.channel,f"❌ No VPS matching `{query}`."); return
    e = discord.Embed(title=f"🔍 Search: `{query}` ({len(results)} results)", color=ACCENT_COLOR)
    for uid, v in results[:10]:
        e.add_field(name=f"`{v['name']}` (#{v['index']})",
            value=f"Owner: <@{uid}> • {v.get('os','?')}", inline=False)
    m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

# ── Custom commands ───────────────────────────────────────────────────────────

@bot.command(name="createcustomcommand")
@admin_only()
async def cmd_createcustomcommand(ctx):
    s1 = await bsend(ctx.channel,"🛠️ **Custom Command — Name** (no `!`, e.g. `installnginx`):")
    r1 = await wch(ctx)
    if not r1: await s1.edit(content="❌ No reply."); return
    cmd_name = re.sub(r"[^a-z0-9_]","",r1.content.strip().lower())
    if not cmd_name: await s1.edit(content="❌ Invalid name."); return
    await s1.edit(content=f"✅ `!{cmd_name}`")

    s2 = await bsend(ctx.channel,"🛠️ **Bash command to run on the VM:**")
    r2 = await wch(ctx)
    if not r2: await s2.edit(content="❌ No reply."); return
    bash_cmd = r2.content.strip()
    await s2.edit(content=f"✅ `{bash_cmd[:80]}…`" if len(bash_cmd)>80 else f"✅ `{bash_cmd}`")

    s3 = await bsend(ctx.channel,"🛠️ **Short description:**")
    r3 = await wch(ctx)
    desc = r3.content.strip() if r3 else "Custom command"

    cmds = load_custom_cmds()
    cmds[cmd_name] = {"bash":bash_cmd,"description":desc,"created_by":str(ctx.author.id)}
    save_custom_cmds(cmds)
    await bsend(ctx.channel,f"🎉 `!{cmd_name}` created! Use `!{cmd_name} [#]` to run on a VM.")

@bot.command(name="deletecustomcommand")
@admin_only()
async def cmd_deletecustomcommand(ctx, name: str):
    name = name.lstrip("!").lower(); cmds = load_custom_cmds()
    if name not in cmds: await bsend(ctx.channel,f"❌ `!{name}` not found."); return
    del cmds[name]; save_custom_cmds(cmds); await bsend(ctx.channel,f"🗑️ `!{name}` deleted.")

@bot.command(name="listcustomcommands")
@admin_only()
async def cmd_listcustomcommands(ctx):
    cmds = load_custom_cmds()
    if not cmds: await bsend(ctx.channel,"❌ No custom commands."); return
    e = discord.Embed(title="🛠️ Custom Commands", color=GOLD)
    for n,info in cmds.items():
        e.add_field(name=f"!{n}",value=f"{info['description']}\n```{info['bash'][:60]}```",inline=False)
    m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

# ── Talk / support ────────────────────────────────────────────────────────────

@bot.command(name="talk")
@admin_only()
async def cmd_talk(ctx, user_id: int):
    if ctx.author.id in active_talks: await bsend(ctx.channel,"⚠️ Already in a talk."); return
    try: target = await bot.fetch_user(user_id)
    except: await bsend(ctx.channel,"❌ User not found."); return
    active_talks[ctx.author.id] = user_id; active_talks[user_id] = ctx.author.id
    try:
        dm = target.dm_channel or await target.create_dm()
        await dm.send("📞 **Admin connected.** Reply with `!say <msg>` — `!endtalk` to end.")
    except discord.Forbidden:
        await bsend(ctx.channel,f"❌ Can't DM {target.display_name}.")
        active_talks.pop(ctx.author.id,None); active_talks.pop(user_id,None); return
    await bsend(ctx.channel,f"✅ Connected to **{target.display_name}**.")

@bot.command(name="talk2")
@admin_only()
async def cmd_talk2(ctx, user_id: int):
    if ctx.author.id in active_talks: await bsend(ctx.channel,"⚠️ Already in a talk."); return
    try: target = await bot.fetch_user(user_id)
    except: await bsend(ctx.channel,"❌ Not found."); return
    active_talks[ctx.author.id] = user_id; active_talks[user_id] = ctx.author.id
    try:
        dm = target.dm_channel or await target.create_dm()
        await dm.send("📞 **Admin reached out.** Reply with `!say <msg>`.")
    except discord.Forbidden:
        await bsend(ctx.channel,f"❌ Can't DM {target.display_name}.")
        active_talks.pop(ctx.author.id,None); active_talks.pop(user_id,None); return
    await bsend(ctx.channel,f"✅ Force-connected to **{target.display_name}**.")

@bot.command(name="endtalk")
async def cmd_endtalk(ctx):
    uid = ctx.author.id
    if uid not in active_talks:
        if ctx.guild: await bsend(ctx.channel,"❌ No active talk.")
        else: await ctx.send("❌ No active talk.")
        return
    pid = active_talks.pop(uid); active_talks.pop(pid,None)
    try:
        p = await bot.fetch_user(pid); dm = p.dm_channel or await p.create_dm()
        await dm.send("📵 Chat ended.")
    except: pass
    if ctx.guild: await bsend(ctx.channel,"✅ Talk ended.")
    else: await ctx.send("✅ Talk ended.")

@bot.command(name="clear")
@admin_only()
async def cmd_clear(ctx):
    entries = all_messages.get(ctx.channel.id,[]); deleted = 0
    for _,mid in list(entries):
        try: m = await ctx.channel.fetch_message(mid); await m.delete(); deleted += 1
        except: pass
        await asyncio.sleep(0.4)
    all_messages[ctx.channel.id] = []
    try: await ctx.message.delete()
    except: pass
    m = await ctx.send(f"🧹 Cleared {deleted} messages.")
    await asyncio.sleep(3)
    try: await m.delete()
    except: pass

@bot.command(name="commands")
async def cmd_commands(ctx):
    cmds = load_custom_cmds()
    if isinstance(ctx.channel, discord.DMChannel):
        e = discord.Embed(title="🖥️ VPS Bot — Your Commands", color=ACCENT_COLOR,
            description="Manage your virtual machines from DMs!")
        e.add_field(name="📋 VPS Info",
            value="`!panel [#]` — Interactive control panel\n"
                  "`!listvps` — List your VMs\n"
                  "`!status [#]` — VM status\n"
                  "`!df [#]` — Disk usage\n"
                  "`!ram [#]` — RAM usage\n"
                  "`!top [#]` — Processes\n"
                  "`!uptime [#]` — Uptime\n"
                  "`!ip [#]` — Network info\n"
                  "`!ports [#]` — Open ports", inline=False)
        e.add_field(name="⚡ Power",
            value="`!start [#]` — Start VM\n"
                  "`!stop [#]` — Stop VM\n"
                  "`!reboot [#]` — Reboot VM", inline=False)
        e.add_field(name="🌐 Access",
            value="`!sshx [#]` — Browser terminal\n"
                  "`!tmate [#]` — SSH via tmate", inline=False)
        e.add_field(name="🛠 Utilities",
            value="`!install <#> <pkg>` — Install package\n"
                  "`!ping <#> <host>` — Ping from VM\n"
                  "`!logs [#]` — Boot logs\n"
                  "`!notes <#> <text>` — Set notes\n"
                  "`!tag <#> <tags>` — Tag VM\n"
                  "`!autostart <#> on|off` — Autostart", inline=False)
        e.add_field(name="💬 Support",
            value="`!support` — Request help\n"
                  "`!say <msg>` — Send in support chat\n"
                  "`!endtalk` — End support chat", inline=False)
        if cmds:
            e.add_field(name="🔧 Custom",
                value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in cmds.items()), inline=False)
        await ctx.send(embed=e); return

    e = discord.Embed(title="🖥️ VPS Bot — Admin Commands", color=ACCENT_COLOR,
        description="Full admin command reference.")
    e.add_field(name="🔨 Create VPS",
        value="`!createvps` — Standard VPS (default specs)\n"
              "`!customvps` — VPS with custom RAM/CPU/disk\n"
              "`!createsomeonevps @user` — VPS for someone\n"
              "`!someonecustomvps @user` — Custom VPS for someone", inline=False)
    e.add_field(name="📋 View & Manage",
        value="`!panel [#]` — Interactive button panel ✨\n"
              "`!vpslist` — Your VPS\n"
              "`!viewothervps` — All users' VPS\n"
              "`!status [#]` — VM status\n"
              "`!search <q>` — Search VPS", inline=False)
    e.add_field(name="⚡ Power",
        value="`!start [#]` `!stop [#]` `!reboot [#]`\n"
              "`!deletevps [#]` `!userdeletevps <id> [#]`", inline=False)
    e.add_field(name="⏰ Expiry",
        value="`!expire <id> <time>` — e.g. `1d` `2h` `1mo`\n"
              "`!noexpire <id>` — Never expire", inline=False)
    e.add_field(name="🔧 Utilities",
        value="`!run <#> <cmd>` — Run shell command\n"
              "`!install <#> <pkg>` `!df [#]` `!ram [#]`\n"
              "`!top [#]` `!uptime [#]` `!ip [#]` `!ports [#]`\n"
              "`!ping <#> <host>` `!logs [#]`", inline=False)
    e.add_field(name="📸 Snapshots",
        value="`!snapshot [#]` `!snapshots [#]`", inline=False)
    e.add_field(name="🏷 Organization",
        value="`!rename <#> <name>` `!notes <#> <txt>` `!tag <#> <tags>`\n"
              "`!transfer <#> @user` `!autostart <#> on|off`", inline=False)
    e.add_field(name="👥 Admin Tools",
        value="`!stats` `!announce <msg>`\n"
              "`!setmaxvps <n>` `!banuser <id>` `!unbanuser <id>`", inline=False)
    e.add_field(name="🛠 Custom Commands",
        value="`!createcustomcommand` `!deletecustomcommand <n>`\n"
              "`!listcustomcommands`", inline=False)
    e.add_field(name="💬 Talk",
        value="`!talk <id>` `!talk2 <id>` `!endtalk` `!say <msg>` `!clear`", inline=False)
    if cmds:
        e.add_field(name="🔧 Custom",
            value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in list(cmds.items())[:8]), inline=False)
    e.set_footer(text="💡 Use !panel for an interactive button control panel!")
    m = await ctx.send(embed=e); all_messages.setdefault(ctx.channel.id,[]).append(("bot",m.id))

# ══════════════════════════════════════════════════════════════════════════════
#  DM HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_dm(message):
    parts = message.content.strip().split(); cmd = parts[0][1:].lower() if parts else ""; args = parts[1:]
    uid   = message.author.id

    if cmd == "say":
        if uid not in active_talks: await message.channel.send("❌ Not in a chat."); return
        pid  = active_talks[uid]; text = " ".join(args) or "(empty)"
        try:
            p  = await bot.fetch_user(pid); dm = p.dm_channel or await p.create_dm()
            data = load_data(); label = "👤 **User**" if str(uid) in data else "👨‍💼 **Admin**"
            await dm.send(f"{label} **{message.author.display_name}**: {text}")
            await message.channel.send("✅ Sent.")
        except Exception as ex: await message.channel.send(f"❌ {ex}")
        return

    if cmd == "endtalk":
        if uid not in active_talks: await message.channel.send("❌ No active talk."); return
        pid = active_talks.pop(uid); active_talks.pop(pid,None)
        try:
            p = await bot.fetch_user(pid); dm = p.dm_channel or await p.create_dm()
            await dm.send("📵 Chat ended.")
        except: pass
        await message.channel.send("✅ Talk ended."); return

    if cmd == "support":
        if uid in active_talks: await message.channel.send("⚠️ Already chatting."); return
        support_queue[uid] = True
        await message.channel.send("✅ **Support requested!** An admin will reach out shortly.")
        for guild in bot.guilds:
            notified = set()
            for rid in (SUPPORT_ROLE_ID, ADMIN_ROLE_ID):
                role = guild.get_role(rid)
                if not role: continue
                for member in role.members:
                    if member.id in notified or member.bot: continue
                    notified.add(member.id)
                    try:
                        adm = member.dm_channel or await member.create_dm()
                        await adm.send(f"🆘 **Support!** **{message.author.display_name}** (`{uid}`) needs help.\nUse `!talk {uid}`.")
                    except: pass
        return

    data = load_data(); ukey = str(uid)
    index = int(args[0]) if args and args[0].isdigit() else 1

    if cmd == "listvps":
        lst = data.get(ukey,{}).get("vps_list",[])
        if not lst: await message.channel.send("❌ No VMs."); return
        e = discord.Embed(title=f"🖥️ Your VMs ({len(lst)})", color=ACCENT_COLOR)
        for v in lst:
            running = await vm_is_running(v["name"]); exp = v.get("expires_at",0)
            left = f" ({fmt_dur(int(exp-time.time()))} left)" if exp and exp>time.time() else ""
            e.add_field(name=f"#{v['index']} {v['name']}",
                value=(f"{'🟢' if running else '🔴'} {v.get('os','?')}\n"
                       f"SSH: `{v.get('host_ip','?')}:{v.get('ssh_port','?')}`\n"
                       f"⏰ {fmt_ts(exp) if exp else 'Never'}{left}"), inline=False)
        await message.channel.send(embed=e); return

    # DM commands that map to the same handlers via a fake ctx-like object
    vps = get_vps(data, ukey, index)

    DM_CMDS = {
        "panel":   lambda: cmd_panel.__wrapped__(message, index) if hasattr(cmd_panel,'__wrapped__') else None,
    }

    if cmd == "status":
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        running = await vm_is_running(vps["name"]); exp = vps.get("expires_at",0)
        e = discord.Embed(title=f"📊 VM #{index} — `{vps['name']}`", color=GREEN if running else RED)
        e.add_field(name="Status", value=f"{'🟢 Running' if running else '🔴 Stopped'}", inline=True)
        e.add_field(name="OS",     value=vps.get("os","?"),  inline=True)
        e.add_field(name="SSH",    value=f"`{vps.get('host_ip','?')}:{vps.get('ssh_port','?')}`", inline=True)
        e.add_field(name="RAM",    value=f"{vps.get('ram_mb',DEFAULT_RAM_MB)}MB", inline=True)
        e.add_field(name="vCPU",   value=str(vps.get("cpus",DEFAULT_CPUS)), inline=True)
        e.add_field(name="Disk",   value=f"{vps.get('disk_gb',DEFAULT_DISK_GB)}GB", inline=True)
        e.add_field(name="Expires",value=fmt_ts(exp) if exp else "Never", inline=True)
        await message.channel.send(embed=e); return

    if cmd == "panel":
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        running = await vm_is_running(vps["name"])
        view    = VPSPanel(vps, uid, False)
        await message.channel.send(embed=vps_embed(vps, running), view=view); return

    if cmd == "start":
        if not vps: await message.channel.send(f"❌ Not found."); return
        if await vm_is_running(vps["name"]): await message.channel.send("⚠️ Already running."); return
        msg = await message.channel.send("⏳ Starting VM…")
        try:
            await start_qemu(vps["name"], vm_disk(vps["name"]), vm_seed(vps["name"]),
                             vps["ssh_port"], vps.get("ram_mb",DEFAULT_RAM_MB), vps.get("cpus",DEFAULT_CPUS))
            vps["status"]="running"; save_data(data)
            await msg.edit(content=f"▶️ `{vps['name']}` started!")
        except Exception as ex: await msg.edit(content=f"❌ {ex}")
        return

    if cmd == "stop":
        if not vps: await message.channel.send("❌ Not found."); return
        await vm_stop(vps["name"]); vps["status"]="stopped"; save_data(data)
        await message.channel.send(f"⏹️ `{vps['name']}` stopped."); return

    if cmd == "reboot":
        if not vps: await message.channel.send("❌ Not found."); return
        await vm_exec(vps["ssh_port"], vps["username"], "sudo reboot &", timeout=10)
        await message.channel.send(f"🔄 Reboot sent to `{vps['name']}`!"); return

    if cmd == "sshx":
        if not vps: await message.channel.send(f"❌ Not found."); return
        msg = await message.channel.send("⏳ Getting sshx link… (up to 60s)")
        link, dbg = await vm_sshx(vps, msg)
        if link: await msg.edit(content=f"✅ **sshx running!**\n🔗 {link}")
        else:     await msg.edit(content=f"❌ sshx failed.\n```\n{dbg[-500:]}\n```")
        return

    if cmd == "tmate":
        if not vps: await message.channel.send("❌ Not found."); return
        msg = await message.channel.send("⏳ Starting tmate…")
        sl, wl = await vm_tmate(vps, msg)
        if sl or wl:
            lines = ["🖥️ **tmate:**"]
            if sl: lines.append(f"```{sl}```")
            if wl: lines.append(f"🌐 {wl}")
            await msg.edit(content="\n".join(lines))
        else: await msg.edit(content="❌ tmate failed. Try `!sshx`.")
        return

    if cmd == "df":
        if not vps: await message.channel.send("❌ Not found."); return
        _,out,_ = await vm_exec(vps["ssh_port"],vps["username"],"df -h",timeout=15)
        await message.channel.send(f"💾 **Disk:**\n```\n{out.strip()[:1400]}\n```"); return

    if cmd == "ram":
        if not vps: await message.channel.send("❌ Not found."); return
        _,out,_ = await vm_exec(vps["ssh_port"],vps["username"],"free -m",timeout=15)
        await message.channel.send(f"🧠 **RAM:**\n```\n{out.strip()}\n```"); return

    if cmd == "top":
        if not vps: await message.channel.send("❌ Not found."); return
        _,out,_ = await vm_exec(vps["ssh_port"],vps["username"],"ps aux --sort=-%cpu | head -12",timeout=15)
        await message.channel.send(f"⚙️ **Processes:**\n```\n{out.strip()[:1400]}\n```"); return

    if cmd == "uptime":
        if not vps: await message.channel.send("❌ Not found."); return
        _,out,_ = await vm_exec(vps["ssh_port"],vps["username"],"uptime",timeout=10)
        await message.channel.send(f"⏱️ **`{vps['name']}`:** `{out.strip()}`"); return

    if cmd == "logs":
        if not vps: await message.channel.send("❌ Not found."); return
        lf = vm_log(vps["name"])
        if not os.path.exists(lf): await message.channel.send("❌ No log file."); return
        with open(lf,errors="replace") as f: content=f.read()
        tail = content[-1600:] if len(content)>1600 else content
        await message.channel.send(f"📜 **Boot log:**\n```\n{tail}\n```"); return

    if cmd == "install":
        if not vps: await message.channel.send("❌ Not found."); return
        pkg = " ".join(args[1:]) if len(args)>1 else ""
        if not pkg: await message.channel.send("❌ Usage: `!install <#> <package>`"); return
        msg = await message.channel.send(f"⏳ Installing `{pkg}`…")
        rc,out,err = await vm_exec(vps["ssh_port"],vps["username"],
            f"DEBIAN_FRONTEND=noninteractive apt-get install -y {pkg} 2>&1", timeout=120)
        output=(out+err).strip()[-600:]
        if rc==0: await msg.edit(content=f"✅ `{pkg}` installed!\n```\n{output}\n```")
        else:     await msg.edit(content=f"❌ Install failed:\n```\n{output}\n```")
        return

    if cmd == "commands":
        e = discord.Embed(title="🖥️ VPS Bot — Your Commands", color=ACCENT_COLOR)
        e.add_field(name="📋 Info", value="`!panel [#]` `!listvps` `!status [#]`\n`!df [#]` `!ram [#]` `!top [#]` `!uptime [#]` `!logs [#]`", inline=False)
        e.add_field(name="⚡ Power", value="`!start [#]` `!stop [#]` `!reboot [#]`", inline=False)
        e.add_field(name="🌐 Access", value="`!sshx [#]` — browser terminal\n`!tmate [#]` — SSH via tmate", inline=False)
        e.add_field(name="🛠 Utils", value="`!install <#> <pkg>`\n`!notes <#> <text>` `!tag <#> <tags>`", inline=False)
        e.add_field(name="💬 Support", value="`!support` `!say <msg>` `!endtalk`", inline=False)
        cmds = load_custom_cmds()
        if cmds: e.add_field(name="🔧 Custom", value="\n".join(f"`!{n} [#]` — {i['description']}" for n,i in cmds.items()), inline=False)
        await message.channel.send(embed=e); return

    # custom commands in DM
    cmds = load_custom_cmds()
    if cmd in cmds:
        if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
        msg = await message.channel.send(f"⏳ Running `!{cmd}` on `{vps['name']}`…")
        rc,out,err = await vm_exec(vps["ssh_port"],vps["username"],cmds[cmd]["bash"],timeout=120)
        output = (out+err).strip()[:1500]
        if rc==0: await msg.edit(content=f"✅ `!{cmd}` done!\n```{output}```" if output else f"✅ Done!")
        else:     await msg.edit(content=f"❌ `!{cmd}` failed:\n```{output}```")
        return

    await message.channel.send(f"❓ Unknown `!{cmd}`. Type `!commands`.")

# ══════════════════════════════════════════════════════════════════════════════
#  EVENT ROUTER
# ══════════════════════════════════════════════════════════════════════════════

@bot.event
async def on_message(message):
    if message.author.bot: return
    if isinstance(message.channel, discord.DMChannel):
        if message.content.startswith("!"): await handle_dm(message)
        return
    all_messages.setdefault(message.channel.id,[]).append(("user",message.id))

    if message.content.startswith("!"):
        parts = message.content.strip().split(); cmd = parts[0][1:].lower() if parts else ""; args = parts[1:]
        index = int(args[0]) if args and args[0].isdigit() else 1
        cmds  = load_custom_cmds()
        if cmd in cmds:
            data = load_data(); vps = get_vps(data, str(message.author.id), index)
            if not vps: await message.channel.send(f"❌ VPS #{index} not found."); return
            msg = await message.channel.send(f"⏳ Running `!{cmd}` on `{vps['name']}`…")
            rc,out,err = await vm_exec(vps["ssh_port"],vps["username"],cmds[cmd]["bash"],timeout=120)
            output = (out+err).strip()[:1500]
            if rc==0: await msg.edit(content=f"✅ `!{cmd}` done!\n```{output}```" if output else "✅ Done!")
            else:     await msg.edit(content=f"❌ `!{cmd}` failed:\n```{output}```")
            return

    await bot.process_commands(message)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MemberNotFound): await ctx.send("❌ User not found.")
    elif isinstance(error, commands.MissingRequiredArgument): await ctx.send("❌ Missing argument. Try `!commands`.")
    elif isinstance(error, commands.BadArgument): await ctx.send("❌ Bad argument. Check the command format.")
    elif isinstance(error, (commands.CheckFailure, commands.CommandNotFound)): pass
    else: await ctx.send(f"❌ Error: `{error}`")

@bot.event
async def on_ready():
    ensure_dirs()
    print(f"╔══════════════════════════════════════╗")
    print(f"║  Dirt VPS Bot v3.0 — Online!         ║")
    print(f"║  {bot.user} ({bot.user.id})")
    print(f"║  KVM: {'✅ available' if os.path.exists('/dev/kvm') else '❌ not available (slower)'}")
    print(f"╚══════════════════════════════════════╝")
    bot.loop.create_task(expiry_loop())
    bot.loop.create_task(autostart_loop())

bot.run(BOT_TOKEN)
